package com.iftas.eventportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventportalApplicationTests {

	@Test
	void contextLoads() {
	}

}
