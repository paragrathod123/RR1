package com.iftas.eventportal;

import java.util.TimeZone;

import javax.annotation.PostConstruct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;


@SpringBootApplication
@PropertySource(ignoreResourceNotFound = true, value = "classpath:i18n/messages.properties")
public class EventportalApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(EventportalApplication.class, args);
	}
	
	@Bean
    public MultipartResolver multipartResolver() {
      CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
      multipartResolver.setMaxUploadSize(10485760*5); // 10MB
      multipartResolver.setMaxUploadSizePerFile(1048576*5); // 1MB
      return multipartResolver;
    }
	
	@Override
	 protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
	  return application.sources(EventportalApplication.class);
	}
	
	@PostConstruct
	  public void init(){
	    // Setting Spring Boot SetTimeZone
	    TimeZone.setDefault(TimeZone.getTimeZone("IST"));
	  }
 
}
