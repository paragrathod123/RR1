package com.iftas.eventportal;

import java.io.IOException;
import java.util.Properties;

import com.iftas.eventportal.library.FileManipulationLibrary;



public class ConfigLibrary {
	private static String configFileLocation = "";

	  
	  public static String getConfigFileLocation() { return configFileLocation; }


	  
	  public static void setConfigFileLocation(String configFileLocation) { ConfigLibrary.configFileLocation = configFileLocation; }

	  
	  public static String getConfigValue(String configName) throws IOException {
	    Properties propertyContent = FileManipulationLibrary.readPropertyFile(configFileLocation);
	    return propertyContent.getProperty(configName);
	  }
}
