package com.iftas.eventportal.config;


import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@Configuration
@EnableJpaRepositories("com.iftas.eventportal.dao")
@EnableTransactionManagement
public class DatabaseConfiguration {
}