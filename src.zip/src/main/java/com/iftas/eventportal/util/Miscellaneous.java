package com.iftas.eventportal.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;

import com.iftas.eventportal.dao.MenuRepository;
import com.iftas.eventportal.dao.RoleRepository;
import com.iftas.eventportal.dao.SpeakersRepository;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.iftas.eventportal.dao.CentreRepository;
import com.iftas.eventportal.dao.DepartmentRepository;
import com.iftas.eventportal.dao.DesignationRepository;
import com.iftas.eventportal.dao.OrganizationRepository;
import com.iftas.eventportal.dao.UserRepository;
import com.iftas.eventportal.entity.MenuMaster;
import com.iftas.eventportal.entity.PageMenuOnBasisRole;
import com.iftas.eventportal.entity.RoleMst;
import com.iftas.eventportal.entity.SpeakerMaster;
import com.iftas.eventportal.entity.Centres;
import com.iftas.eventportal.entity.Department;
import com.iftas.eventportal.entity.Designation;
import com.iftas.eventportal.entity.Organization;
import com.iftas.eventportal.entity.User;


public class Miscellaneous implements GetUserName{

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private MenuRepository menuRepository;
	
	@Autowired
	EntityManager entityManager;
	
	@Autowired
	private OrganizationRepository organizationRepository;
	
	@Autowired
	private CentreRepository centreRepository;
	
	@Autowired
	private DepartmentRepository departmentRepository;
	
	@Autowired
	private DesignationRepository designationRepository;
	
	@Autowired
	private SpeakersRepository speakersRepository;
	
	
	
	@Override
	public String getUserName(int id) {
		String userName = "" ; 
		Optional<User> users =  userRepository.findById(Long.valueOf(id));
		if(users.isPresent()) {
			User user =  users.get();
			userName = user.getUserName();
		}
		return userName;
	}

	@Override
	public List<RoleMst> getAllRoles(int displayFlag) {
		return roleRepository.findAllByActiveStatus(displayFlag);
	}

	@Override
	public List<MenuMaster> getAllMenus() {
		return menuRepository.findAll();
	}

	@Override
	public List<PageMenuOnBasisRole> getAllPagesWithPrivilegesOnBasisOfRoleId(int roleId, int menuId) {
		String sqlQuery ="Select pageid,pageName,menuid,max(is_Read) as is_Read,max(is_Add) as is_Add,max(is_Export) as is_Export,\r\n" + 
				"\r\n" + 
				"max(is_Edit) as is_Edit from (\r\n" + 
				"Select pgmst.pageid,pgmst.menuid ,pgmst.name as pageName,NULL as is_Read,NULL as is_Add,NULL as is_Export, NULL as is_Edit ,NULL as roleid \r\n" + 
				"from pagemst pgmst Where pgmst.menuid="+menuId+" \r\n" + 
				"union\r\n" + 
				"Select pri.pageid,pgmst.menuid,pgmst.name as pageName,pri.is_Read,pri.is_Add,pri.is_Export,pri.is_Edit,pri.roleid\r\n" + 
				" from privileges pri ,pagemst pgmst Where pri.pageid = pgmst.pageid\r\n" + 
				" and pri.roleid="+roleId+" and pgmst.menuid="+menuId+" \r\n" + 
				" ) as temp Group by pageid,pageName,menuid";
		System.out.println("sqlQuery  "+sqlQuery);
		Query query = entityManager.createNativeQuery(sqlQuery, "PagesWithPrivilegesOnBasisOfRoleId");
		
		List<PageMenuOnBasisRole> result =  query.getResultList();
		return result;
	}

	@Override
	public List<String> getMenuNameOnBasisOfRoleId(int roleId) {
		String strQuery ="Select abc.name from (select distinct menu.name,menu.menuid from privileges pri,pagemst pages,menumst menu where pri.pageid =  pages.pageid and pages.menuid = menu.menuid and pri.roleid="+roleId+"  Order  by menu.menuid asc ) as abc ";
		
		Query query = entityManager.createNativeQuery(strQuery);
		List<String> result =  query.getResultList();
		return result;
	}

	@Override
	public List<PageMenuOnBasisRole> getSelectedPagesWithPrivilegesOnBasisOfRoleId(int roleId, int menuId) {
		String sqlQuery ="Select pri.pageid,pgmst.menuid,pgmst.name as pageName,pri.is_Read,pri.is_Add,pri.is_Export,pri.is_Edit,pri.roleid\r\n" + 
				" from privileges pri ,pagemst pgmst Where pri.pageid = pgmst.pageid\r\n" + 
				" and pri.roleid="+roleId+" and pgmst.menuid="+menuId+" \r\n" + 
				" ";
		System.out.println("sqlQuery  "+sqlQuery);
		Query query = entityManager.createNativeQuery(sqlQuery, "SelectedPagesWithPrivilegesOnBasisOfRoleId");
		
		List<PageMenuOnBasisRole> result =  query.getResultList();
		return result;
	}



	@Override
	public List<Organization> getAllOrganization(int activeStatus) {
		return organizationRepository.findAllByActiveStatusOrderByOrganizationNameAsc(activeStatus);
	}



	@Override
	public List<Centres> getAllCenters(int activeStatus) {
		return centreRepository.findAllByActiveStatusOrderByCentreNameAsc(activeStatus);
	}



	@Override
	public List<Department> getAllDepartments(int activeStatus) {
		return departmentRepository.findAllByActiveStatusOrderByDepartmentNameAsc(activeStatus);
	}



	@Override
	public List<Designation> getAllDesignations(int activeStatus) {
		return designationRepository.findAllByActiveStatusOrderByDesignationNameAsc(activeStatus);
	}

	@Override
	public String getAllSpeakers(int activeStatus) {
		List<SpeakerMaster> speakerList = new ArrayList<SpeakerMaster>();
		speakerList =  speakersRepository.findAll();
		System.out.println(speakerList.size());
		JSONObject obj = new JSONObject();
		JSONArray arr = new JSONArray();
		
		for (SpeakerMaster object : speakerList) {
			obj.put("id", object.getSpeakerId());
			obj.put("firstName", object.getSpeakerFirstName());
			obj.put("lastName", object.getSpeakerLastName());
			
			arr.add(obj);
			
			obj = new JSONObject();
			
		}
		
		String jsonArray =  JSON.toJSONString(speakerList);
		System.out.println(jsonArray);
		return jsonArray;
	}

	@Override
	public List<RoleMst> getMasterRole(int displayFlag) {
		return roleRepository.findAllMasterRole( displayFlag);
	}

	@Override
	public List<RoleMst> getAdminRole(int displayFlag) {
		return roleRepository.findAllAdminRole(displayFlag);
	}

//	@Override
//	public List<SpeakerMaster> getAllSpeakers(int activeStatus) {
//		// TODO Auto-generated method stub
//		return speakersRepository.findAll();
//	}
	
	
	
	
	

}
