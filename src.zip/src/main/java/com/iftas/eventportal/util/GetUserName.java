package com.iftas.eventportal.util;

import java.util.List;

import com.alibaba.fastjson.JSONArray;
import com.iftas.eventportal.entity.Centres;
import com.iftas.eventportal.entity.Department;
import com.iftas.eventportal.entity.Designation;
import com.iftas.eventportal.entity.MenuMaster;
import com.iftas.eventportal.entity.Organization;
import com.iftas.eventportal.entity.PageMenuOnBasisRole;
import com.iftas.eventportal.entity.RoleMst;
import com.iftas.eventportal.entity.SpeakerMaster;

public interface GetUserName {
	
	
	String getUserName(int id);
	
	List<RoleMst> getAllRoles(int displayFlag);
	
	List<MenuMaster> getAllMenus();
	
	List<PageMenuOnBasisRole> getAllPagesWithPrivilegesOnBasisOfRoleId(int roleId, int menuId);

	List<String> getMenuNameOnBasisOfRoleId(int roleId);


	List<PageMenuOnBasisRole> getSelectedPagesWithPrivilegesOnBasisOfRoleId(int roleId, int menuId);
	
	List<Organization> getAllOrganization(int activeStatus);
	
	List<Centres> getAllCenters(int activeStatus);
	
	List<Department> getAllDepartments(int activeStatus);
	
	List<Designation> getAllDesignations(int activeStatus);
	
	String getAllSpeakers(int activeStatus);
	
	List<RoleMst> getMasterRole(int displayFlag);
	
	List<RoleMst> getAdminRole(int displayFlag);
	
	//List<SpeakerMaster> getAllSpeakers(int activeStatus);
	
	
	
}
