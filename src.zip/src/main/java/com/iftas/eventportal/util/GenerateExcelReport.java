package com.iftas.eventportal.util;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iftas.eventportal.entity.Centres;
import com.iftas.eventportal.entity.CommonSetup;
import com.iftas.eventportal.entity.Department;
import com.iftas.eventportal.entity.Designation;
import com.iftas.eventportal.entity.EmailTemplate;
import com.iftas.eventportal.entity.EventFeedbackReport;
import com.iftas.eventportal.entity.MobileUsers;
import com.iftas.eventportal.entity.Organization;
import com.iftas.eventportal.entity.ParticipantMaster;
import com.iftas.eventportal.entity.RoleMst;
import com.iftas.eventportal.entity.SpeakerMaster;
import com.iftas.eventportal.entity.User;




@Service
public class GenerateExcelReport {
	
	
	@Autowired
	EntityManager entityManager;
	
	
	

    
    public  ByteArrayInputStream FeedbackReportToExcel(List<EventFeedbackReport> eventFeedbackReportList) throws IOException {
		
		DateTimeFormatter formatter =
			    DateTimeFormatter.ofLocalizedDateTime( FormatStyle.SHORT )
			                     .withLocale( Locale.UK )
			                     .withZone( ZoneId.systemDefault() );
		
		
		String[] COLUMNs = { "Department Name","Event Name","Session Name"
				,"Speaker Name","Ratings"
				,"Event Date","User Name" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			Sheet sheet = workbook.createSheet("Feedback Report ");
			
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.BLUE.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			// Header Row
			Row headerRow = sheet.createRow(0);

			// Table Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);
			}

			int rowIdx = 1;
		
			
			for (EventFeedbackReport feedbackReport : eventFeedbackReportList) {
				Row row = sheet.createRow(rowIdx++);

				row.createCell(0).setCellValue(feedbackReport.getDepartmentName());
				row.createCell(1).setCellValue(feedbackReport.getEventName());
				row.createCell(2).setCellValue(feedbackReport.getSessionName());
				row.createCell(3).setCellValue(feedbackReport.getUserName());
				row.createCell(4).setCellValue(feedbackReport.getSpeakerName());
				row.createCell(5).setCellValue(feedbackReport.getRatingName());
				row.createCell(6).setCellValue(feedbackReport.getEventDate());
				
			}
			
			//Auto-size all the above columns
			sheet.autoSizeColumn(0);
			sheet.autoSizeColumn(1);
			sheet.autoSizeColumn(2);
			sheet.autoSizeColumn(3);
			sheet.autoSizeColumn(4);
			sheet.autoSizeColumn(5);
			sheet.autoSizeColumn(6);
			

			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}
public  ByteArrayInputStream rolesToExcel(List<RoleMst> roles) throws IOException {
 		
 		DateTimeFormatter formatter =
 			    DateTimeFormatter.ofLocalizedDateTime( FormatStyle.SHORT )
 			                     .withLocale( Locale.UK )
 			                     .withZone( ZoneId.systemDefault() );
 		
 		
 		String[] COLUMNs = { "Role Name", "Module","Active/InActive","Created By", "Created Date"
 				,"Last Modified By","Last Modified Date" };
 		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
 			Sheet sheet = workbook.createSheet("Roles");
 			
 			Font headerFont = workbook.createFont();
 			headerFont.setBold(true);
 			headerFont.setColor(IndexedColors.BLUE.getIndex());

 			CellStyle headerCellStyle = workbook.createCellStyle();
 			headerCellStyle.setFont(headerFont);

 			// Header Row
 			Row headerRow = sheet.createRow(0);

 			// Table Header
 			for (int col = 0; col < COLUMNs.length; col++) {
 				Cell cell = headerRow.createCell(col);
 				cell.setCellValue(COLUMNs[col]);
 				cell.setCellStyle(headerCellStyle);
 			}

 			int rowIdx = 1;
 			for (RoleMst role : roles) {
 				Row row = sheet.createRow(rowIdx++);

 				row.createCell(0).setCellValue(role.getRoleName());
 				
 				
 				//Below to get distinct menu name 
 				String strQuery ="Select abc.name from (select distinct menu.name,menu.menuid from privileges pri,pagemst pages,menumst menu where pri.pageid =  pages.pageid and pages.menuid = menu.menuid and pri.roleid="+role.getRoleId()+"  Order  by menu.menuid asc ) as abc ";
				 
				  
				  Query query = entityManager.createNativeQuery(strQuery); String menuName =
				  (String) query.getResultStream().collect(Collectors.joining(", "));;
				  row.createCell(1).setCellValue(menuName);
				 
 				
 				if(role.getActiveStatus() == 0) {
 					row.createCell(2).setCellValue("Active");
 				}else {
 					row.createCell(2).setCellValue("In Active");
 				}
 				
 				
 				
 				
 				
 				
 				if(role.getCreatedBy()!=0L) {
				  String query1="Select first_name from users where userid = "+role.getCreatedBy();
				  Query q = entityManager.createNativeQuery(query1); 
				  String result = (String)q.getSingleResult(); row.createCell(3).setCellValue(result);
 				}
 				else {
 					row.createCell(3).setCellValue("");
 				}	
				 
					
					
					if(role.getCreatedDate()!=null && !role.getCreatedDate().equals("") && !role.getCreatedDate().equals("null")) {
	 					row.createCell(4).setCellValue(formatter.format(role.getCreatedDate()));
	 				}else {
	 					row.createCell(4).setCellValue("");
	 				}	
					
 				if(role.getModifiedBy()!=0L) {
 					String query11="Select first_name from users where userid ="+role.getModifiedBy();
 					Query q1 =  entityManager.createNativeQuery(query11);
 					String result1 =  (String)q1.getSingleResult();
 					row.createCell(5).setCellValue(result1);
 				}else {
 					
 					row.createCell(5).setCellValue("");
 					
 				}
 				
 				if(role.getModifiedDate()!=null && !role.getModifiedDate().equals("") && !role.getModifiedDate().equals("null")) {
 					row.createCell(6).setCellValue(formatter.format(role.getModifiedDate()));
 				}else {
 					row.createCell(6).setCellValue("");
 				}
 			}
 			
 			//Auto-size all the above columns
 			sheet.autoSizeColumn(0);
 			sheet.autoSizeColumn(1);
 			sheet.autoSizeColumn(2);
 			sheet.autoSizeColumn(3);
 			sheet.autoSizeColumn(4);
 			sheet.autoSizeColumn(5);
			sheet.autoSizeColumn(6); 
 			

 			workbook.write(out);
 			return new ByteArrayInputStream(out.toByteArray());
 		}
 	}

public  ByteArrayInputStream usersToExcel(List<User> users) throws IOException {
	
	DateTimeFormatter formatter =
		    DateTimeFormatter.ofLocalizedDateTime( FormatStyle.SHORT )
		                     .withLocale( Locale.UK )
		                     .withZone( ZoneId.systemDefault() );
	
	
	String[] COLUMNs = {"Title", "First Name", "Last Name", "Login Name","Email", "Mobile No","Role","is Super Admin","Department"
			,"Designation", "Status" };
	try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
		Sheet sheet = workbook.createSheet("Users");
		
		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setColor(IndexedColors.BLUE.getIndex());

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFont(headerFont);

		// Header Row
		Row headerRow = sheet.createRow(0);

		// Table Header
		for (int col = 0; col < COLUMNs.length; col++) {
			Cell cell = headerRow.createCell(col);
			cell.setCellValue(COLUMNs[col]);
			cell.setCellStyle(headerCellStyle);
		}

		int rowIdx = 1;
		for (User user : users) {
			Row row = sheet.createRow(rowIdx++);

			row.createCell(0).setCellValue(user.getTitle());
			row.createCell(1).setCellValue(user.getUserName());
			row.createCell(2).setCellValue(user.getLastName());
			row.createCell(3).setCellValue(user.getLogin());
			row.createCell(4).setCellValue(user.getEmail());
			row.createCell(5).setCellValue(user.getMobileNo());
			
			String query1="Select rolemst.name from rbieventmanagementdb.rolemst, users where \r\n"+ 
			"rolemst.roleid = users.roleid and users.userid = "+user.getUserId(); 
				Query q1 =  entityManager.createNativeQuery(query1);
				String result1 =  (String)q1.getSingleResult();
				row.createCell(6).setCellValue(result1);
				
			if(user.getMarkerType() == 0) {
				row.createCell(7).setCellValue("Yes");
			}else if (user.getMarkerType() == 1) {
				row.createCell(7).setCellValue("No");
			}
				
				
				if(user.getUserDepartment()!=null) {
				  String query2="Select department.department_name from rbieventmanagementdb.department, users where \r\n"
				  + "department.department_id = users.department_id and users.userid = "+user.getUserId(); 
				  Query q2 = entityManager.createNativeQuery(query2); 
				  String result2 = (String)q2.getSingleResult();
				  row.createCell(8).setCellValue(result2);
				}
				else {
					row.createCell(8).setCellValue("");
				}
				  
				if(user.getUserDesignation()!=null) {
				  String query3="Select designation.designation_name from rbieventmanagementdb.designation, users where \r\n"
                  + "designation.designation_id = users.designation_id and users.userid = "+user.getUserId();
				  Query q3 = entityManager.createNativeQuery(query3); 
				  String result3 = (String)q3.getSingleResult();
				  row.createCell(9).setCellValue(result3);
				}
				else {
					row.createCell(9).setCellValue("");
				}
						
		
			if(user.getActiveStatus() == 0) {
				row.createCell(10).setCellValue("Active");
			}else {
				row.createCell(10).setCellValue("In Active");
			}

		}
		
		//Auto-size all the above columns
		sheet.autoSizeColumn(0);
		sheet.autoSizeColumn(1);
		sheet.autoSizeColumn(2);
		sheet.autoSizeColumn(3);
		sheet.autoSizeColumn(4);
		sheet.autoSizeColumn(5);
		sheet.autoSizeColumn(6);
	    sheet.autoSizeColumn(7);
	    sheet.autoSizeColumn(8);
	    sheet.autoSizeColumn(9);
	    sheet.autoSizeColumn(10);
			 



		workbook.write(out);
		return new ByteArrayInputStream(out.toByteArray());
	}
}

public  ByteArrayInputStream CommonSetupToExcel(List<CommonSetup> commonsetups) throws IOException {
		
		DateTimeFormatter formatter =
			    DateTimeFormatter.ofLocalizedDateTime( FormatStyle.SHORT )
			                     .withLocale( Locale.UK )
			                     .withZone( ZoneId.systemDefault() );
		
		
		String[] COLUMNs = { "Session Time Out", "Max Login Attempts", "Password Expiry After No Of Days","Active/InActive", "Created Date"
				,"Last Modified By","Last Modified Date" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			Sheet sheet = workbook.createSheet("Portal Settings");
			
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.BLUE.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			// Header Row
			Row headerRow = sheet.createRow(0);

			// Table Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);
			}

			int rowIdx = 1;
			for (CommonSetup commonsetup : commonsetups) {
				Row row = sheet.createRow(rowIdx++);

				row.createCell(0).setCellValue(commonsetup.getSessionTimeOut());
				row.createCell(1).setCellValue(commonsetup.getMaxLoginAttempts());
				row.createCell(2).setCellValue(commonsetup.getPasswordExpiryAfterNoOfDays());
				
				
				if(commonsetup.getActiveStatus() == 0) {
					row.createCell(3).setCellValue("Active");
				}else {
					row.createCell(3).setCellValue("In Active");
				}

				if(commonsetup.getCreatedDate()!=null && !commonsetup.getCreatedDate().equals("") && !commonsetup.getCreatedDate().equals("null")) {
					row.createCell(4).setCellValue(formatter.format(commonsetup.getCreatedDate()));
				}else {
					row.createCell(4).setCellValue("");
				}
				
				
				if(commonsetup.getModifiedBy()!=0L) {
					String query="Select first_name from users where userid ="+commonsetup.getModifiedBy();
					Query q =  entityManager.createNativeQuery(query);
					String result =  (String)q.getSingleResult();
					row.createCell(5).setCellValue(result);
				}else {
				
					row.createCell(5).setCellValue("");
					
				}
				
				if(commonsetup.getModifiedDate()!=null && !commonsetup.getModifiedDate().equals("") && !commonsetup.getModifiedDate().equals("null")) {
					row.createCell(6).setCellValue(formatter.format(commonsetup.getModifiedDate()));
				}else {
					row.createCell(6).setCellValue("");
				}
			}
			
			//Auto-size all the above columns
			sheet.autoSizeColumn(0);
			sheet.autoSizeColumn(1);
			sheet.autoSizeColumn(2);
			sheet.autoSizeColumn(3);
			sheet.autoSizeColumn(4);
			sheet.autoSizeColumn(5);
			sheet.autoSizeColumn(6);

			

			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

public  ByteArrayInputStream emailSetupToExcel(List<EmailTemplate> emailsetup) throws IOException {
	
	DateTimeFormatter formatter =
		    DateTimeFormatter.ofLocalizedDateTime( FormatStyle.SHORT )
		                     .withLocale( Locale.UK )
		                     .withZone( ZoneId.systemDefault() );
	
	

	String[] COLUMNs = { "Title","Active/InActive"
			,"Created Date"
			,"Last Modified By","Last Modified Date" };
	try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
		Sheet sheet = workbook.createSheet("Contact Us ");
		
		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setColor(IndexedColors.BLUE.getIndex());

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFont(headerFont);

		// Header Row
		Row headerRow = sheet.createRow(0);

		// Table Header
		for (int col = 0; col < COLUMNs.length; col++) {
			Cell cell = headerRow.createCell(col);
			cell.setCellValue(COLUMNs[col]);
			cell.setCellStyle(headerCellStyle);
		}

		int rowIdx = 1;
		for (EmailTemplate emailsetups : emailsetup) {
			Row row = sheet.createRow(rowIdx++);

			row.createCell(0).setCellValue("Email Invite");
			
			
			if(emailsetups.getActiveStatus() == 0) {
				row.createCell(1).setCellValue("Active");
			}else {
				row.createCell(1).setCellValue("In Active");
			}
			
			
			
			
			
			if(emailsetups.getCreatedDate()!=null && !emailsetups.getCreatedDate().equals("") && !emailsetups.getCreatedDate().equals("null")) {
				row.createCell(2).setCellValue(formatter.format(emailsetups.getCreatedDate()));
			}else {
				row.createCell(2).setCellValue("");
			}
			
			
			if(emailsetups.getModifiedBy()!=null) {
				String query="Select first_name from users where userid ="+emailsetups.getModifiedBy();
				Query q =  entityManager.createNativeQuery(query);
				String result =  (String)q.getSingleResult();
				row.createCell(3).setCellValue(result);
			}else {
				String query="Select first_name from users where userid = "+emailsetups.getCreatedBy();
				Query q =  entityManager.createNativeQuery(query);
				String result =  (String)q.getSingleResult();
				row.createCell(3).setCellValue(result);
				
			}
			
			if(emailsetups.getModifiedDate()!=null && !emailsetups.getModifiedDate().equals("") && !emailsetups.getModifiedDate().equals("null")) {
				row.createCell(4).setCellValue(formatter.format(emailsetups.getModifiedDate()));
			}else {
				row.createCell(4).setCellValue("");
			}
		}
		
		//Auto-size all the above columns
		sheet.autoSizeColumn(0);
		sheet.autoSizeColumn(1);
		sheet.autoSizeColumn(2);
		sheet.autoSizeColumn(3);
		sheet.autoSizeColumn(4);
		
		

		workbook.write(out);
		return new ByteArrayInputStream(out.toByteArray());
	}
}
public  ByteArrayInputStream organizationToExcel(List<Organization> organizations) throws IOException {
		
		DateTimeFormatter formatter =
			    DateTimeFormatter.ofLocalizedDateTime( FormatStyle.SHORT )
			                     .withLocale( Locale.UK )
			                     .withZone( ZoneId.systemDefault() );
		
		
		String[] COLUMNs = { "Organization Name", "Status","Created Date", "Created By"
				,"Last Modified By","Last Modified Date" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			Sheet sheet = workbook.createSheet("Organizations");
			
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.BLUE.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			// Header Row
			Row headerRow = sheet.createRow(0);

			// Table Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);
			}

			int rowIdx = 1;
			for (Organization organization : organizations) {
				Row row = sheet.createRow(rowIdx++);

				row.createCell(0).setCellValue(organization.getOrganizationName());
				

				if(organization.getActiveStatus() == 0) {
					row.createCell(1).setCellValue("Active");
				}else {
					row.createCell(1).setCellValue("In Active");
				}
				
	
				if(organization.getCreatedDate()!=null && !organization.getCreatedDate().equals("") && !organization.getCreatedDate().equals("null")) {
 					row.createCell(2).setCellValue(formatter.format(organization.getCreatedDate()));
 				}else {
 					row.createCell(2).setCellValue("");
 				}	
				
				if(organization.getCreatedBy()!=0L) {
					  String query1="Select first_name from users where userid = "+organization.getCreatedBy();
					  Query q = entityManager.createNativeQuery(query1); 
					  String result = (String)q.getSingleResult(); row.createCell(3).setCellValue(result);
						}
						else {
							row.createCell(3).setCellValue("");
						}	
				
				
				if(organization.getModifiedBy()!=0L) {
					String query11="Select first_name from users where userid ="+organization.getModifiedBy();
					Query q1 =  entityManager.createNativeQuery(query11);
					String result1 =  (String)q1.getSingleResult();
					row.createCell(4).setCellValue(result1);
				}else {
				
					row.createCell(4).setCellValue("");
					
				}
				
				if(organization.getModifiedDate()!=null && !organization.getModifiedDate().equals("") && !organization.getModifiedDate().equals("null")) {
					row.createCell(5).setCellValue(formatter.format(organization.getModifiedDate()));
				}else {
					row.createCell(5).setCellValue("");
				}
			}
			
			//Auto-size all the above columns
			sheet.autoSizeColumn(0);
			sheet.autoSizeColumn(1);
			sheet.autoSizeColumn(2);
			sheet.autoSizeColumn(3);
			sheet.autoSizeColumn(4);
			sheet.autoSizeColumn(5);
			

			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}
    
public  ByteArrayInputStream centreToExcel(List<Centres> centres) throws IOException {
	
	DateTimeFormatter formatter =
		    DateTimeFormatter.ofLocalizedDateTime( FormatStyle.SHORT )
		                     .withLocale( Locale.UK )
		                     .withZone( ZoneId.systemDefault() );
	
	
	String[] COLUMNs = { "Centre Name", "Status","Created Date", "Created By"
			,"Last Modified By","Last Modified Date" };
	try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
		Sheet sheet = workbook.createSheet("Centres");
		
		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setColor(IndexedColors.BLUE.getIndex());

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFont(headerFont);

		// Header Row
		Row headerRow = sheet.createRow(0);

		// Table Header
		for (int col = 0; col < COLUMNs.length; col++) {
			Cell cell = headerRow.createCell(col);
			cell.setCellValue(COLUMNs[col]);
			cell.setCellStyle(headerCellStyle);
		}

		int rowIdx = 1;
		for (Centres centre : centres) {
			Row row = sheet.createRow(rowIdx++);

			row.createCell(0).setCellValue(centre.getCentreName());
			

			if(centre.getActiveStatus() == 0) {
				row.createCell(1).setCellValue("Active");
			}else {
				row.createCell(1).setCellValue("In Active");
			}
			

			if(centre.getCreatedDate()!=null && !centre.getCreatedDate().equals("") && !centre.getCreatedDate().equals("null")) {
					row.createCell(2).setCellValue(formatter.format(centre.getCreatedDate()));
				}else {
					row.createCell(2).setCellValue("");
				}	
			
			if(centre.getCreatedBy()!=0L) {
				  String query1="Select first_name from users where userid = "+centre.getCreatedBy();
				  Query q = entityManager.createNativeQuery(query1); 
				  String result = (String)q.getSingleResult(); row.createCell(3).setCellValue(result);
					}
					else {
						row.createCell(3).setCellValue("");
					}	
			
			
			if(centre.getModifiedBy()!=0L) {
				String query11="Select first_name from users where userid ="+centre.getModifiedBy();
				Query q1 =  entityManager.createNativeQuery(query11);
				String result1 =  (String)q1.getSingleResult();
				row.createCell(4).setCellValue(result1);
			}else {
				row.createCell(4).setCellValue("");
				
			}
			
			if(centre.getModifiedDate()!=null && !centre.getModifiedDate().equals("") && !centre.getModifiedDate().equals("null")) {
				row.createCell(5).setCellValue(formatter.format(centre.getModifiedDate()));
			}else {
				row.createCell(5).setCellValue("");
			}
		}
		
		//Auto-size all the above columns
		sheet.autoSizeColumn(0);
		sheet.autoSizeColumn(1);
		sheet.autoSizeColumn(2);
		sheet.autoSizeColumn(3);
		sheet.autoSizeColumn(4);
		sheet.autoSizeColumn(5);
		

		workbook.write(out);
		return new ByteArrayInputStream(out.toByteArray());
	}
}
public  ByteArrayInputStream departmentToExcel(List<Department> departments) throws IOException {
	
	DateTimeFormatter formatter =
		    DateTimeFormatter.ofLocalizedDateTime( FormatStyle.SHORT )
		                     .withLocale( Locale.UK )
		                     .withZone( ZoneId.systemDefault() );
	
	
	String[] COLUMNs = { "Department Code", "Department Name", "Status","Created Date", "Created By"
			,"Last Modified By","Last Modified Date" };
	try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
		Sheet sheet = workbook.createSheet("Departments");
		
		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setColor(IndexedColors.BLUE.getIndex());

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFont(headerFont);

		// Header Row
		Row headerRow = sheet.createRow(0);

		// Table Header
		for (int col = 0; col < COLUMNs.length; col++) {
			Cell cell = headerRow.createCell(col);
			cell.setCellValue(COLUMNs[col]);
			cell.setCellStyle(headerCellStyle);
		}

		int rowIdx = 1;
		for (Department department : departments) {
			Row row = sheet.createRow(rowIdx++);

			row.createCell(0).setCellValue(department.getDepartmentCode());
			row.createCell(1).setCellValue(department.getDepartmentName());

			if(department.getActiveStatus() == 0) {
				row.createCell(2).setCellValue("Active");
			}else {
				row.createCell(2).setCellValue("In Active");
			}
			

			if(department.getCreatedDate()!=null && !department.getCreatedDate().equals("") && !department.getCreatedDate().equals("null")) {
					row.createCell(3).setCellValue(formatter.format(department.getCreatedDate()));
				}else {
					row.createCell(3).setCellValue("");
				}	
			
			if(department.getCreatedBy()!=0L) {
				  String query1="Select first_name from users where userid = "+department.getCreatedBy();
				  Query q = entityManager.createNativeQuery(query1); 
				  String result = (String)q.getSingleResult(); row.createCell(4).setCellValue(result);
					}
					else {
						row.createCell(4).setCellValue("");
					}	
			
			
			if(department.getModifiedBy()!=0L) {
				String query11="Select first_name from users where userid ="+department.getModifiedBy();
				Query q1 =  entityManager.createNativeQuery(query11);
				String result1 =  (String)q1.getSingleResult();
				row.createCell(5).setCellValue(result1);
			}else {
			
				row.createCell(5).setCellValue("");
				
			}
			
			if(department.getModifiedDate()!=null && !department.getModifiedDate().equals("") && !department.getModifiedDate().equals("null")) {
				row.createCell(6).setCellValue(formatter.format(department.getModifiedDate()));
			}else {
				row.createCell(6).setCellValue("");
			}
		}
		
		//Auto-size all the above columns
		sheet.autoSizeColumn(0);
		sheet.autoSizeColumn(1);
		sheet.autoSizeColumn(2);
		sheet.autoSizeColumn(3);
		sheet.autoSizeColumn(4);
		sheet.autoSizeColumn(5);
		sheet.autoSizeColumn(6);

		workbook.write(out);
		return new ByteArrayInputStream(out.toByteArray());
	}
}

public  ByteArrayInputStream designationToExcel(List<Designation> desgintaions) throws IOException {
	
	DateTimeFormatter formatter =
		    DateTimeFormatter.ofLocalizedDateTime( FormatStyle.SHORT )
		                     .withLocale( Locale.UK )
		                     .withZone( ZoneId.systemDefault() );
	
	
	String[] COLUMNs = {  "Designation Name", "Status","Created Date", "Created By"
			,"Last Modified By","Last Modified Date" };
	try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
		Sheet sheet = workbook.createSheet("Designations");
		
		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setColor(IndexedColors.BLUE.getIndex());

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFont(headerFont);

		// Header Row
		Row headerRow = sheet.createRow(0);

		// Table Header
		for (int col = 0; col < COLUMNs.length; col++) {
			Cell cell = headerRow.createCell(col);
			cell.setCellValue(COLUMNs[col]);
			cell.setCellStyle(headerCellStyle);
		}

		int rowIdx = 1;
		for (Designation desgintaion : desgintaions) {
			Row row = sheet.createRow(rowIdx++);

			row.createCell(0).setCellValue(desgintaion.getDesignationName());

			if(desgintaion.getActiveStatus() == 0) {
				row.createCell(1).setCellValue("Active");
			}else {
				row.createCell(1).setCellValue("In Active");
			}
			

			if(desgintaion.getCreatedDate()!=null && !desgintaion.getCreatedDate().equals("") && !desgintaion.getCreatedDate().equals("null")) {
					row.createCell(2).setCellValue(formatter.format(desgintaion.getCreatedDate()));
				}else {
					row.createCell(2).setCellValue("");
				}	
			
			if(desgintaion.getCreatedBy()!=0L) {
				  String query1="Select first_name from users where userid = "+desgintaion.getCreatedBy();
				  Query q = entityManager.createNativeQuery(query1); 
				  String result = (String)q.getSingleResult(); row.createCell(3).setCellValue(result);
					}
					else {
						row.createCell(3).setCellValue("");
					}	
			
			
			if(desgintaion.getModifiedBy()!=0L) {
				String query11="Select first_name from users where userid ="+desgintaion.getModifiedBy();
				Query q1 =  entityManager.createNativeQuery(query11);
				String result1 =  (String)q1.getSingleResult();
				row.createCell(4).setCellValue(result1);
			}else {
				String query11="Select first_name from users where userid = "+desgintaion.getCreatedBy();
				
				row.createCell(4).setCellValue("");
				
			}
			
			if(desgintaion.getModifiedDate()!=null && !desgintaion.getModifiedDate().equals("") && !desgintaion.getModifiedDate().equals("null")) {
				row.createCell(5).setCellValue(formatter.format(desgintaion.getModifiedDate()));
			}else {
				row.createCell(5).setCellValue("");
			}
		}
		
		//Auto-size all the above columns
		sheet.autoSizeColumn(0);
		sheet.autoSizeColumn(1);
		sheet.autoSizeColumn(2);
		sheet.autoSizeColumn(3);
		sheet.autoSizeColumn(4);
		sheet.autoSizeColumn(5);

		workbook.write(out);
		return new ByteArrayInputStream(out.toByteArray());
	}
}

public  ByteArrayInputStream speakerstoExcel(List<SpeakerMaster> speakers) throws IOException {
	
	DateTimeFormatter formatter =
		    DateTimeFormatter.ofLocalizedDateTime( FormatStyle.SHORT )
		                     .withLocale( Locale.UK )
		                     .withZone( ZoneId.systemDefault() );
	
	
	String[] COLUMNs = { "Title", "First Name", "Last Name","Organization","Centre","Department","Designation", "Email", "Mobile No"};
	try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
		Sheet sheet = workbook.createSheet("Speakers");
		
		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setColor(IndexedColors.BLUE.getIndex());

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFont(headerFont);

		// Header Row
		Row headerRow = sheet.createRow(0);

		// Table Header
		for (int col = 0; col < COLUMNs.length; col++) {
			Cell cell = headerRow.createCell(col);
			cell.setCellValue(COLUMNs[col]);
			cell.setCellStyle(headerCellStyle);
		}

		int rowIdx = 1;
		for (SpeakerMaster speaker : speakers) {
			Row row = sheet.createRow(rowIdx++);

			row.createCell(0).setCellValue(speaker.getTitle());
			row.createCell(1).setCellValue(speaker.getSpeakerFirstName());
			row.createCell(2).setCellValue(speaker.getSpeakerLastName());
			
			if(speaker.getSpeakerOrganization() !=null) {
				  String query2="Select organization.organization_name from organization, speakers where \r\n"
				  + "organization.organization_id = speakers.organization_id and speakers.id	 = "+speaker.getSpeakerId(); 
				  Query q2 = entityManager.createNativeQuery(query2); String
				  result2 = (String)q2.getSingleResult();
				  row.createCell(3).setCellValue(result2);}
				else {
					row.createCell(3).setCellValue("");
				}
			
			if(speaker.getSpeakerCenter() !=null) {
				  String query2="Select centre.centre_name from centre, speakers where \r\n"
				  + "centre.centre_id = speakers.center_id and speakers.id	 = "+speaker.getSpeakerId(); 
				  Query q2 = entityManager.createNativeQuery(query2); String
				  result2 = (String)q2.getSingleResult();
				  row.createCell(4).setCellValue(result2);}
				else {
					row.createCell(4).setCellValue("");
				}

			
				if(speaker.getSpeakerDepartment() !=null) {
				  String query2="Select department.department_name from department, speakers where \r\n"
				  + "department.department_id = speakers.department_id and speakers.id	 = "+speaker.getSpeakerId(); 
				  Query q2 = entityManager.createNativeQuery(query2); String
				  result2 = (String)q2.getSingleResult();
				  row.createCell(5).setCellValue(result2);}
				else {
					row.createCell(5).setCellValue("");
				}
				  
				if(speaker.getSpeakerDesignation() !=null) {
				  String query3="Select designation.designation_name from rbieventmanagementdb.designation, speakers where \r\n"
				  + "designation.designation_id = speakers.designation_id and speakers.id = "+speaker.getSpeakerId(); 
				  Query q3 = entityManager.createNativeQuery(query3); String
				  result3 = (String)q3.getSingleResult();
				  row.createCell(6).setCellValue(result3);
				} 
				else {
					row.createCell(6).setCellValue("");
				}
				
				row.createCell(7).setCellValue(speaker.getSpeakerEmailId());
				row.createCell(8).setCellValue(speaker.getSpeakerMobileNo());

		}
		
		//Auto-size all the above columns
		sheet.autoSizeColumn(0);
		sheet.autoSizeColumn(1);
		sheet.autoSizeColumn(2);
		sheet.autoSizeColumn(3);
		sheet.autoSizeColumn(4);
		sheet.autoSizeColumn(5);
		sheet.autoSizeColumn(6);
		sheet.autoSizeColumn(7); 
		sheet.autoSizeColumn(8);	 



		workbook.write(out);
		return new ByteArrayInputStream(out.toByteArray());
	}
}

public  ByteArrayInputStream participantstoExcel(List<ParticipantMaster> participants) throws IOException {
	
	DateTimeFormatter formatter =
		    DateTimeFormatter.ofLocalizedDateTime( FormatStyle.SHORT )
		                     .withLocale( Locale.UK )
		                     .withZone( ZoneId.systemDefault() );
	
	
	String[] COLUMNs = { "Title", "First Name", "Last Name","Organization","Centre","Department","Designation", "Email", "Mobile No"};
	try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
		Sheet sheet = workbook.createSheet("Participants");
		
		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setColor(IndexedColors.BLUE.getIndex());

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFont(headerFont);

		// Header Row
		Row headerRow = sheet.createRow(0);

		// Table Header
		for (int col = 0; col < COLUMNs.length; col++) {
			Cell cell = headerRow.createCell(col);
			cell.setCellValue(COLUMNs[col]);
			cell.setCellStyle(headerCellStyle);
		}

		int rowIdx = 1;
		for (ParticipantMaster participant : participants) {
			Row row = sheet.createRow(rowIdx++);

			row.createCell(0).setCellValue(participant.getTitle());
			row.createCell(1).setCellValue(participant.getParticipantFirstName());
			row.createCell(2).setCellValue(participant.getParticipantLastName());
			
			if(participant.getParticipantOrganization() !=null) {
				  String query2="Select organization.organization_name from organization, participants where \r\n"
				  + "organization.organization_id = participants.organization_id and participants.id	 = "+participant.getParticipantId(); 
				  Query q2 = entityManager.createNativeQuery(query2); String
				  result2 = (String)q2.getSingleResult();
				  row.createCell(3).setCellValue(result2);}
				else {
					row.createCell(3).setCellValue("");
				}
			
			if(participant.getParticipantCenter() !=null) {
				  String query2="Select centre.centre_name from centre, participants where \r\n"
				  + "centre.centre_id = participants.center_id and participants.id	 = "+participant.getParticipantId(); 
				  Query q2 = entityManager.createNativeQuery(query2); String
				  result2 = (String)q2.getSingleResult();
				  row.createCell(4).setCellValue(result2);}
				else {
					row.createCell(4).setCellValue("");
				}

			
				if(participant.getParticipantDepartment() !=null) {
				  String query2="Select department.department_name from department, participants where \r\n"
				  + "department.department_id = participants.department_id and participants.id	 = "+participant.getParticipantId(); 
				  Query q2 = entityManager.createNativeQuery(query2); String
				  result2 = (String)q2.getSingleResult();
				  row.createCell(5).setCellValue(result2);}
				else {
					row.createCell(5).setCellValue("");
				}
				  
				if(participant.getParticipantDesignation() !=null) {
				  String query3="Select designation.designation_name from rbieventmanagementdb.designation, participants where \r\n"
				  + "designation.designation_id = participants.designation_id and participants.id = "+participant.getParticipantId(); 
				  Query q3 = entityManager.createNativeQuery(query3); String
				  result3 = (String)q3.getSingleResult();
				  row.createCell(6).setCellValue(result3);
				} 
				else {
					row.createCell(6).setCellValue("");
				}
				
				row.createCell(7).setCellValue(participant.getParticipantEmailId());
				row.createCell(8).setCellValue(participant.getParticipantMobileNo());

		}
		
		//Auto-size all the above columns
		sheet.autoSizeColumn(0);
		sheet.autoSizeColumn(1);
		sheet.autoSizeColumn(2);
		sheet.autoSizeColumn(3);
		sheet.autoSizeColumn(4);
		sheet.autoSizeColumn(5);
		sheet.autoSizeColumn(6);
		sheet.autoSizeColumn(7); 
		sheet.autoSizeColumn(8);	 



		workbook.write(out);
		return new ByteArrayInputStream(out.toByteArray());
	}
}
public  ByteArrayInputStream mobileUserToExcel(List<MobileUsers> mobileUsers) throws IOException {
	
	DateTimeFormatter formatter =
		    DateTimeFormatter.ofLocalizedDateTime( FormatStyle.SHORT )
		                     .withLocale( Locale.UK )
		                     .withZone( ZoneId.systemDefault() );
	
	
	String[] COLUMNs = {"Login Id", "User Name", "Mobile No", "Email Id","Is Event Admin", "Active/InActive"};
	try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
		Sheet sheet = workbook.createSheet("Mobile Users");
		
		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setColor(IndexedColors.BLUE.getIndex());

		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFont(headerFont);

		// Header Row
		Row headerRow = sheet.createRow(0);

		// Table Header
		for (int col = 0; col < COLUMNs.length; col++) {
			Cell cell = headerRow.createCell(col);
			cell.setCellValue(COLUMNs[col]);
			cell.setCellStyle(headerCellStyle);
		}

		int rowIdx = 1;
		for (MobileUsers mobileUser : mobileUsers) {
			Row row = sheet.createRow(rowIdx++);

			row.createCell(0).setCellValue(mobileUser.getUserId());
			row.createCell(1).setCellValue(mobileUser.getUserName());
			row.createCell(2).setCellValue(mobileUser.getUserMobileNo());
			row.createCell(3).setCellValue(mobileUser.getEmail_id());
			if(mobileUser.getIsAdmin() == 0) {
				row.createCell(4).setCellValue("No");
			}else {
				row.createCell(4).setCellValue(" Yes");
			}
			if(mobileUser.getActiveStatus() == 0) {
				row.createCell(5).setCellValue("Active");
			}else {
				row.createCell(5).setCellValue("In Active");
			}

			
		}
		
		//Auto-size all the above columns
		sheet.autoSizeColumn(0);
		sheet.autoSizeColumn(1);
		sheet.autoSizeColumn(2);
		sheet.autoSizeColumn(3);
		sheet.autoSizeColumn(4);
		sheet.autoSizeColumn(5);

		

		workbook.write(out);
		return new ByteArrayInputStream(out.toByteArray());
	}
}
}