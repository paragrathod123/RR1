package com.iftas.eventportal.controller;


import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.iftas.eventportal.dao.UserRepository;
import com.iftas.eventportal.entity.User;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.model.KeyAndPassword;
import com.iftas.eventportal.service.MailService;
import com.iftas.eventportal.service.UserService;

/**
 * 
 * This Class is used for method like reset password,forgot password
 * @author Parag Rathod
 *
 */

@Controller
@RequestMapping("/api")
public class AccountController {

	private final Logger log = LoggerFactory.getLogger(AccountController.class);
	
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private MailService  mailService;
	
	
	@PostMapping("/reset/init")
	public String requestPasswordReset(RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		
		log.debug("Request to request Password Reset ");
		
		String email =request.getParameter("email");
		//Check If email is Present or not
		Optional<User> userWithEmail =  userRepository.findOneByEmailIgnoreCase(email);
		if(!userWithEmail.isPresent()) {
			redirectAttributes.addFlashAttribute("message","No Email Id Found ");
			redirectAttributes.addFlashAttribute("alertClass", Constants.FAILEDALERTCLASS);
			return "redirect:/forgotPassword";
		}
		
		mailService.sendPasswordResetMail(userService.requestPasswordReset(email).get());
		
		redirectAttributes.addFlashAttribute("successMsg","Password reset mail send on registered emailId ");
		redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
		return "redirect:/forgotPassword";
		
	}
	
	@GetMapping("/reset/finish")
	public String getRestPasswordForm(@RequestParam String key
										,Model theModel
										,RedirectAttributes redirectAttributes) {
		log.debug("Request to Rest Password");
		
		//Check if Reset Key is Present
		Optional<User> userWithResetKey =  userRepository.findOneByResetKey(key);
		if(!userWithResetKey.isPresent()) {
			redirectAttributes.addFlashAttribute("message","No Reset Key Found");
			redirectAttributes.addFlashAttribute("alertClass", Constants.FAILEDALERTCLASS);
			return "redirect:/login";
		}
		// create model attribute to bind form data
		KeyAndPassword reset = new KeyAndPassword();
		reset.setKey(key);
		theModel.addAttribute("reset", reset);
		return "front/reset";
	}
	
	@PostMapping("/reset/finish/final")
	public String finishPasswordReset(
			@ModelAttribute("reset") @Valid KeyAndPassword theKeyPassword,
			BindingResult bindingResult,
			RedirectAttributes redirectAttributes
			,HttpServletRequest request
			,Model theModel
			) {
		System.out.println("Hello");
		log.debug("Request to Update Reset Password");
		String message = "";
		boolean isPresent = true;
		if (bindingResult.hasErrors()) {
			redirectAttributes.addFlashAttribute("message","Password size must be between 4 and 100 ");
			redirectAttributes.addFlashAttribute("alertClass", Constants.FAILEDALERTCLASS);
			return "redirect:/api/reset/finish?key="+theKeyPassword.getKey();
		}
		else {
			
			//Check if Reset Key is Present
			Optional<User> userWithResetKey =  userRepository.findOneByResetKey(theKeyPassword.getKey());
			if(!userWithResetKey.isPresent()) {
				message = "No Reset Key Found";
				isPresent = false;
			}
			
			if(isPresent) {
				userWithResetKey =  userService.completePasswordReset(theKeyPassword.getPassword(), theKeyPassword.getKey());
				message=Constants.PASSWORD_RESET_SUCCESSFULLY;
			}
			
		}
		redirectAttributes.addFlashAttribute("message",message);
		redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
		return "redirect:/login";
		
	}
	
	
	
	
	
	
	
}
