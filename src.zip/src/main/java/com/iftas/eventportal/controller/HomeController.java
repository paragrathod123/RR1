package com.iftas.eventportal.controller;


import java.security.Principal;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.iftas.eventportal.dao.EventMasterRepository;
import com.iftas.eventportal.dao.UserRepository;
import com.iftas.eventportal.entity.EventMaster;
import com.iftas.eventportal.entity.ProductMaster;
import com.iftas.eventportal.entity.User;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.model.KeyAndPassword;
import com.iftas.eventportal.security.SecurityUtils;
import com.iftas.eventportal.service.ProductService;
import com.iftas.eventportal.service.UserService;



@Controller
public class HomeController {
	
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	UserService userService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private EventMasterRepository eventMasterRepository ;
	
	private PasswordEncoder passwordEncoder =  new BCryptPasswordEncoder();
	
	@GetMapping({"/","/login"})
	public String login(Model theModel) {
		return "front/login";
		
	}
	
	@GetMapping("/home")
	public String home(Model theModel,HttpServletRequest request) {
		//Here we will have code for Dashboard
		return "front/home";
		
	}
	
	@GetMapping("/403")
    public String accessDenied(Model model, Principal principal) {
    	if (principal != null) {
    		//Get Login User Details
    		Optional<String> loginNames  =  SecurityUtils.getCurrentUserLogin();
    		String loginUser =  loginNames.get();
            model.addAttribute("userInfo", loginUser);
            String message = "Hi " + principal.getName() //
                    + "<br> You do not have permission to access this page!";
            
            model.addAttribute("message", message);
 
        }
        return "front/403Page";
		
	}
	
	
	@GetMapping("/forgotPassword")
	public String getForgotPasswordForm(Model theModel) {
		return "front/forgotPassword";
	}
	
	@GetMapping("/resetPassword/init")
	public String getResetPasswordForm(Model theModel) {
		// create model attribute to bind form data
		KeyAndPassword reset = new KeyAndPassword();
		theModel.addAttribute("reset", reset);
		return "front/resetPassword";
	}
	
	
	@GetMapping("/profile/viewUser")
	public String showFormForUserView(@RequestParam("userId") Long id,Model theModel,HttpServletRequest request) {
		System.out.println("in view user ");
		User user = new User();
		//Get UserTemp by Id
		user =  userService.getUserDetail(id);
		List<ProductMaster> products = productService.getProductList();
		EventMaster theEvent = new EventMaster();
		if(user.getEventId()!=null) {
			Optional<EventMaster> optionalEvent  =  eventMasterRepository.findById(Long.valueOf(user.getEventId()));
			if(optionalEvent.isPresent()) {
				theEvent =  optionalEvent.get();
			}
		}
		theModel.addAttribute("event", theEvent);
		theModel.addAttribute("products", products);
		theModel.addAttribute("user", user);
		return "front/userView";
	}
	
	
	@PostMapping("/resetPassword/final")
	public String finishPasswordReset(
			@ModelAttribute("reset") @Valid KeyAndPassword theKeyPassword,
			BindingResult bindingResult,
			RedirectAttributes redirectAttributes
			,HttpServletRequest request
			) {
		
		String message = "";
		  Optional<String> loginNames  =  SecurityUtils.getCurrentUserLogin();
			
			String loginUser =  loginNames.get();
			
			//Fetch User Details & Set that into new session detail Class for further usages
			Optional<User> users =  userRepository.findOneByLogin(loginUser);
			User user =  users.get();
			boolean isPresent = true;
			if (bindingResult.hasErrors()) {
				return "front/resetPassword";
			}else {
				if(!passwordEncoder.matches(theKeyPassword.getOldPassword(), user.getPasswordHash() )) {
					System.out.println("Password Commparison");
					message = "Current Password is Incorrect";
					redirectAttributes.addFlashAttribute("errorMsg",message);
					isPresent = false;
					return "redirect:/resetPassword/init";
				}
			if(isPresent) {
				    System.out.println("New Password " + theKeyPassword.getPassword());
				    System.out.println("Old Password" + theKeyPassword.getOldPassword());
				    System.out.println("Old Password" + user.getPasswordHash());
					userService.changePassword(theKeyPassword.getPassword());
					message="Password Reset Successful";
			}
			}
			redirectAttributes.addFlashAttribute("message",message);
			redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
			return "redirect:/login";
	
	
	
}

}
