package com.iftas.eventportal.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

import javax.mail.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.iftas.eventportal.dao.EventMasterRepository;
import com.iftas.eventportal.dao.UserRepository;
import com.iftas.eventportal.entity.EventMaster;
import com.iftas.eventportal.entity.ProductMaster;
import com.iftas.eventportal.entity.User;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.service.MailService;
import com.iftas.eventportal.service.ProductService;
import com.iftas.eventportal.service.UserService;
import com.iftas.eventportal.util.GenerateExcelReport;
import com.iftas.eventportal.util.RandomUtil;



@Controller
@RequestMapping("/systemAdmin/users")
@PreAuthorize("hasPermission('','users', 'READ_PRIVILEGE')")
public class UserRegistrationController {

	
	private final Logger log = LoggerFactory.getLogger(UserRegistrationController.class);
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	UserService userService;
	
	@Autowired
	private GenerateExcelReport generateExcelReport;
	
	@Autowired
	private MailService  mailService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private EventMasterRepository eventMasterRepository ;
	
	@GetMapping("/")
	@PreAuthorize("hasPermission('','users', 'READ_PRIVILEGE')")
	public String listUsers(Model theModel,HttpServletRequest request) {
		log.debug("Inside listUsers(Model theModel,HttpServletRequest request)");
		List<User> users =  userService.getUserList();
		//Add to Model
		System.out.println(users.size() + " no. of users ");
		theModel.addAttribute("users", users);
		return "systemAdmin/userList";
		
	}
	
	@GetMapping("/userRegister")
	@PreAuthorize("hasPermission('','users', 'ADD_PRIVILEGE')")
	public String showFormForAdd(Model theModel,HttpServletRequest request) {
		log.debug("Inside UserRegistrationController.showFormForAdd(Model theModel,HttpServletRequest request)");
		User theUser = new User();
		List<ProductMaster> products = productService.getProductList();
		theModel.addAttribute("products", products);
		theModel.addAttribute("user", theUser);
		return "systemAdmin/userRegisterForm";
	}
	
	
	@PostMapping("/createUser")
	@PostAuthorize("hasPermission('','users', 'ADD_PRIVILEGE')")
	public String createTempUser(
			@ModelAttribute("user") @Valid User theUser,
			BindingResult bindingResult
			,@RequestParam("imgInp") MultipartFile readFileFormat
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		HttpSession session =  request.getSession();
		String message = "User activation Link Send Successfully!!";

		log.debug("Request to Add New Temp User "+theUser );
		String errorMsg = "";String successMsg = "";
		boolean sendFlag =  false;
		if (bindingResult.hasErrors()) {
			return "systemAdmin/userRegisterForm";
		}
		else {					
			//Check Whether Login Name & Email Id  already exists
			if(userRepository.findOneByLogin(theUser.getLogin().toLowerCase()).isPresent()) {
				errorMsg = "Login name already used!";
				redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
			}else if(userRepository.findOneByLogin(theUser.getLogin()).isPresent()) {
				errorMsg = "Login name already used!";
				redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
			}else if(userRepository.findOneByEmailIgnoreCase(theUser.getEmail()).isPresent()) {
				errorMsg = "Email is already in use!";
				redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
			}else {
				successMsg =  Constants.ADD_SUCCESSFULLY;
				//Step 1 Check whether record is send for approval/rejection 
				//Step2 save the User
				userService.createUser(theUser, request,readFileFormat);
				redirectAttributes.addFlashAttribute("successMsg",successMsg);
			}
			//Step 3 use a redirect to prevent duplicate submissions & Add Messages
			redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
	
			return "redirect:/systemAdmin/users/";
		}
	
	}
	
	@GetMapping("/editUser")
	@PreAuthorize("hasPermission('','users', 'EDIT_PRIVILEGE')")
	public String showFormForUpdate(@RequestParam("userId") Long id,Model theModel,HttpServletRequest request) {
		System.out.println("in edit user ");
		User user = new User();
		//Get UserTemp by Id
		user =  userService.getUserDetail(id);
		List<ProductMaster> products = productService.getProductList();
		EventMaster theEvent = new EventMaster();
		if(user.getEventId()!=null) {
			Optional<EventMaster> optionalEvent  =  eventMasterRepository.findById(Long.valueOf(user.getEventId()));
			if(optionalEvent.isPresent()) {
				theEvent =  optionalEvent.get();
			}
		}
		theModel.addAttribute("event", theEvent);
		theModel.addAttribute("products", products);
		theModel.addAttribute("user", user);
		return "systemAdmin/userEdit";
	}
	
	@GetMapping("/viewUser")
	public String showFormForUserView(@RequestParam("userId") Long id,Model theModel,HttpServletRequest request) {
		System.out.println("in view user ");
		User user = new User();
		//Get UserTemp by Id
		user =  userService.getUserDetail(id);
		List<ProductMaster> products = productService.getProductList();
		EventMaster theEvent = new EventMaster();
		if(user.getEventId()!=null) {
			Optional<EventMaster> optionalEvent  =  eventMasterRepository.findById(Long.valueOf(user.getEventId()));
			if(optionalEvent.isPresent()) {
				theEvent =  optionalEvent.get();
			}
		}
		theModel.addAttribute("event", theEvent);
		theModel.addAttribute("products", products);
		theModel.addAttribute("user", user);
		return "systemAdmin/userView";
	}
	
	/* systemAdmin/updateUser */
	
	@PostMapping("/updateUser")
	@PostAuthorize("hasPermission('','users', 'EDIT_PRIVILEGE')")
	public String updateUser(
			@ModelAttribute("user") @Valid User theUser,
			BindingResult bindingResult
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			,@RequestParam("imgInp") MultipartFile readFileFormat
			) {
		HttpSession session =  request.getSession();
		String successMsg = "" ,errorMsg="";
				
				//Step2 save the User
				
		boolean isPresentFlag = false;
		boolean sendFlag =  false;
		if (bindingResult.hasErrors()) {
			return "systemAdmin/userEdit";
		}
		else {	
			
			//Check If changes email Or Login already Exists 
			Optional<User> existingUser =  userRepository.findOneByEmailIgnoreCase(theUser.getEmail());
			if(existingUser.isPresent() && (!theUser.getUserId().equals(existingUser.get().getUserId()))) {
				errorMsg = "Email is already in use!";
				isPresentFlag = true;
				redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
			}
			existingUser = userRepository.findOneByLogin(theUser.getLogin().toLowerCase());
			if(existingUser.isPresent() && (!theUser.getUserId().equals(existingUser.get().getUserId()))) {
				errorMsg = "Login name already used!";
				isPresentFlag = true;
				redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
			}
			existingUser = userRepository.findOneByLogin(theUser.getLogin());
			if(existingUser.isPresent() && (!theUser.getUserId().equals(existingUser.get().getUserId()))) {
				errorMsg = "Login name already used!";
				isPresentFlag = true;
				redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
			}
			
			if(!isPresentFlag) {
				successMsg =  Constants.UPDATE_SUCCESSFULLY;
				//Step 1 Check whether record is send for approval/rejection 
				//Step2 save the User
				userService.updateUser(theUser, request,readFileFormat);
				redirectAttributes.addFlashAttribute("successMsg",successMsg);
			}
	
			return "redirect:/systemAdmin/users/";
		}
	
	
	
	}
	@PreAuthorize("hasPermission('','users', 'EXPORT_PRIVILEGE')")
	@GetMapping(value = "/export")
	public ResponseEntity<InputStreamResource> excelCustomersReport() throws IOException {
		List<User> users =  userService.getUserList();
		ByteArrayInputStream in = generateExcelReport.usersToExcel(users);
		// return IO ByteArray(in);
		HttpHeaders headers = new HttpHeaders();
		// set filename in header
		headers.add("Content-Disposition", "attachment; filename=users.xlsx");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}
}	
	
	
	

