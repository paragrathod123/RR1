package com.iftas.eventportal.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.iftas.eventportal.dao.MenuRepository;
import com.iftas.eventportal.dao.RoleRepository;
import com.iftas.eventportal.entity.Centres;
import com.iftas.eventportal.entity.RoleMst;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.service.RoleService;
import com.iftas.eventportal.util.GenerateExcelReport;








@Controller
@RequestMapping("/systemAdmin/roles")
@PreAuthorize("hasPermission('','roles', 'READ_PRIVILEGE')")
public class RoleController {

	private final Logger log = LoggerFactory.getLogger(RoleController.class);
	
	@Autowired
	private RoleService roleService;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private MenuRepository menuRepository;
	
	@Autowired
	private GenerateExcelReport generateExcelReport;
	
	@GetMapping("/")
	@PreAuthorize("hasPermission('','roles', 'READ_PRIVILEGE')")
	public String listRoles(Model theModel) {
		log.debug("Request to List Roles");
		System.out.println("Request To List Roles");
		//Get all display flag 1 records
		List<RoleMst> roles =  roleService.getRoleListing();
		System.out.println("roles.size "+roles.size());
		//Add to Model
		theModel.addAttribute("roles", roles);
		//Redirect
		return "systemAdmin/roles/listroles";
	}
	
	@PreAuthorize("hasPermission('','roles', 'ADD_PRIVILEGE')")
	@GetMapping("/addRole")
	public String showFormForAdd(Model theModel) {
		log.debug("Request to Add New Role");
		RoleMst role = new RoleMst();
		theModel.addAttribute("role", role);
		return "systemAdmin/roles/addrole";
	}
	
	@PostAuthorize("hasPermission('','roles', 'ADD_PRIVILEGE')")
	@PostMapping("/createRole")
	public String createRole(
			@ModelAttribute("role") @Valid RoleMst theRole,
			BindingResult bindingResult,
			@RequestParam(required=false , value = "addbutn") String addFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request)
	{
		log.debug("Request to Add New Role "+theRole);
		String successMsg = "";String errorMsg="";
		if (bindingResult.hasErrors()) {
			return "systemAdmin/roles/addrole";
		}
		else {
			
			if(roleRepository.findByRoleName(request.getParameter("roleName")).isPresent()) {
				errorMsg = "Role name already used!";
				redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
			}else {
				
				successMsg =  Constants.ADD_SUCCESSFULLY;

				roleService.createRole(theRole, request);
				redirectAttributes.addFlashAttribute("successMsg",successMsg);
				
			}
			//Step 3 use a redirect to prevent duplicate submissions & Add Messages
			redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
			return "redirect:/systemAdmin/roles/";
			
		}
	}
	
	
	@PreAuthorize("hasPermission('','roles', 'EDIT_PRIVILEGE')")
	@GetMapping("/editRole")
	public String showFormForUpdate(@RequestParam("roleId") Long id,Model theModel) {
		log.debug("Request to Update Temp User" +id);
		RoleMst role = new RoleMst();
		role = roleService.getRoleDetail(id);
		theModel.addAttribute("role", role);
		return "systemAdmin/roles/updaterole";
	}
	
	@PostAuthorize("hasPermission('','roles', 'EDIT_PRIVILEGE')")
	@PostMapping("/updateRole")
	public String updateTempUser(
			@ModelAttribute("role") @Valid RoleMst theRole,
			BindingResult bindingResult
			,@RequestParam(required=false , value = "updatebutn") String updateFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		
	    log.debug("Request to Update User "+theRole );
		
		String successMsg = "";String errorMsg="";
		boolean isPresentFlag = false;
		boolean sendFlag =  false;
		if (bindingResult.hasErrors()) {
			System.out.println("role in error ");
			return "systemAdmin/roles/updaterole";
		}
		else {	
			
			Optional<RoleMst> existingRole =  roleRepository.findByRoleName(request.getParameter("roleName"));
			if(existingRole.isPresent() && (!theRole.getRoleId().equals(existingRole.get().getRoleId()))) {
				errorMsg = "Role name already used!";
				isPresentFlag = true;
				redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
			}
			if(!isPresentFlag) {
				successMsg =  Constants.UPDATE_SUCCESSFULLY;

				roleService.updateRole(theRole, request);
				redirectAttributes.addFlashAttribute("successMsg",successMsg);
			}
			
			//Step 3 use a redirect to prevent duplicate submissions & Add Messages
			redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
			return "redirect:/systemAdmin/roles/";
		}
		
	}
	
	@GetMapping(value = "/viewRole")
	public String viewCentre(@RequestParam("roleId") Long id,Model theModel,HttpServletRequest request) {
		log.debug("Request to View  Role "+id );
		System.out.println("Request to View  CRoleentre "+id);
		RoleMst role =  roleService.getRoleDetail(id);
		theModel.addAttribute("role", role);
	    return "systemAdmin/roles/viewrole";
	}
	
	@PreAuthorize("hasPermission('','roles', 'EXPORT_PRIVILEGE')")
	@GetMapping(value = "/export")
	public ResponseEntity<InputStreamResource> excelRolesReport() throws IOException {
		System.out.println("Role export");
		List<RoleMst> roles =  roleService.getRoleListing();
		ByteArrayInputStream in = generateExcelReport.rolesToExcel(roles);
		// return IO ByteArray(in);
		HttpHeaders headers = new HttpHeaders();
		// set filename in header
		headers.add("Content-Disposition", "attachment; filename=roles.xlsx");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

}
