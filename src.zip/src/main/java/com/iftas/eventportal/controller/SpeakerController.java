package com.iftas.eventportal.controller;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.iftas.eventportal.dao.EventMasterRepository;
import com.iftas.eventportal.dao.EventSpeakerRepository;
import com.iftas.eventportal.dao.SpeakersRepository;
import com.iftas.eventportal.entity.Centres;
import com.iftas.eventportal.entity.EventMaster;
import com.iftas.eventportal.entity.SpeakerMaster;
import com.iftas.eventportal.entity.User;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.service.CentreService;
import com.iftas.eventportal.service.SpeakerService;
import com.iftas.eventportal.util.GenerateExcelReport;

@Controller
@RequestMapping("/report/speakers")
@PreAuthorize("hasPermission('','speakers', 'READ_PRIVILEGE')")
public class SpeakerController {
	
	private final Logger log = LoggerFactory.getLogger(SpeakerController.class);
	
	
	@Autowired
	private SpeakerService speakerService;
	
	@Autowired
	private SpeakersRepository speakersRepository;
	
	@Autowired
	private GenerateExcelReport generateExcelReport;
	
	@Autowired
	private EventSpeakerRepository eventSpeakerRepository;
	
	@RequestMapping("/")
	@PreAuthorize("hasPermission('','speakers', 'READ_PRIVILEGE')")
	public String listSpeakers(Model theModel, HttpServletRequest request) {
		log.debug("Request to list Speakers");
		List<SpeakerMaster> speaker = new ArrayList<SpeakerMaster>();
		
		HttpSession session =  request.getSession();
		if(Integer.parseInt((String)session.getAttribute("markerType")) == 1) {
			if(session.getAttribute("eventid")!=null && !session.getAttribute("eventid").equals("") && !session.getAttribute("eventid").equals("null")) {
				speaker = eventSpeakerRepository.findAllSpeakerByEventId(Long.valueOf((String)session.getAttribute("eventid")));
			}
		}else {
			speaker = speakerService.getSpeakerList();
		}
		
	    theModel.addAttribute("speaker", speaker);
	    return "Event/speakers/listSpeakers";
	}
	
	
	@GetMapping("/uploadSpeaker")
	@PreAuthorize("hasPermission('','speakers', 'ADD_PRIVILEGE')")
	public String showFormForUpload(Model theModel) {
		log.debug("Request to Upload new Speakers");
		SpeakerMaster speakers = new SpeakerMaster();
		theModel.addAttribute("speakers", speakers);
		return "Event/speakers/uploadSpeaker";
	}
	
	
	@PostMapping("/import")
	@PostAuthorize("hasPermission('','speakers', 'ADD_PRIVILEGE')")
	public String mapReapExcelDatatoDB(@RequestParam("file") MultipartFile reapExcelDataFile,Model theModel,RedirectAttributes redirectAttributes,HttpServletRequest request) throws IOException {
		log.debug("Request to Uploading new Speakers");
		String succesMessage=""; 
		succesMessage = Constants.UPLOAD_SUCCESSFULLY;
		speakerService.uploadSpeakers(reapExcelDataFile, request);
		redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
		return "redirect:/report/speakers/";
	}
	
	@GetMapping("/addSpeaker")
	@PreAuthorize("hasPermission('','speakers', 'ADD_PRIVILEGE')")
	public String showFormForAdd(Model theModel) {
		log.debug("Request to Add new Speaker");
		SpeakerMaster speaker = new SpeakerMaster();
		theModel.addAttribute("speaker", speaker);
		return "Event/speakers/addSpeaker";
	}
	
	
	@PostMapping("/createSpeaker")
	@PostAuthorize("hasPermission('','speakers', 'ADD_PRIVILEGE')")
	public String createSpeaker(
			 @ModelAttribute("speaker") @Valid SpeakerMaster theSpeaker
			,BindingResult bindingResult
			,@RequestParam(required=false, value="addbutn") String addFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			,@RequestParam("imgInpSpeaker") MultipartFile readFileFormat
			) {
		System.out.println("Request to Add new Speaker" + theSpeaker);
		String succesMessage=""; String errorMessage="";
		if(bindingResult.hasErrors()) {
			return "/Event/speakers/addSpeaker";
		}
		else {
			
			if(speakersRepository.findOneBySpeakerEmailIdIgnoreCase(theSpeaker.getSpeakerEmailId()).isPresent()) {
				errorMessage = "Email is already in use!";
				redirectAttributes.addFlashAttribute("errorMsg",errorMessage);
			}else {
				succesMessage = Constants.ADD_SUCCESSFULLY;
				speakerService.creatSpeaker(theSpeaker, readFileFormat, request);
				redirectAttributes.addFlashAttribute("succesMessage", succesMessage);
			}
			//Step 3 use a redirect to prevent duplicate submissions & Add Messages
			redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
			return "redirect:/report/speakers/";
				
		}
   }
	
	
   
	@GetMapping("/editSpeaker")
	@PreAuthorize("hasPermission('','speakers', 'EDIT_PRIVILEGE')")
	public String showFormForUpdate(@RequestParam("speakerId") Long id,Model theModel,HttpServletRequest request) {
		System.out.println("In Edit speaker ");
		SpeakerMaster speakers = new SpeakerMaster();
		speakers =  speakerService.getSpeakerById(id);
		theModel.addAttribute("speaker", speakers);
		return "Event/speakers/editSpeaker";
	}
	
	
	
	
	@PostMapping("/updateSpeaker")
	@PostAuthorize("hasPermission('','speakers', 'EDIT_PRIVILEGE')")
	public String updateSpeaker(
			@ModelAttribute("speaker") @Valid SpeakerMaster theSpeaker,
			BindingResult bindingResult
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			,@RequestParam("imgInp") MultipartFile readFileFormat
			) {
		HttpSession session =  request.getSession();
		String successMsg = "" ,errorMsg="";
		boolean isPresentFlag = false;
		boolean sendFlag =  false;
		if (bindingResult.hasErrors()) {
			return "/Event/speakers/editSpeaker";
		}
		else {	
			
			//Check If changes email already Exists 
			Optional<SpeakerMaster> existingSpeaker =  speakersRepository.findOneBySpeakerEmailIdIgnoreCase(theSpeaker.getSpeakerEmailId());
			if(existingSpeaker.isPresent() && (!theSpeaker.getSpeakerId().equals(existingSpeaker.get().getSpeakerId()))) {
				errorMsg = "Email is already in use!";
				isPresentFlag = true;
				redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
			}
			if(!isPresentFlag) {
				successMsg =  Constants.UPDATE_SUCCESSFULLY;
				//Step1 save the Speaker
				speakerService.updateSpeaker(theSpeaker, request,readFileFormat);
				redirectAttributes.addFlashAttribute("successMsg",successMsg);
			}
	
			return "redirect:/report/speakers/";
		}
	
	
	
	}
	
	
	@GetMapping("/viewSpeaker")
	public String showFormForUserView(@RequestParam("speakerId") Long id,Model theModel,HttpServletRequest request) {
		System.out.println("in view speaker ");
		SpeakerMaster speakers = new SpeakerMaster();
		speakers =  speakerService.getSpeakerById(id);
		theModel.addAttribute("speaker", speakers);
		return "Event/speakers/viewSpeaker";
	}
	
	
	@PreAuthorize("hasPermission('','speakers', 'EXPORT_PRIVILEGE')")
	@GetMapping(value = "/export")
	public ResponseEntity<InputStreamResource> excelRolesReport(HttpServletRequest request) throws IOException{
        List<SpeakerMaster> speaker = new ArrayList<SpeakerMaster>();
		
		HttpSession session =  request.getSession();
		if(Integer.parseInt((String)session.getAttribute("markerType")) == 1) {
			if(session.getAttribute("eventid")!=null && !session.getAttribute("eventid").equals("") && !session.getAttribute("eventid").equals("null")) {
				speaker = eventSpeakerRepository.findAllSpeakerByEventId(Long.valueOf((String)session.getAttribute("eventid")));
			}
		}else {
			speaker = speakerService.getSpeakerList();
		}
		ByteArrayInputStream in = generateExcelReport.speakerstoExcel(speaker);
		
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=speakers.xlsx");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}
	
	
	@GetMapping("/downloadTemplate")
    public void fileDownload(@RequestParam("url") String url, Model theModel,HttpServletRequest request,HttpServletResponse response ) throws IOException {
        //System.out.println("in file download  event ");
       System.out.println("url "+url);
        HttpSession session =  request.getSession();
        String filePath = (String)session.getAttribute("pathUrl");
        //System.out.println(filePath + url);
        
        File file = new File(filePath + url);
        if (file.exists()) {

             //get the mimetype
             String mimeType = URLConnection.guessContentTypeFromName(file.getName());
             if (mimeType == null) {
                  //unknown mimetype so set the mimetype to application/octet-stream
                  mimeType = "application/octet-stream";
             }

             response.setContentType(mimeType);

             //Here we have mentioned it to show as attachment
             response.setHeader("Content-Disposition", String.format("attachment; filename=\"" + file.getName() + "\""));

             response.setContentLength((int) file.length());

             InputStream inputStream = new BufferedInputStream(new FileInputStream(file));

             FileCopyUtils.copy(inputStream, response.getOutputStream());
        }
    }

	
	
	
	
	

}
