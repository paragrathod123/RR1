package com.iftas.eventportal.controller;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.iftas.eventportal.dao.EventParticipantRepository;
import com.iftas.eventportal.dao.ParticipantRepository;
import com.iftas.eventportal.entity.ParticipantMaster;
import com.iftas.eventportal.entity.SpeakerMaster;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.service.ParticipantService;
import com.iftas.eventportal.util.GenerateExcelReport;

@Controller
@RequestMapping("/report/participants")
@PreAuthorize("hasPermission('','participants', 'READ_PRIVILEGE')")
public class ParticipantController {
	
	
	private final Logger log = LoggerFactory.getLogger(ParticipantController.class);
	
	@Autowired
	private ParticipantRepository participantRepository;
	
	@Autowired
	private ParticipantService participantService;
	
	@Autowired
	private GenerateExcelReport generateExcelReport;
	
	@Autowired
	private EventParticipantRepository eventParticipantRepository;
	
	
	@RequestMapping("/")
	@PreAuthorize("hasPermission('','participants', 'READ_PRIVILEGE')")
	public String listSpeakers(Model theModel, HttpServletRequest request) {
		log.debug("Request to list Participants");
		List<ParticipantMaster> participants = new ArrayList<ParticipantMaster>();
		HttpSession session =  request.getSession();
		if(Integer.parseInt((String)session.getAttribute("markerType")) == 1) {
			if(session.getAttribute("eventid")!=null && !session.getAttribute("eventid").equals("") && !session.getAttribute("eventid").equals("null")) {
				participants = eventParticipantRepository.findAllParticipantByEventId(Long.valueOf((String)session.getAttribute("eventid")));
			}
		}else {
			participants = participantService.getParticipantList();
		}
	    theModel.addAttribute("participants", participants);
	    return "Event/participants/listParticipants";
	}
	
	
	@GetMapping("/uploadParticipant")
	@PreAuthorize("hasPermission('','participants', 'ADD_PRIVILEGE')")
	public String showFormForUpload(Model theModel) {
		log.debug("Request to Upload new Participant");
		ParticipantMaster participants = new ParticipantMaster();
		theModel.addAttribute("participants", participants);
		return "Event/participants/uploadParticipants";
	}
	
	
	@PostMapping("/import")
	@PostAuthorize("hasPermission('','participants', 'ADD_PRIVILEGE')")
	public String mapReapExcelDatatoDB(@RequestParam("file") MultipartFile reapExcelDataFile,Model theModel,RedirectAttributes redirectAttributes,HttpServletRequest request) throws IOException {
		log.debug("Request to Uploading new Participant");
		String succesMessage=""; 
		succesMessage = Constants.UPLOAD_SUCCESSFULLY;
		participantService.uploadParticipants(reapExcelDataFile, request);
		redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
		return "redirect:/report/participants/";
	}
	
	
	
	@GetMapping("/addParticipant")
	@PreAuthorize("hasPermission('','participants', 'ADD_PRIVILEGE')")
	public String showFormForAdd(Model theModel) {
		log.debug("Request to Add new Participant");
		ParticipantMaster participant = new ParticipantMaster();
		theModel.addAttribute("participant", participant);
		return "Event/participants/addParticipant";
	}
	
	
	@PostMapping("/createParticipant")
	@PostAuthorize("hasPermission('','participants', 'ADD_PRIVILEGE')")
	public String createParticipant(
			 @ModelAttribute("participant") @Valid ParticipantMaster theParticipant
			,BindingResult bindingResult
			,@RequestParam(required=false, value="addbutn") String addFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			,@RequestParam("imgInp") MultipartFile readFileFormat
			) {
		System.out.println("Request to Add new Participant" + theParticipant);
		String succesMessage=""; String errorMessage="";
		if(bindingResult.hasErrors()) {
			return "/Event/participants/addParticipant";
		}
		else {
			
			if(participantRepository.findOneByParticipantEmailIdIgnoreCase(theParticipant.getParticipantEmailId()).isPresent()) {
				errorMessage = "Email is already in use!";
				redirectAttributes.addFlashAttribute("errorMsg",errorMessage);
			}else {
				succesMessage = Constants.ADD_SUCCESSFULLY;
				participantService.creatParticipant(theParticipant, readFileFormat, request);
				redirectAttributes.addFlashAttribute("succesMessage", succesMessage);
			}
			//Step 3 use a redirect to prevent duplicate submissions & Add Messages
			redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
			return "redirect:/report/participants/";
				
		}
   }
	
	
   
	@GetMapping("/editParticipant")
	@PreAuthorize("hasPermission('','participants', 'EDIT_PRIVILEGE')")
	public String showFormForUpdate(@RequestParam("participantId") Long id,Model theModel,HttpServletRequest request) {
		System.out.println("In Edit Participant ");
		ParticipantMaster participant = new ParticipantMaster();
		participant =  participantService.getParticipantById(id);
		theModel.addAttribute("participant", participant);
		return "Event/participants/editParticipant";
	}
	
	
	
	
	@PostMapping("/updateParticipant")
	@PostAuthorize("hasPermission('','participants', 'EDIT_PRIVILEGE')")
	public String updateParticipant(
			@ModelAttribute("participant") @Valid ParticipantMaster theParticipant,
			BindingResult bindingResult
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			,@RequestParam("imgInp") MultipartFile readFileFormat
			) {
		HttpSession session =  request.getSession();
		String successMsg = "" ,errorMsg="";
		boolean isPresentFlag = false;
		boolean sendFlag =  false;
		if (bindingResult.hasErrors()) {
			return "/Event/participants/editParticipant";
		}
		else {	
			
			//Check If changes email already Exists 
			Optional<ParticipantMaster> existingParticipant =  participantRepository.findOneByParticipantEmailIdIgnoreCase(theParticipant.getParticipantEmailId());
			if(existingParticipant.isPresent() && (!theParticipant.getParticipantId().equals(existingParticipant.get().getParticipantId()))) {
				errorMsg = "Email is already in use!";
				isPresentFlag = true;
				redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
			}
			if(!isPresentFlag) {
				successMsg =  Constants.UPDATE_SUCCESSFULLY;
				//Step1 save the Participant
				participantService.updateParticipant(theParticipant, request,readFileFormat);
				redirectAttributes.addFlashAttribute("successMsg",successMsg);
			}
	
			return "redirect:/report/participants/";
		}
	
	
	
	}
	
	
	@GetMapping("/viewParticipant")
	public String showFormForUserView(@RequestParam("participantId") Long id,Model theModel,HttpServletRequest request) {
		System.out.println("in view Participant ");
		ParticipantMaster participant = new ParticipantMaster();
		participant =  participantService.getParticipantById(id);
		theModel.addAttribute("participant", participant);
		return "Event/participants/viewParticipant";
	}
	
	@PreAuthorize("hasPermission('','participants', 'EXPORT_PRIVILEGE')")
	@GetMapping(value = "/export")
	public ResponseEntity<InputStreamResource> excelRolesReport(HttpServletRequest request) throws IOException{
		List<ParticipantMaster> participants = new ArrayList<ParticipantMaster>();
		HttpSession session =  request.getSession();
		if(Integer.parseInt((String)session.getAttribute("markerType")) == 1) {
			if(session.getAttribute("eventid")!=null && !session.getAttribute("eventid").equals("") && !session.getAttribute("eventid").equals("null")) {
				participants = eventParticipantRepository.findAllParticipantByEventId(Long.valueOf((String)session.getAttribute("eventid")));
			}
		}else {
			participants = participantService.getParticipantList();
		}
		ByteArrayInputStream in = generateExcelReport.participantstoExcel(participants);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=participants.xlsx");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}
	
	
	
	@GetMapping("/downloadTemplate")
    public void fileDownload(@RequestParam("url") String url, Model theModel,HttpServletRequest request,HttpServletResponse response ) throws IOException {
        //System.out.println("in file download  event ");
       System.out.println("url "+url);
        HttpSession session =  request.getSession();
        String filePath = (String)session.getAttribute("pathUrl");
        //System.out.println(filePath + url);
        
        File file = new File(filePath + url);
        if (file.exists()) {

             //get the mimetype
             String mimeType = URLConnection.guessContentTypeFromName(file.getName());
             if (mimeType == null) {
                  //unknown mimetype so set the mimetype to application/octet-stream
                  mimeType = "application/octet-stream";
             }

             response.setContentType(mimeType);

             //Here we have mentioned it to show as attachment
             response.setHeader("Content-Disposition", String.format("attachment; filename=\"" + file.getName() + "\""));

             response.setContentLength((int) file.length());

             InputStream inputStream = new BufferedInputStream(new FileInputStream(file));

             FileCopyUtils.copy(inputStream, response.getOutputStream());
        }
    }
	
	
	
	
	
	
	
	
	

}
