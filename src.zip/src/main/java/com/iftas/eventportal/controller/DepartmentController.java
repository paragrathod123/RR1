package com.iftas.eventportal.controller;


import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.iftas.eventportal.dao.DepartmentRepository;
import com.iftas.eventportal.entity.Department;
import com.iftas.eventportal.entity.Organization;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.service.DepartmentService;
import com.iftas.eventportal.util.GenerateExcelReport;




@Controller
@RequestMapping("/Masters/department")
@PreAuthorize("hasPermission('','department', 'READ_PRIVILEGE')")
public class DepartmentController {
	private final Logger log = LoggerFactory.getLogger(DepartmentController.class);
	
	@Autowired
	DepartmentRepository departmentRepository;
	
	@Autowired
	DepartmentService departmentService;
	
	@Autowired
	private GenerateExcelReport generateExcelReport;
	
	@GetMapping("/")
	@PreAuthorize("hasPermission('','department', 'READ_PRIVILEGE')")
	public String listDepartment(Model theModel, HttpServletRequest request) {
		log.debug("Request to list Department");
		System.out.println("Request to list Department");
		List<Department> department = departmentService.getDepartmentListing();
	    theModel.addAttribute("department", department);
	    return "Event/department/listDepartment";
	}
	
	@GetMapping("/addDepartment")
	@PreAuthorize("hasPermission('','department', 'ADD_PRIVILEGE')")
	public String showFormForAdd(Model theModel) {
		log.debug("Request to Add new Department");
		System.out.println("Request to Add new Department");
		Department department = new Department();
		theModel.addAttribute("department", department);
		return "Event/department/addDepartment";
	}
	
	@PostMapping("/createDepartment")
	@PostAuthorize("hasPermission('','department', 'ADD_PRIVILEGE')")
	public String createDepartment(
			@ModelAttribute("department") @Valid Department theDepartment
			,BindingResult bindingResult
			,@RequestParam(required=false, value="addbutn") String addFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		
		log.debug("Request to Add new Department" + theDepartment);
		System.out.println("Request to Add new Department" + theDepartment);
		String succesMessage=""; String errorMessage="";
		if(bindingResult.hasErrors()) {
			return "/Event/department/addDepartment";
		}
		else {
			if(departmentRepository.findByDepartmentCode(request.getParameter("departmentCode")).isPresent()) {
				System.out.println("Department already exists");
				errorMessage = "Department already exists";
				redirectAttributes.addFlashAttribute("errorMessage", errorMessage);
			}else {
				succesMessage = Constants.ADD_SUCCESSFULLY;
				departmentService.createDepartment(theDepartment,request);
				redirectAttributes.addFlashAttribute("successMessage", succesMessage);
			}
		}

		redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
		return "redirect:/Masters/department/";
}
	@GetMapping(value = "/viewDepartment")
	public String viewDepartment(@RequestParam("departmentId") Long id,Model theModel,HttpServletRequest request) {
		log.debug("Request to View  Department "+id );
		System.out.println("Request to View  Department "+id);
		Department department =  departmentService.getDepartmentById(id);
		theModel.addAttribute("department", department);
	    return "Event/department/viewdepartment";
	}
	
	@GetMapping("/editDepartment")
	@PreAuthorize("hasPermission('','department', 'EDIT_PRIVILEGE')")
	public String showFormForUpdate(@RequestParam("departmentId") Long id,Model theModel, HttpServletRequest request) {
		log.debug("Request to Update Department" +id);
		System.out.println("Request to Update Department" +id);
		Department department = new Department();
		//Get UserTemp by Id
		department =  departmentService.getDepartmentById(id);
		theModel.addAttribute("department", department);
		return "Event/department/updatedepartment";
	}
	
	
	@PostMapping("/updateDepartment")
	@PostAuthorize("hasPermission('','department', 'EDIT_PRIVILEGE')")
	public String updateDepartment(
			@ModelAttribute("department") @Valid Department theDepartment,
			BindingResult bindingResult
			,@RequestParam(required=false , value = "updatebutn") String updateFlag
			,@RequestParam(required=false , value = "updateandsendbutn") String updateSendFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		log.debug("Request to Update Department "+theDepartment );
		System.out.println("Request to Update Department "+theDepartment );
		String successMessage = ""; String errorMessage="";
		boolean isPresentFlag = false;
		if (bindingResult.hasErrors()) {
			return "Event/department/updatedepartment";
		}
		else {	
			Optional<Department> existingDepartment =  departmentRepository.findByDepartmentCode(theDepartment.getDepartmentCode());
			if(existingDepartment.isPresent() && (!theDepartment.getDepartmentId().equals(existingDepartment.get().getDepartmentId()))) {
				errorMessage = "Department Code Already Taken!";
				redirectAttributes.addFlashAttribute("errorMessage",errorMessage);
				isPresentFlag = true;
			}
			existingDepartment = departmentRepository.findByDepartmentNameIgnoreCase(theDepartment.getDepartmentName());
			if(existingDepartment.isPresent() && (!theDepartment.getDepartmentId().equals(existingDepartment.get().getDepartmentId()))) {
				errorMessage = "Department Already Present!";
				redirectAttributes.addFlashAttribute("errorMessage",errorMessage);
				isPresentFlag = true;
			}
			existingDepartment= departmentRepository.findByDepartmentName(theDepartment.getDepartmentName().toLowerCase());
			if(existingDepartment.isPresent() && (!theDepartment.getDepartmentId().equals(existingDepartment.get().getDepartmentId()))) {
				errorMessage = "Department Already Present!";
				redirectAttributes.addFlashAttribute("errorMessage",errorMessage);
				isPresentFlag = true;
			}
			
			if(!isPresentFlag) {
				successMessage =  Constants.UPDATE_SUCCESSFULLY;
				//Step2 save the Holiday
				departmentService.updateDepartment(theDepartment, request);
				redirectAttributes.addFlashAttribute("successMessage",successMessage);
			}
	

			return "redirect:/Masters/department/";
		}
	}
	
	@GetMapping(value = "/export")
	@PreAuthorize("hasPermission('','department', 'EXPORT_PRIVILEGE')")
	public ResponseEntity<InputStreamResource> excelCommonSetupReport() throws IOException {
		List<Department> department =  departmentService.getDepartmentListing();
		ByteArrayInputStream in = generateExcelReport.departmentToExcel(department);
		// return IO ByteArray(in);
		HttpHeaders headers = new HttpHeaders();
		// set filename in header
		headers.add("Content-Disposition", "attachment; filename=department.xlsx");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}
}