package com.iftas.eventportal.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.iftas.eventportal.dao.CentreRepository;
import com.iftas.eventportal.entity.Centres;
import com.iftas.eventportal.entity.Department;
import com.iftas.eventportal.entity.Organization;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.service.CentreService;
import com.iftas.eventportal.util.GenerateExcelReport;

@Controller
@RequestMapping("/Masters/centre")
@PreAuthorize("hasPermission('','centre', 'READ_PRIVILEGE')")
public class CentreController {
	private final Logger log = LoggerFactory.getLogger(CentreController.class);
	
	@Autowired
	private CentreService centreService;
	
	@Autowired
	private GenerateExcelReport generateExcelReport;
	
	@Autowired
	private CentreRepository centreRepository;;
	
	@RequestMapping("/")
	public String listCentre(Model theModel, HttpServletRequest request) {
		log.debug("Request to list Centre");
		System.out.println("Request to list Centre");
		List<Centres> centre = centreService.getCentreList();
	    theModel.addAttribute("centre", centre);
	    return "Event/centre/listCentre";
	}
	
	@GetMapping("/addCentre")
	@PreAuthorize("hasPermission('','centre', 'ADD_PRIVILEGE')")
	public String showFormForAdd(Model theModel) {
		log.debug("Request to Add new Centre");
		System.out.println("Request to Add new Centre");
		Centres centre = new Centres();
		theModel.addAttribute("centre", centre);
		return "Event/centre/addCentre";
	}
	
	@PostMapping("/createCentre")
	@PostAuthorize("hasPermission('','centre', 'ADD_PRIVILEGE')")
	public String createCentre(
			@ModelAttribute("centre") @Valid Centres theCentres
			,BindingResult bindingResult
			,@RequestParam(required=false, value="addbutn") String addFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		
		log.debug("Request to Add new Centre" + theCentres);
		System.out.println("Request to Add new Centre" + theCentres);
		String succesMessage=""; String errorMessage="";
		if(bindingResult.hasErrors()) {
			return "/Event/centre/addCentre";
		}
		else {
			if(centreRepository.findByCentreName(request.getParameter("centreName")).isPresent()) {
				System.out.println("Centre Name already exists");
				errorMessage = "Centre Name already exists";
				redirectAttributes.addFlashAttribute("errorMessage", errorMessage);
			}else {
				succesMessage = Constants.ADD_SUCCESSFULLY;
				centreService.creatCentres(theCentres, request);
				redirectAttributes.addFlashAttribute("succesMessage", succesMessage);
			}
		}
		redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
		return "redirect:/Masters/centre/";
		
}
	@GetMapping(value = "/viewCentre")
	public String viewCentre(@RequestParam("centreId") Long id,Model theModel,HttpServletRequest request) {
		log.debug("Request to View  Centre "+id );
		System.out.println("Request to View  Centre "+id);
		Centres centre =  centreService.getCentreById(id);
		theModel.addAttribute("centre", centre);
	    return "Event/centre/viewcentre";
	}
	
	@GetMapping("/editCentre")
	@PreAuthorize("hasPermission('','centre', 'EDIT_PRIVILEGE')")
	public String showFormForUpdate(@RequestParam("centreId") Long id,Model theModel, HttpServletRequest request) {
		log.debug("Request to Update Centre" +id);
		System.out.println("Request to Update  Centre "+id);
		Centres centre = new Centres();
		//Get UserTemp by Id
		centre =  centreService.getCentreById(id);
		theModel.addAttribute("centre", centre);
		return "Event/centre/updatecentre";
	}
	
	
	@PostMapping("/updateCentre")
	@PostAuthorize("hasPermission('','centre', 'EDIT_PRIVILEGE')")
	public String updateCentre(
			@ModelAttribute("centre") @Valid Centres thCentres,
			BindingResult bindingResult
			,@RequestParam(required=false , value = "updatebutn") String updateFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		log.debug("Request to Update Centres "+thCentres );
		System.out.println("Request to Update Centres "+thCentres);
		String successMessage = ""; String errorMessage="";
		boolean isPresentFlag = false;
		if (bindingResult.hasErrors()) {
			return "Event/centre/updatecentre";
		}
		else {
			Optional<Centres> existingCentre =  centreRepository.findByCentreName(thCentres.getCentreName());
			if(existingCentre.isPresent() && (!thCentres.getCentreId().equals(existingCentre.get().getCentreId()))) {
				System.out.println("Centre Name already exists");
				errorMessage = "Centre Name already exists";
				redirectAttributes.addFlashAttribute("errorMessage", errorMessage);
				isPresentFlag=true;
			}
			existingCentre= centreRepository.findByCentreName(thCentres.getCentreName().toLowerCase());
			if(existingCentre.isPresent() && (!thCentres.getCentreId().equals(existingCentre.get().getCentreId()))) {
				System.out.println("Centre Name already exists");
				errorMessage = "Centre Name already exists";
				redirectAttributes.addFlashAttribute("errorMessage", errorMessage);
				isPresentFlag=true;
			}
			if(!isPresentFlag) {
				successMessage =  Constants.UPDATE_SUCCESSFULLY;
				centreService.updateCentres(thCentres, request);
				redirectAttributes.addFlashAttribute("successMessage",successMessage);
			}
	

			return "redirect:/Masters/centre/";
	}
	}
	
	@GetMapping(value = "/export")
	@PreAuthorize("hasPermission('','centre', 'EXPORT_PRIVILEGE')")
	public ResponseEntity<InputStreamResource> excelCommonSetupReport() throws IOException {
		List<Centres> centre =  centreService.getCentreList();
		ByteArrayInputStream in = generateExcelReport.centreToExcel(centre);
		// return IO ByteArray(in);
		HttpHeaders headers = new HttpHeaders();
		// set filename in header
		headers.add("Content-Disposition", "attachment; filename=centre.xlsx");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}
}
