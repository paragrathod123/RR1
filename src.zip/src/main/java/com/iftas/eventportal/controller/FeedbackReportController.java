package com.iftas.eventportal.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.iftas.eventportal.dao.EventSpeakerRepository;
import com.iftas.eventportal.entity.Department;
import com.iftas.eventportal.entity.EventFeedbackReport;
import com.iftas.eventportal.entity.EventMaster;
import com.iftas.eventportal.entity.EventSessionFeedback;
import com.iftas.eventportal.entity.EventSpeakers;
import com.iftas.eventportal.entity.SpeakerMaster;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.service.DepartmentService;
import com.iftas.eventportal.service.EventFeedbackService;
import com.iftas.eventportal.service.EventService;
import com.iftas.eventportal.service.SpeakerService;
import com.iftas.eventportal.util.GenerateExcelReport;

@Controller
public class FeedbackReportController {

	@Autowired
	private GenerateExcelReport generateExcelReport;
	
	@Autowired
	private EventFeedbackService eventFeedbackService;
	
	@Autowired
	private DepartmentService departmentService;
	
	@Autowired
	private EventService eventService;
	
	@Autowired
	private SpeakerService speakerService;
	
	@Autowired
	private EventSpeakerRepository eventSpeakerRepository;
	
	@GetMapping("report/feedbackForm")
	public String feedbackForm(
			@ModelAttribute("feedback") EventSessionFeedback theFeedback,
			BindingResult bindingResult
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			,Model theModel) {
		
		HttpSession session =  request.getSession();
		List<Department> departments = new ArrayList<Department>();
		if(session.getAttribute("markerType")!=null && !session.getAttribute("markerType").equals("") && !session.getAttribute("markerType").equals("null")) {
			//System.out.println("0000 "+session.getAttribute("markerType"));
			if(Integer.parseInt((String)session.getAttribute("markerType")) == 0) {
				departments = departmentService.getDepartmentListingByActiveStatus(0);
				//System.out.println("00001 "+departments.size());
			}
			if(Integer.parseInt((String)session.getAttribute("markerType")) == 1) {
				if(session.getAttribute("departmentid")!=null && !session.getAttribute("departmentid").equals("") && !session.getAttribute("departmentid").equals("null")) {
					Department depa = departmentService.getDepartmentById(Long.valueOf((String)session.getAttribute("departmentid")));
					
					departments.add(depa);
				}
			}
		}
		List<EventMaster> theEvents = new ArrayList<EventMaster>();
		if(session.getAttribute("markerType")!=null && !session.getAttribute("markerType").equals("") && !session.getAttribute("markerType").equals("null")) {
			//System.out.println("0000 "+session.getAttribute("markerType"));
			if(Integer.parseInt((String)session.getAttribute("markerType")) == 0) {
				theEvents = eventService.getEventList();
				//System.out.println("00001 "+departments.size());
			}
			if(Integer.parseInt((String)session.getAttribute("markerType")) == 1) {
				if(session.getAttribute("eventid")!=null && !session.getAttribute("eventid").equals("") && !session.getAttribute("eventid").equals("null")) {
					EventMaster event = eventService.getEventListbyId(Long.valueOf((String)session.getAttribute("eventid")));
					theEvents.add(event);
				}
			}
		}
	
		
		
		
		 // List<EventFeedbackReport> eventFeedbackReportList = new ArrayList<EventFeedbackReport>(); 
		  //if(theFeedback!=null) {
		  //System.out.println(theFeedback.getDepartmentId());
		  //System.out.println(theFeedback.getRatingName()); eventFeedbackReportList = eventFeedbackService.getFeedbackReport(theFeedback, request); }
		 //theModel.addAttribute("eventReportList", eventFeedbackReportList);
		 
		  theModel.addAttribute("departments", departments);
		  theModel.addAttribute("events", theEvents); 
		  //theModel.addAttribute("speakers",theSpeaker);
		 
		return "reports/feedbackReportForm";
	}
	
	
	@GetMapping("/report/feedbackReport")
	@ResponseBody
	public List<EventFeedbackReport> feedbackReport(
			@ModelAttribute("feedback") @Valid EventSessionFeedback theFeedback,
			@RequestParam(required=false , value = "eventId") String eventId
				,@RequestParam(required=false , value = "departmentId") String departmentId
				,@RequestParam(required=false , value = "ratingName") String ratingName
				,@RequestParam(required=false , value = "speakerId") String speakerId
			,BindingResult bindingResult
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			,Model theModel) {
		HttpSession session =  request.getSession();
		String successMsg = "",errorMsg = "";
		System.out.println("Hello in feedback Report");
       System.out.println("rating "+theFeedback.getRatingName());
       int deptId = 0;
		//EventFeedbackReport eventFeedbackReport = new EventFeedbackReport();
       if(session.getAttribute("markerType")!=null && !session.getAttribute("markerType").equals("") && !session.getAttribute("markerType").equals("null")) {
    	   if(Integer.parseInt((String)session.getAttribute("markerType")) == 1) {
				if(session.getAttribute("departmentid")!=null && !session.getAttribute("departmentid").equals("") && !session.getAttribute("departmentid").equals("null")) {
					Department depa = departmentService.getDepartmentById(Long.valueOf((String)session.getAttribute("departmentid")));
					System.out.println(depa.getDepartmentId() + "fsafsadfs");
					deptId = depa.getDepartmentId().intValue();
					theFeedback.setDepartmentId(deptId);
				}
			}
       }
       
		List<EventFeedbackReport> eventFeedbackReportList = new ArrayList<EventFeedbackReport>();
		eventFeedbackReportList =	eventFeedbackService.getFeedbackReport(theFeedback,  request);
		
		
		for (EventFeedbackReport eventFeedbackReport : eventFeedbackReportList) {
			System.out.println("eventFeedbackReport export rating Hello"+eventFeedbackReport.getRatingName());
		}
		
		if(eventFeedbackReportList.size() > 0) {
			successMsg = "Feedback Report Generated Successfully!!";
			
		}else {
			errorMsg = "Data not Found !! ";
			
		}
		
		
		
		 
			// use a redirect to prevent duplicate submissions & Add Messages
	
		
		  theModel.addAttribute("eventReportList", eventFeedbackReportList);
		 // theModel.addAttribute("successMsg",successMsg);
		  //theModel.addAttribute("errorMsg",errorMsg);
		  
		  //return "reports/feedbackReportForm";
		 
		
		/*
		 * redirectAttributes.addFlashAttribute("eventReportList",
		 * eventFeedbackReportList);
		 * redirectAttributes.addFlashAttribute("successMsg",successMsg);
		 * redirectAttributes.addFlashAttribute("errorMsg", errorMsg);
		 */
		  
		 return eventFeedbackReportList; 
		 
		//return "redirect:/report/feedbackForm";
		
		}
	
	
	@GetMapping(value = "/report/feedbackReport/export")
	@PreAuthorize("hasPermission(null,'feedbackForm', 'EXPORT_PRIVILEGE')")
	public ResponseEntity<InputStreamResource> excelFeedbackReport (@ModelAttribute("feedback") EventSessionFeedback theFeedback,
	BindingResult bindingResult
	,RedirectAttributes redirectAttributes
	,HttpServletRequest request
	,Model theModel) throws IOException { 
	
		
		List<EventFeedbackReport> eventFeedbackReportList = new ArrayList<EventFeedbackReport>();
		if(theFeedback!=null) {
			System.out.println(theFeedback.getDepartmentId());
			System.out.println(theFeedback.getRatingName());
			eventFeedbackReportList =	eventFeedbackService.getFeedbackReport(theFeedback,  request);
		}
		ByteArrayInputStream in = generateExcelReport.FeedbackReportToExcel(eventFeedbackReportList);
		// return IO ByteArray(in);
		HttpHeaders headers = new HttpHeaders();
		// set filename in header
		headers.add("Content-Disposition", "attachment; filename=eventFeedbackReport.xlsx");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}
	
}
