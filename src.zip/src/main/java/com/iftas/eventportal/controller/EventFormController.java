package com.iftas.eventportal.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.poi.ss.usermodel.PictureData;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFPicture;
import org.apache.poi.xssf.usermodel.XSSFShape;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.iftas.eventportal.dao.DesignationRepository;
import com.iftas.eventportal.dao.EventAdminRepository;
import com.iftas.eventportal.dao.EventMasterRepository;
import com.iftas.eventportal.dao.EventParticipantRepository;
import com.iftas.eventportal.dao.EventSessionRepository;
import com.iftas.eventportal.dao.EventSpeakerRepository;
import com.iftas.eventportal.dao.EventTransportaionRepository;
import com.iftas.eventportal.dao.MobileUserRepository;
import com.iftas.eventportal.dao.ParticipantRepository;
import com.iftas.eventportal.dao.SpeakersRepository;
import com.iftas.eventportal.dto.eventDTO;
import com.iftas.eventportal.entity.Department;
import com.iftas.eventportal.entity.Designation;
import com.iftas.eventportal.entity.EventAdmin;
import com.iftas.eventportal.entity.EventMaster;
import com.iftas.eventportal.entity.EventParticipants;
import com.iftas.eventportal.entity.EventSessionRef;
import com.iftas.eventportal.entity.EventSpeakers;
import com.iftas.eventportal.entity.EventTransportaion;
import com.iftas.eventportal.entity.MobileUsers;
import com.iftas.eventportal.entity.ParticipantMaster;
import com.iftas.eventportal.entity.ProductMaster;
import com.iftas.eventportal.entity.SpeakerMaster;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.service.DepartmentService;
import com.iftas.eventportal.service.EventService;
import com.iftas.eventportal.service.EventSpeakerService;
import com.iftas.eventportal.service.ParticipantService;
import com.iftas.eventportal.service.ProductService;
import com.iftas.eventportal.service.SpeakerService;
import com.iftas.eventportal.utils.DataRow;
import com.iftas.eventportal.utils.DataTable;
import com.iftas.eventportal.utils.ExcelTable;


@Controller
@PreAuthorize("hasPermission('','event', 'READ_PRIVILEGE')")
@RequestMapping("/Event/event")
public class EventFormController {

	@Autowired
	private EventService eventService;
	
	@Autowired
	private ParticipantService participantService;
	
	@Autowired
	private DepartmentService departmentService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private EventSpeakerService eventSpeakerService;
	
	@Autowired
	private DesignationRepository desigantionRepository;
	
	@Autowired
	private EventParticipantRepository eventParticipantRepository;
	
	@Autowired
	private EventAdminRepository eventAdminRepository;
	
	@Autowired
	private EventSessionRepository eventSessionRepository;
	
	
	@Autowired
	private EventSpeakerRepository eventSpeakerRepository;
	
	@Autowired
	private EventTransportaionRepository eventTransportaionRepository;
	
	@Autowired
	private SpeakerService speakerService;
	
	@Autowired
	private SpeakersRepository speakersRepository;
	
	@Autowired
	private ParticipantRepository participantRepository;
	
	@Autowired
	private MobileUserRepository mobileUserRepository;
	
	@GetMapping("/")
	@PreAuthorize("hasPermission('','event', 'READ_PRIVILEGE')")
	public String eventDetailList(Model theModel,HttpServletRequest request) {
		HttpSession session =  request.getSession();
		List<EventMaster> events = new ArrayList<EventMaster>();
		if(session.getAttribute("markerType")!=null && !session.getAttribute("markerType").equals("") && !session.getAttribute("markerType").equals("null")) {
			if(Integer.parseInt((String)session.getAttribute("markerType")) == 0) {
				events =  eventService.getEventList();
			}
			if(Integer.parseInt((String)session.getAttribute("markerType")) == 1) {
				if(session.getAttribute("eventid")!=null && !session.getAttribute("eventid").equals("") && !session.getAttribute("eventid").equals("null")) {
					EventMaster event = eventService.getEventListbyId(Long.valueOf((String)session.getAttribute("eventid")));
					events.add(event);
				}
			}
		}
		theModel.addAttribute("events", events);
		return "events/eventListDetails";
	}
	
	@GetMapping("/eventUploadForm")
	@PreAuthorize("hasPermission('','event', 'ADD_PRIVILEGE')")
	public String eventUploadForm(Model theModel,HttpServletRequest request) {
		return "events/eventUploadForm";
	}


	
	@PostMapping("/import")
	@PostAuthorize("hasPermission('','event', 'ADD_PRIVILEGE')")
	public String mapReapExcelDatatoDB(@RequestParam("file") MultipartFile reapExcelDataFile
			,Model theModel,RedirectAttributes redirectAttributes,HttpServletRequest request) throws IOException {
		String succesMessage=""; 
	    succesMessage = Constants.UPLOAD_SUCCESSFULLY;
	    eventService.uploadEvents(reapExcelDataFile, request);
		redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
		return "redirect:/Event/event/";
	}
	
	
	@GetMapping("/viewEvent")
	public String viewEvent(@RequestParam("eventId") Long id, Model theModel,HttpServletRequest request) {
		EventMaster eventMaster =  eventService.getEventListbyId(id);
		eventDTO eventdata = new eventDTO();
		List<EventTransportaion> transportData = eventTransportaionRepository.findAllByEventId(id);
		eventdata.setEventId(eventMaster.getEventId());
		eventdata.setEventName(eventMaster.getEventName());
		eventdata.setEventPlaceName(eventMaster.getEventLocationPlaceName());
		eventdata.setEventStartDate(eventMaster.getEventStartDate());
		eventdata.setEventEndDate(eventMaster.getEventEndDate());
		eventdata.setEventInformation(eventMaster.getEventLocationInformation());
		eventdata.setVenueAddress(eventMaster.getEventVenueAddress());
		eventdata.setVenuePinCode(eventMaster.getEventVenuePincode());
		eventdata.setVenueLatitude(eventMaster.getEventVenueLatittude());
		eventdata.setVenueLongitude(eventMaster.getEventVenueLongitude());
		if(eventMaster.getEventDepartment()!=null) {
		  eventdata.setDepartmentName(eventMaster.getEventDepartment().getDepartmentName());
		}
		if(eventMaster.getEventProduct()!=null) {
		eventdata.setProductName(eventMaster.getEventProduct().getProductName());
		}
		eventdata.setEventLocUrl(eventMaster.getEventVenueFolderName());
		eventdata.setEventLocImageName(eventMaster.getEventVenueFileName());		
		for (EventTransportaion eventTransportaion : transportData) {
			if(eventTransportaion.getTransportFileDescription().equals("0")) {
			eventdata.setTransportToVenueFolder(eventTransportaion.getTransportFolderName());
			eventdata.setTransportToVenueFile(eventTransportaion.getTransportFileName());
			
			}else if(eventTransportaion.getTransportFileDescription().equals("1")) {
				eventdata.setTransportFromVenueFolder(eventTransportaion.getTransportFolderName());	
				eventdata.setTransportFromVenueFile(eventTransportaion.getTransportFileName());
			
			}else if(eventTransportaion.getTransportFileDescription().equals("2")) {
				eventdata.setFlightToFolder(eventTransportaion.getTransportFolderName());
				eventdata.setFlightToFile(eventTransportaion.getTransportFileName());
				
			}else if(eventTransportaion.getTransportFileDescription().equals("3")) {
				eventdata.setFlightFromVenueFolder(eventTransportaion.getTransportFolderName());
				eventdata.setFlightFromFile(eventTransportaion.getTransportFileName());
			}
		
		}
		if(eventMaster.getEventConferenceInformation()!=null) {
			eventdata.setDressCode(eventMaster.getEventConferenceInformation().getDressCode());
			eventdata.setAttendanceTimeTable(eventMaster.getEventConferenceInformation().getAttendenceTimeTable());
			eventdata.setPresentations(eventMaster.getEventConferenceInformation().getPresentations());
			eventdata.setSpecialRequirements(eventMaster.getEventConferenceInformation().getSpecialRequirements());
			eventdata.setRegistrationDetail(eventMaster.getEventConferenceInformation().getRegisterationDetail());
			eventdata.setTransportation(eventMaster.getEventConferenceInformation().getTransportation());
			eventdata.setWelcomeMsg(eventMaster.getEventConferenceInformation().getWelcomeMessage());
	    }
		
		
		
		List<EventSpeakers> speakerdata = eventSpeakerRepository.findAllByEventId(id);
		List<EventParticipants> participantData = eventParticipantRepository.findAllByEventId(id);
		
		List<EventSessionRef> sessionData = eventSessionRepository.findAllByEventId(id);
		List<EventAdmin> adminData = eventAdminRepository.findAllByEventId(id);
		
		theModel.addAttribute("eventSpeaker", speakerdata);
		theModel.addAttribute("eventParticipant", participantData);
		theModel.addAttribute("eventSession", sessionData);
		theModel.addAttribute("eventAdmin", adminData);
		theModel.addAttribute("event", eventdata);
		theModel.addAttribute("eventMaster", eventMaster);
		return "events/eventView";
	}
	
	@GetMapping("/editEvent")
	@PreAuthorize("hasPermission('','event', 'EDIT_PRIVILEGE')")
	public String showFormForUpdate(@RequestParam("eventId") Long id, Model theModel,HttpServletRequest request) {
		System.out.println("in edit event ");
		EventMaster eventMaster =  eventService.getEventListbyId(id);
		HttpSession session =  request.getSession();
		boolean disabled = false;
		List<Department> departments = new ArrayList<Department>();
		if(session.getAttribute("markerType")!=null && !session.getAttribute("markerType").equals("") && !session.getAttribute("markerType").equals("null")) {
			if(Integer.parseInt((String)session.getAttribute("markerType")) == 0) {
				departments = departmentService.getDepartmentListingByActiveStatus(0);
			}
			if(Integer.parseInt((String)session.getAttribute("markerType")) == 1) {
				if(session.getAttribute("departmentid")!=null && !session.getAttribute("departmentid").equals("") && !session.getAttribute("departmentid").equals("null")) {
					Department depa = departmentService.getDepartmentById(Long.valueOf((String)session.getAttribute("departmentid")));
					departments.add(depa);
				}
			}
		}
		
		if(session.getAttribute("eventid")!=null && !session.getAttribute("eventid").equals("") && !session.getAttribute("eventid").equals("null")) {
			disabled = true;
		}
		
		List<ProductMaster> products = productService.getProductList();
		//List<EventTransportaion> transportData = eventTransportaionRepository.findAllByEventId(id);
		theModel.addAttribute("departments", departments);
		theModel.addAttribute("products", products);
		theModel.addAttribute("eventMaster", eventMaster);
		theModel.addAttribute("disabled", disabled);
		return "events/eventEdit";
	}
	
	@PostMapping("/updateEvent")
	@PostAuthorize("hasPermission('','event', 'EDIT_PRIVILEGE')")
	public String updateEventDetails(
			@ModelAttribute("eventMaster") @Valid eventDTO theEventDetails,  
			 BindingResult bindingResult
			,Model theModel
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			) throws IllegalStateException, IOException {
		System.out.println("In Update Event START :: ");
		HttpSession session =  request.getSession();
		String successMsg = "",errorMsg="";
		
		
		
		
		boolean eventDataStatus = false;		
		eventDataStatus =  eventService.updateEventDetails(theEventDetails,request);
		if(eventDataStatus) {
			successMsg = "Event Data Updated Successfully!";
		}else {
			errorMsg = "Eror Occured, Event Data not Updated!";
		}
		
		redirectAttributes.addFlashAttribute("successMsg",successMsg);
		redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
		return "redirect:/Event/event/editEvent?eventId="+request.getParameter("eventId");
		
	}
	
	@GetMapping("/editEventConference")
	@PreAuthorize("hasPermission('','event', 'EDIT_PRIVILEGE')")
	public String showFormForEventConferenceUpdate(@RequestParam("eventId") Long id, Model theModel,HttpServletRequest request) {
		System.out.println("in edit EventConference ");
		EventMaster eventMaster =  eventService.getEventListbyId(id);
		theModel.addAttribute("eventMaster", eventMaster);
		return "events/eventConferenceEdit";
	}
	
	@PostMapping("/updateEventConference")
	public String updateConferenceEventDetails(
			@ModelAttribute("eventMaster") @Valid eventDTO theEventDetails,  
			 BindingResult bindingResult
			,Model theModel
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			) throws IllegalStateException, IOException {
		System.out.println("In Update Event START :: ");
		HttpSession session =  request.getSession();
		String successMsg = "",errorMsg="";
		boolean eventDataStatus = false;		
		eventDataStatus =  eventService.updateConferenceEventDetails(theEventDetails,request);
		if(eventDataStatus) {
			successMsg = "Event Data Updated Successfully!";
		}else {
			errorMsg = "Eror Occured, Event Data not Updated!";
		}
		
		redirectAttributes.addFlashAttribute("successMsg",successMsg);
		redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
		return "redirect:/Event/event/editEventConference?eventId="+request.getParameter("eventId");
		
	}
	
	
	@GetMapping("/editEventSpeaker")
	public String showFormForEventSpeakerUpdate(@RequestParam("eventId") Long id, Model theModel,HttpServletRequest request) {
		System.out.println("in edit Event Speaker ");
		EventMaster eventMaster =  eventService.getEventListbyId(id);
		List<SpeakerMaster> speakerdata = eventSpeakerRepository.findAllSpeakerByEventId(id);
		theModel.addAttribute("eventMaster", eventMaster);
		theModel.addAttribute("speaker", speakerdata);
		return "events/eventSpeakerEdit";
	}
	
	
	@GetMapping("/addEventSpeaker")
	public String showFormForAdd(@RequestParam("eventId") Long id,Model theModel) {
		SpeakerMaster speaker = new SpeakerMaster();
		theModel.addAttribute("speaker", speaker);
		theModel.addAttribute("eventId", id);
		return "events/addEventSpeaker";
	}
	
	
	@PostMapping("/createSpeaker")
	public String createSpeaker(
			 @ModelAttribute("speaker") @Valid SpeakerMaster theSpeaker
			,BindingResult bindingResult
			,@RequestParam(required=false, value="addbutn") String addFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			,@RequestParam("imgInp") MultipartFile readFileFormat
			) {
		System.out.println("Request to Add new Speaker" + theSpeaker);
		String succesMessage=""; String errorMessage="";
		if(bindingResult.hasErrors()) {
			return "events/addEventSpeaker";
		}
		else {
			
			Optional<SpeakerMaster> optionalSpeaker =  speakersRepository.findOneBySpeakerEmailIdIgnoreCase(theSpeaker.getSpeakerEmailId());
			if(optionalSpeaker.isPresent()) {
				theSpeaker.setSpeakerId(optionalSpeaker.get().getSpeakerId());
				theSpeaker.setSpeakerFileName(optionalSpeaker.get().getSpeakerFileName());
				theSpeaker.setSpeakerFolderName(optionalSpeaker.get().getSpeakerFolderName());
				speakerService.updateEventSpeaker(theSpeaker, readFileFormat, request);
			}else {
				speakerService.createEventSpeaker(theSpeaker, readFileFormat, request);
				redirectAttributes.addFlashAttribute("succesMessage", succesMessage);
			}
			succesMessage = Constants.ADD_SUCCESSFULLY;
			redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
			return "redirect:/Event/event/editEventSpeaker?eventId="+request.getParameter("eventId");
				
		}
   }
	
	@GetMapping("/editSpeaker")
	public String showFormEditSpeakerForUpdate(@RequestParam("speakerId") Long id,@RequestParam("eventId") Long eventId,Model theModel,HttpServletRequest request) {
		System.out.println("In Edit speaker ");
		SpeakerMaster speakers = new SpeakerMaster();
		speakers =  speakerService.getSpeakerById(id);
		EventSpeakers eventSpeaker = new EventSpeakers();
		//Getting Data from event Speaker & event Id
		Optional<EventSpeakers> optionalEventSpeaker = eventSpeakerRepository.findBySpeakerAndEventId(eventId, id);
		if(optionalEventSpeaker.isPresent()) {
			eventSpeaker = optionalEventSpeaker.get();
		}
		//Getting Data from event Mobile User 
		MobileUsers mobileUser = new MobileUsers();	
	    Optional<MobileUsers> optionalMobileUser = mobileUserRepository.findOneByEmailIdIgnoreCase(speakers.getSpeakerEmailId());
	    if(optionalMobileUser.isPresent()) {
	    	mobileUser =optionalMobileUser.get();
	    }
	    
		theModel.addAttribute("speaker", speakers);
		theModel.addAttribute("eventspeaker", eventSpeaker);
		theModel.addAttribute("mobileUser", mobileUser);
		return "events/editEventSpeaker";
	}
	
	@PostMapping("/updateSpeaker")
	public String updateSpeaker(
			@ModelAttribute("speaker") @Valid SpeakerMaster theSpeaker,
			BindingResult bindingResult
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			,@RequestParam("imgInp") MultipartFile readFileFormat
			) {
		HttpSession session =  request.getSession();
		String successMsg = "" ,errorMsg="";
		boolean isPresentFlag = false;
		boolean sendFlag =  false;
		if (bindingResult.hasErrors()) {
			return "events/editEventSpeaker";
		}
		else {	
			
			//Check If changes email already Exists 
			Optional<SpeakerMaster> existingSpeaker =  speakersRepository.findOneBySpeakerEmailIdIgnoreCase(theSpeaker.getSpeakerEmailId());
			if(existingSpeaker.isPresent() && (!theSpeaker.getSpeakerId().equals(existingSpeaker.get().getSpeakerId()))) {
				theSpeaker.setSpeakerId(existingSpeaker.get().getSpeakerId());
				theSpeaker.setSpeakerFileName(existingSpeaker.get().getSpeakerFileName());
				theSpeaker.setSpeakerFolderName(existingSpeaker.get().getSpeakerFolderName());
			}
			
		    successMsg =  Constants.UPDATE_SUCCESSFULLY;
			//Step1 save the Speaker
			speakerService.updateEventSpeaker(theSpeaker,readFileFormat, request);
			redirectAttributes.addFlashAttribute("successMsg",successMsg);
			
			return "redirect:/Event/event/editEventSpeaker?eventId="+request.getParameter("eventId");
		}
	
	
	
	}
	
	
	@GetMapping("/viewEventSpeaker")
	public String showFormForUserView(@RequestParam("speakerId") Long id,@RequestParam("eventId") Long eventId,Model theModel,HttpServletRequest request) {
		SpeakerMaster speakers = new SpeakerMaster();
		speakers =  speakerService.getSpeakerById(id);
		EventSpeakers eventSpeaker = new EventSpeakers();
		//Getting Data from event Speaker & event Id
		Optional<EventSpeakers> optionalEventSpeaker = eventSpeakerRepository.findBySpeakerAndEventId(eventId, id);
		if(optionalEventSpeaker.isPresent()) {
			eventSpeaker = optionalEventSpeaker.get();
		}
		//Getting Data from event Mobile User 
		MobileUsers mobileUser = new MobileUsers();	
	    Optional<MobileUsers> optionalMobileUser = mobileUserRepository.findOneByEmailIdIgnoreCase(speakers.getSpeakerEmailId());
	    if(optionalMobileUser.isPresent()) {
	    	mobileUser =optionalMobileUser.get();
	    }
		theModel.addAttribute("speaker", speakers);
		theModel.addAttribute("eventspeaker", eventSpeaker);
		theModel.addAttribute("mobileUser", mobileUser);
		return "events/viewEventSpeaker";
	}
	
	@GetMapping("/viewEventParticipant")
	public String showFormForParticipantView(@RequestParam("participantId") Long id,@RequestParam("eventId") Long eventId,Model theModel,HttpServletRequest request) {
		ParticipantMaster participant = new ParticipantMaster();
		participant =  participantService.getParticipantById(id);
		EventParticipants eventParticipant = new EventParticipants();
		//Getting Data from event Speaker & event Id
		Optional<EventParticipants> optionalEventParticipants = eventParticipantRepository.findByParticipantAndEventId(eventId, id);
		if(optionalEventParticipants.isPresent()) {
			eventParticipant = optionalEventParticipants.get();
		}
		//Getting Data from event Mobile User 
		MobileUsers mobileUser = new MobileUsers();	
	    Optional<MobileUsers> optionalMobileUser = mobileUserRepository.findOneByEmailIdIgnoreCase(participant.getParticipantEmailId());
	    if(optionalMobileUser.isPresent()) {
	    	mobileUser =optionalMobileUser.get();
	    }
		theModel.addAttribute("participants", participant);
		theModel.addAttribute("eventparticipants", eventParticipant);
		theModel.addAttribute("mobileUser", mobileUser);
		return "events/viewEventParticipant";
	}
	
	
	@GetMapping("/uploadEventSpeaker")
	public String showFormForUpload(Model theModel) {
		SpeakerMaster speakers = new SpeakerMaster();
		theModel.addAttribute("speakers", speakers);
		return "events/uploadEventSpeaker";
	}
	
	
	
	@PostMapping("/importSpeaker")
	public String mapReadSpeakerExcelDatatoDB(@RequestParam("file") MultipartFile reapExcelDataFile,Model theModel,RedirectAttributes redirectAttributes,HttpServletRequest request) throws IOException {
		String succesMessage=""; 
		succesMessage = Constants.UPLOAD_SUCCESSFULLY;
		speakerService.uploadEventSpeakers(reapExcelDataFile, request);
		redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
		redirectAttributes.addFlashAttribute("successMsg",succesMessage );
		return "redirect:/Event/event/editEventSpeaker?eventId="+request.getParameter("eventId");
	}
	
	@GetMapping("/editEventSession")
	public String showFormForEventSessionUpdate(@RequestParam("eventId") Long id, Model theModel,HttpServletRequest request) {
		System.out.println("in edit Event Session ");
		
		List<EventSessionRef> sessionData = eventSessionRepository.findAllByEventId(id);
		List<SpeakerMaster> speakerdata = eventSpeakerRepository.findAllSpeakerByEventId(id);
		EventMaster eventMaster =  eventService.getEventListbyId(id);
		theModel.addAttribute("eventMaster", eventMaster);
		theModel.addAttribute("eventSession", sessionData);
		theModel.addAttribute("speakers", speakerdata);
		return "events/eventSessionEdit";
	}
	
	@PostMapping("/updateEventSession")
	public String updateSessionEventDetails(
			@ModelAttribute("eventMaster") @Valid eventDTO theEventDetails,  
			 BindingResult bindingResult
			,Model theModel
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			) throws IllegalStateException, IOException {
		System.out.println("In Update Event START :: ");
		HttpSession session =  request.getSession();
		String successMsg = "",errorMsg="";
		boolean eventDataStatus = false;		
		eventDataStatus =  eventService.updateSessionEventDetails(theEventDetails,request);
		if(eventDataStatus) {
			successMsg = "Event Data Updated Successfully!";
		}else {
			errorMsg = "Eror Occured, Event Data not Updated!";
		}
		
		redirectAttributes.addFlashAttribute("successMsg",successMsg);
		redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
		return "redirect:/Event/event/editEventSession?eventId="+request.getParameter("eventId");
		
	}
	
	
	@GetMapping("/editEventParticipant")
	public String showFormForEventParticipantUpdate(@RequestParam("eventId") Long id, Model theModel,HttpServletRequest request) {
		System.out.println("in edit Event Participant ");
		EventMaster eventMaster =  eventService.getEventListbyId(id);
		List<ParticipantMaster> participantList = eventParticipantRepository.findAllParticipantByEventId(id);
		theModel.addAttribute("eventMaster", eventMaster);
		theModel.addAttribute("participants", participantList);
		return "events/eventParticipantEdit";
	}
	
	@GetMapping("/addEventParticipant")
	public String showFormForEventParticipantAdd(@RequestParam("eventId") Long id,Model theModel) {		
		ParticipantMaster participant = new ParticipantMaster();
		theModel.addAttribute("participant", participant);
		theModel.addAttribute("eventId", id);
		return "events/addEventParticipant";
	}
	
	
	@PostMapping("/createParticipant")
	public String createParticipant(
			 @ModelAttribute("participant") @Valid ParticipantMaster theParticipant
			,BindingResult bindingResult
			,@RequestParam(required=false, value="addbutn") String addFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			,@RequestParam("imgInp") MultipartFile readFileFormat
			) {
		System.out.println("Request to Add new Participant" + theParticipant);
		String succesMessage=""; String errorMessage="";
		if(bindingResult.hasErrors()) {
			return "events/addEventParticipant";
		}
		else {
			Optional<ParticipantMaster> optionalParticipant = participantRepository.findOneByParticipantEmailIdIgnoreCase(theParticipant.getParticipantEmailId());
			if(optionalParticipant.isPresent()) {
				theParticipant.setParticipantId(optionalParticipant.get().getParticipantId());
				theParticipant.setParticipantFileName(optionalParticipant.get().getParticipantFileName());
				theParticipant.setParticipantFolderName(optionalParticipant.get().getParticipantFolderName());
				participantService.updateEventParticipant(theParticipant, request,readFileFormat);
			}else {
				succesMessage = Constants.ADD_SUCCESSFULLY;
				participantService.createEventParticipant(theParticipant, readFileFormat, request);
				redirectAttributes.addFlashAttribute("succesMessage", succesMessage);
			}
			//Step 3 use a redirect to prevent duplicate submissions & Add Messages
			redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
			return "redirect:/Event/event/editEventParticipant?eventId="+request.getParameter("eventId");
				
		}
   }
	
	@GetMapping("/editParticipant")
	public String showFormEventParticipantForUpdate(@RequestParam("participantId") Long id,@RequestParam("eventId") Long eventId,Model theModel,HttpServletRequest request) {
		System.out.println("In Edit Participant ");
		ParticipantMaster participant = new ParticipantMaster();
		participant =  participantService.getParticipantById(id);
		EventParticipants eventParticipant = new EventParticipants();
		//Getting Data from event participant & event Id
		Optional<EventParticipants> optionalEventParticipant = eventParticipantRepository.findByParticipantAndEventId(eventId, id);
		if(optionalEventParticipant.isPresent()) {
			eventParticipant = optionalEventParticipant.get();
		}
		//Getting Data from event Mobile User 
		MobileUsers mobileUser = new MobileUsers();	
	    Optional<MobileUsers> optionalMobileUser = mobileUserRepository.findOneByEmailIdIgnoreCase(participant.getParticipantEmailId());
	    if(optionalMobileUser.isPresent()) {
	    	mobileUser =optionalMobileUser.get();
	    }
		theModel.addAttribute("participant", participant);
		theModel.addAttribute("eventparticipant", eventParticipant);
		theModel.addAttribute("mobileUser", mobileUser);
		return "events/editEventParticipant";
	}
	
	@PostMapping("/updateParticipant")
	public String updateParticipant(
			@ModelAttribute("participant") @Valid ParticipantMaster theParticipant,
			BindingResult bindingResult
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			,@RequestParam("imgInp") MultipartFile readFileFormat
			) {
		HttpSession session =  request.getSession();
		String successMsg = "" ,errorMsg="";
		boolean isPresentFlag = false;
		boolean sendFlag =  false;
		if (bindingResult.hasErrors()) {
			return "events/editEventParticipant";
		}
		else {	
			
			//Check If changes email already Exists 
			Optional<ParticipantMaster> existingParticipant =  participantRepository.findOneByParticipantEmailIdIgnoreCase(theParticipant.getParticipantEmailId());
			if(existingParticipant.isPresent() && (!theParticipant.getParticipantId().equals(existingParticipant.get().getParticipantId()))) {
				theParticipant.setParticipantId(existingParticipant.get().getParticipantId());
				theParticipant.setParticipantFileName(existingParticipant.get().getParticipantFileName());
				theParticipant.setParticipantFolderName(existingParticipant.get().getParticipantFolderName());
			}
			
			successMsg =  Constants.UPDATE_SUCCESSFULLY;
			//Step1 save the Participant
			participantService.updateEventParticipant(theParticipant, request,readFileFormat);
			redirectAttributes.addFlashAttribute("successMsg",successMsg);
	
			return "redirect:/Event/event/editEventParticipant?eventId="+request.getParameter("eventId");
		}
	
	
	
	}
	
	@GetMapping("/uploadEventParticipant")
	public String showEventParticipantFormForUpload(Model theModel) {
		ParticipantMaster participant = new ParticipantMaster(); 
		theModel.addAttribute("participant", participant);
		return "events/uploadEventParticipant";
	}
	
	
	
	@PostMapping("/importParticipant")
	public String mapReadParticipantExcelDatatoDB(@RequestParam("file") MultipartFile reapExcelDataFile,Model theModel,RedirectAttributes redirectAttributes,HttpServletRequest request) throws IOException {
		String succesMessage=""; 
		succesMessage = Constants.UPLOAD_SUCCESSFULLY;
		participantService.uploadEventParticipants(reapExcelDataFile, request);
		redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
		redirectAttributes.addFlashAttribute("successMsg",succesMessage );
		return "redirect:/Event/event/editEventParticipant?eventId="+request.getParameter("eventId");
	}
	
	
	@GetMapping("/editEventAdmin")
	public String showFormForEventAdminUpdate(@RequestParam("eventId") Long id, Model theModel,HttpServletRequest request) {
		System.out.println("in edit Event Admin ");
		List<EventAdmin> adminData = eventAdminRepository.findAllByEventId(id);
		List<Designation> designation = desigantionRepository.findAll();
		EventMaster eventMaster =  eventService.getEventListbyId(id);
		theModel.addAttribute("eventMaster", eventMaster);
		theModel.addAttribute("eventAdmin", adminData);
		theModel.addAttribute("designations", designation);
		return "events/eventAdminEdit";
	}
	
	
	@PostMapping("/updateEventAdmin")
	public String updateAdminEventDetails(
			@ModelAttribute("eventMaster") @Valid EventAdmin eventAdmin,  
			 BindingResult bindingResult
			,Model theModel
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			) throws IllegalStateException, IOException {
		System.out.println("In Update Event START :: ");
		HttpSession session =  request.getSession();
		String successMsg = "",errorMsg="";
		boolean eventDataStatus = false;	
		
		eventDataStatus =  eventService.updateAdminEventDetails(eventAdmin,request);
		if(eventDataStatus) {
			successMsg = "Event Data Updated Successfully!";
		}else {
			errorMsg = "Eror Occured, Event Data not Updated!";
		}
		redirectAttributes.addFlashAttribute("successMsg",successMsg);
		redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
		return "redirect:/Event/event/editEventAdmin?eventId="+request.getParameter("eventId");
	}
	
	
	@GetMapping("/eventForm")
	public String eventForm(Model theModel,HttpServletRequest request) {
		
		HttpSession session =  request.getSession();
		EventMaster eventMaster = new EventMaster();
		List<Department> departments = new ArrayList<Department>();
		if(session.getAttribute("markerType")!=null && !session.getAttribute("markerType").equals("") && !session.getAttribute("markerType").equals("null")) {
			if(Integer.parseInt((String)session.getAttribute("markerType")) == 0) {
				departments = departmentService.getDepartmentListingByActiveStatus(0);
			}
			if(Integer.parseInt((String)session.getAttribute("markerType")) == 1) {
				if(session.getAttribute("departmentid")!=null && !session.getAttribute("departmentid").equals("") && !session.getAttribute("departmentid").equals("null")) {
					Department depa = departmentService.getDepartmentById(Long.valueOf((String)session.getAttribute("departmentid")));
					departments.add(depa);
				}
			}
		}
		List<ProductMaster> products = productService.getProductList();
		theModel.addAttribute("products", products);
		theModel.addAttribute("departments", departments);
		theModel.addAttribute("eventMaster", eventMaster);
		return "events/eventForm";
	}
	
	@PostMapping("/addEvent")
	public String addEventDetails(
			@ModelAttribute("event") @Valid eventDTO theEventDetails, 
			BindingResult bindingResult
			,Model theModel
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request
			
			) throws IllegalStateException, IOException {
		System.out.println("In Add Event START :: ");
		
		HttpSession session =  request.getSession();
		String successMsg = "",errorMsg="";
		
		EventMaster theEventMaster = new EventMaster();
		
		if(theEventDetails.getEventLocationImage()!= null && theEventDetails.getEventPlaceName()!= null && theEventDetails.getEventInformation() != null
			&&	theEventDetails.getDepartmentId() != 0 && theEventDetails.getProductId() != 0) {
			
			theEventMaster =  eventService.addEventDetails(theEventDetails, request);
			
		}else {
			
		if(theEventMaster!=null) {
			successMsg = "Event Data Added Successfully!";
		}else {
			errorMsg = "Eror Occured, Event Data not Added!";
		     }
		}
		redirectAttributes.addFlashAttribute("successMsg",successMsg);
		redirectAttributes.addFlashAttribute("errorMsg",errorMsg);
		return "redirect:/Event/event/editEventConference?eventId="+theEventMaster.getEventId();
		
				
	}
	
	
	
	
	
	 @PostMapping("/fileUpload")
	   public ResponseEntity<Object> fileUpload(@RequestParam("file") MultipartFile file)
	         throws IOException { 
		 System.out.println("in file upload");
	      // Save file on system
	      if (!file.getOriginalFilename().isEmpty()) {
	         BufferedOutputStream outputStream = new BufferedOutputStream(
	               new FileOutputStream(
	                     new File("D:/Upload", file.getOriginalFilename())));
	         outputStream.write(file.getBytes());
	         outputStream.flush();
	         outputStream.close();
	      }else{
	         return new ResponseEntity<>("Invalid file.",HttpStatus.BAD_REQUEST);
	      }
	      
	      return new ResponseEntity<>("File Uploaded Successfully.",HttpStatus.OK);
	   }
	
	 
	 @GetMapping("/downloadTransport")
		public void fileDownload(@RequestParam("url") String url, Model theModel,HttpServletRequest request,HttpServletResponse response ) throws IOException {
			//System.out.println("in file download  event ");
			System.out.println("url "+url);
			HttpSession session =  request.getSession();
			String filePath = (String)session.getAttribute("pathUrl");
			System.out.println("filepath "+filePath);
			System.out.println(filePath + url);
			
			File file = new File(filePath + url);
			//file = file.getAbsoluteFile();
			//System.out.println("file "+file.getName().toString());
			//System.out.println("file absoule path : "+file.getAbsolutePath() + "canonical : "+file.getCanonicalPath());
			//File file = new File("F:\\DevelopmentEvent\\UploadFiles\\Templates\\EventUpload .xlsx");
			if (file.exists()) {

				//get the mimetype
				String mimeType = URLConnection.guessContentTypeFromName(file.getName());
				if (mimeType == null) {
					//unknown mimetype so set the mimetype to application/octet-stream
					mimeType = "application/octet-stream";
				}

				response.setContentType(mimeType);

				 //Here we have mentioned it to show as attachment
				 response.setHeader("Content-Disposition", String.format("attachment; filename=\"" + file.getName() + "\""));

				response.setContentLength((int) file.length());

				InputStream inputStream = new BufferedInputStream(new FileInputStream(file));

				FileCopyUtils.copy(inputStream, response.getOutputStream());
			}
	 }
	 
	 
}
