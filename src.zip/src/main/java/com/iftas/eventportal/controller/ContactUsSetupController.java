package com.iftas.eventportal.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import com.iftas.eventportal.entity.ContactUsSetup;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.service.ContactUsSetupService;

@Controller
@RequestMapping("/systemAdmin/contactussetup")
public class ContactUsSetupController {
	private final Logger log = LoggerFactory.getLogger(ContactUsSetupController.class);
	
	@Autowired
	private ContactUsSetupService contactUsSetupService;
	
	@GetMapping("/")
	public String listConatactUsSetup(Model theModel) {
		log.debug("Request to List Conatct Us Setup");
		List<ContactUsSetup> contactus =  contactUsSetupService.getContactUsSetups(0);
		//Add to Model
		theModel.addAttribute("contactus", contactus);
		return "systemAdmin/contactussetup/listcontactussetup";
	}
	@GetMapping(value = "/viewContactUsSetup")
	public String viewCommonSetup(@RequestParam("contactUsSetupId") Long id,Model theModel,HttpServletRequest request) {
		log.debug("Request to View  contactUsSetup "+id );
		System.out.println("Request to View  contactUsSetup "+id);
		ContactUsSetup contactus =  contactUsSetupService.getContactUsSetupById(id);
		theModel.addAttribute("contactus", contactus);
	    return "systemAdmin/contactussetup/viewContactUsSetup";
	}
	
	@GetMapping("/editContactUsSetup")
	public String showFormForUpdate(@RequestParam("contactUsSetupId") Long id,Model theModel, HttpServletRequest request) {
		log.debug("Request to edit ContactUsSetup" +id);
		System.out.println("Request to edit ContactUsSetup "+id);
		ContactUsSetup contactus = new ContactUsSetup();
		//Get UserTemp by Id
		contactus =  contactUsSetupService.getContactUsSetupById(id);
		theModel.addAttribute("contactus", contactus);
		return "systemAdmin/contactussetup/updateContactUsSetup";
	}
	
	
	@PostMapping("/updateContactUsSetup")
	public String updateCentre(
			@ModelAttribute("contactus") @Valid ContactUsSetup theContactUsSetup,
			BindingResult bindingResult
			,@RequestParam(required=false , value = "updatebutn") String updateFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		log.debug("Request to Update Common contactUsSetup "+theContactUsSetup );
		System.out.println("Request to Update contactUsSetup "+theContactUsSetup);
		String successMessage = ""; String errorMessage="";
		boolean isPresentFlag = false;
		if (bindingResult.hasErrors()) {
			return "systemAdmin/contactussetup/updateContactUsSetup";
		}
		else if(!isPresentFlag) {
				successMessage =  Constants.UPDATE_SUCCESSFULLY;
				contactUsSetupService.updateContactUsSetup(theContactUsSetup, request);
				redirectAttributes.addFlashAttribute("successMessage",successMessage);
			}
	

			return "redirect:/systemAdmin/contactussetup/";
		
	}
	
}
