package com.iftas.eventportal.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.iftas.eventportal.dao.OrganizationRepository;
import com.iftas.eventportal.entity.Centres;
import com.iftas.eventportal.entity.Designation;
import com.iftas.eventportal.entity.EmailTemplate;
import com.iftas.eventportal.entity.Organization;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.service.OrganizationService;
import com.iftas.eventportal.util.GenerateExcelReport;

@Controller
@RequestMapping("/Masters/organization")
@PreAuthorize("hasPermission('','organization', 'READ_PRIVILEGE')")
public class OrganizationController {
	private final Logger log = LoggerFactory.getLogger(OrganizationController.class);
	@Autowired
	private OrganizationRepository organizationRepo;
	
	@Autowired
	private OrganizationService organizationService;
	
	@Autowired
	private GenerateExcelReport generateExcelReport;
	
	
	@GetMapping("/")
	@PreAuthorize("hasPermission('','organization', 'READ_PRIVILEGE')")
	public String listOrganization(Model theModel, HttpServletRequest request) {
		log.debug("Request to list Organization");
		System.out.println("Request to list Organization");
		List<Organization> organization = organizationService.getOrganizationList();
	    theModel.addAttribute("organization", organization);
	    return "Event/organization/listOrganization";
	}
	
	@GetMapping("/addOrganization")
	@PreAuthorize("hasPermission('','organization', 'ADD_PRIVILEGE')")
	public String showFormForAdd(Model theModel) {
		log.debug("Request to Add new Organization");
		System.out.println("Request to Add new Organization");
		Organization organization = new Organization();
		theModel.addAttribute("organization", organization);
		return "Event/organization/addOrganization";
	}
	
	@PostMapping("/createOrganization")
	@PostAuthorize("hasPermission('','organization', 'ADD_PRIVILEGE')")
	public String createOrganization(
			@ModelAttribute("organization") @Valid Organization theOrganization
			,BindingResult bindingResult
			,@RequestParam(required=false, value="addbutn") String addFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		
		log.debug("Request to Add new Organization" + theOrganization);
		System.out.println("Request to Add new Organization" + theOrganization);
		String succesMessage=""; String errorMessage="";
		if(bindingResult.hasErrors()) {
			return "/Event/organization/addOrganization";
		}else {
			if(organizationRepo.findByOrganizationNameIgnoreCase(request.getParameter("organizationName")).isPresent()) {
				System.out.println("Organization Name already exists");
				errorMessage = "Organization already exists";
				redirectAttributes.addFlashAttribute("errorMessage", errorMessage);
			}
		else {
				succesMessage = Constants.ADD_SUCCESSFULLY;
				organizationService.createOrganization(theOrganization, request);
				redirectAttributes.addFlashAttribute("succesMessage", succesMessage);
		}
		redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
		return "redirect:/Masters/organization/";
		}
}
	@GetMapping(value = "/viewOrganization")
	public String viewOrganization(@RequestParam("organizationId") Long id,Model theModel,HttpServletRequest request) {
		log.debug("Request to View  Organization "+id );
		System.out.println("Request to View  Organization "+id);
		Organization organization =  organizationService.getOrganizatiobById(id);
		theModel.addAttribute("organization", organization);
	    return "Event/organization/vieworganization";
	}
	
	@GetMapping("/editOrganization")
	@PreAuthorize("hasPermission('','organization', 'EDIT_PRIVILEGE')")
	public String showFormForUpdate(@RequestParam("organizationId") Long id,Model theModel, HttpServletRequest request) {
		log.debug("Request to Update Organization" +id);
		System.out.println("Request to Update  Organization "+id);
		Organization organization = new Organization();
		//Get UserTemp by Id
		organization =  organizationService.getOrganizatiobById(id);
		theModel.addAttribute("organization", organization);
		return "Event/organization/updateorganization";
	}
	
	
	@PostMapping("/updateOrganization")
	@PostAuthorize("hasPermission('','organization', 'EDIT_PRIVILEGE')")
	public String updateDesignation(
			@ModelAttribute("organization") @Valid Organization theOrganization,
			BindingResult bindingResult
			,@RequestParam(required=false , value = "updatebutn") String updateFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		log.debug("Request to Update Organization "+theOrganization );
		System.out.println("Request to Update Organization "+theOrganization);
		String successMessage = ""; String errorMessage="";
		boolean isPresentFlag = false;
		if (bindingResult.hasErrors()) {
			return "Event/organization/updateorganization";
		}
		else{
			Optional<Organization> existingOrganization =  organizationRepo.findByOrganizationNameIgnoreCase(theOrganization.getOrganizationName());
			if(existingOrganization.isPresent() && (!theOrganization.getOrganizationId().equals(existingOrganization.get().getOrganizationId()))) {
				System.out.println("Organization Name already exists");
				errorMessage = "Organization Name already exists";
				redirectAttributes.addFlashAttribute("errorMessage", errorMessage);
				isPresentFlag=true;
			}
			
			
			if(!isPresentFlag) {
				successMessage =  Constants.UPDATE_SUCCESSFULLY;
				//Step2 save the Holiday
				organizationService.updateOrganization(theOrganization, request);
				redirectAttributes.addFlashAttribute("successMessage",successMessage);
			}
	
		}
			return "redirect:/Masters/organization/";
		
	}
	@GetMapping(value = "/export")
	@PreAuthorize("hasPermission('','organization', 'EXPORT_PRIVILEGE')")
	public ResponseEntity<InputStreamResource> excelCommonSetupReport() throws IOException {
		List<Organization> organization =  organizationService.getOrganizationList();
		ByteArrayInputStream in = generateExcelReport.organizationToExcel(organization);
		// return IO ByteArray(in);
		HttpHeaders headers = new HttpHeaders();
		// set filename in header
		headers.add("Content-Disposition", "attachment; filename=organization.xlsx");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}
}
