package com.iftas.eventportal.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import com.iftas.eventportal.entity.CommonSetup;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.service.CommonSetupService;
import com.iftas.eventportal.util.GenerateExcelReport;



@Controller
@RequestMapping("/systemAdmin/commonsetup")
@PreAuthorize("hasPermission('','commonsetup', 'READ_PRIVILEGE')")
public class CommonSetupController {
	
	private final Logger log = LoggerFactory.getLogger(CommonSetupController.class);
	
	@Autowired
	private CommonSetupService commonSetupService;
	
	@Autowired
	private GenerateExcelReport generateExcelReport;
	
	
	@GetMapping("/")
	@PreAuthorize("hasPermission('','commonsetup', 'READ_PRIVILEGE')")
	public String listCommonSetup(Model theModel) {
		log.debug("Request to List Common Setup");
		List<CommonSetup> commonsetup =  commonSetupService.getCommonSetupListing(0);
		//Add to Model
		theModel.addAttribute("commonsetup", commonsetup);
		return "systemAdmin/commonsetup/listcommonsetup";
	}
	@GetMapping(value = "/viewCommonSetup")
	public String viewCommonSetup(@RequestParam("commonSetupId") Long id,Model theModel,HttpServletRequest request) {
		log.debug("Request to View  CommonSetup "+id );
		System.out.println("Request to View  CommonSetup "+id);
		CommonSetup commonSetup =  commonSetupService.getCommonSetupById(id);
		theModel.addAttribute("commonSetup", commonSetup);
	    return "systemAdmin/commonsetup/viewCommonSetup";
	}
	
	@GetMapping("/editCommonSetup")
	@PreAuthorize("hasPermission('','commonsetup', 'EDIT_PRIVILEGE')")
	public String showFormForUpdate(@RequestParam("commonSetupId") Long id,Model theModel, HttpServletRequest request) {
		log.debug("Request to edit Common Setup" +id);
		System.out.println("Request to edit Common Setup "+id);
		CommonSetup commonSetup = new CommonSetup();
		//Get UserTemp by Id
		commonSetup =  commonSetupService.getCommonSetupById(id);
		theModel.addAttribute("commonSetup", commonSetup);
		return "systemAdmin/commonsetup/updateCommonSetup";
	}
	
	
	@PostMapping("/updateCommonSetup")
	@PostAuthorize("hasPermission('','commonsetup', 'EDIT_PRIVILEGE')")
	public String updateCentre(
			@ModelAttribute("commonSetup") @Valid CommonSetup theCommonSetup,
			BindingResult bindingResult
			,@RequestParam(required=false , value = "updatebutn") String updateFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		log.debug("Request to Update Common Setup "+theCommonSetup );
		System.out.println("Request to UpdateCommon Setup "+theCommonSetup);
		String successMessage = ""; String errorMessage="";
		boolean isPresentFlag = false;
		if (bindingResult.hasErrors()) {
			return "systemAdmin/commonsetup/updateCommonSetup";
		}
		else if(!isPresentFlag) {
				successMessage =  Constants.UPDATE_SUCCESSFULLY;
				commonSetupService.updateCommonSetup(theCommonSetup, request);
				redirectAttributes.addFlashAttribute("successMessage",successMessage);
			}
	

			return "redirect:/systemAdmin/commonsetup/";
		
	}
	@GetMapping(value = "/export")
	@PreAuthorize("hasPermission('','commonsetup', 'EXPORT_PRIVILEGE')")
	public ResponseEntity<InputStreamResource> excelCommonSetupReport() throws IOException {
		List<CommonSetup> commonSetup =  commonSetupService.getCommonSetupListing(0);
		ByteArrayInputStream in = generateExcelReport.CommonSetupToExcel(commonSetup);
		// return IO ByteArray(in);
		HttpHeaders headers = new HttpHeaders();
		// set filename in header
		headers.add("Content-Disposition", "attachment; filename=CommonSetup.xlsx");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}
}
