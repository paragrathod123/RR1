package com.iftas.eventportal.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import com.iftas.eventportal.entity.EmailTemplate;
import com.iftas.eventportal.helper.Constants;

import com.iftas.eventportal.service.EmailTemplateService;
import com.iftas.eventportal.util.GenerateExcelReport;


@Controller
@RequestMapping("/systemAdmin/emailsetup")
@PreAuthorize("hasPermission('','emailsetup', 'READ_PRIVILEGE')")
public class EmailTemplateController {
private final Logger log = LoggerFactory.getLogger(EmailTemplateController.class);
	
	@Autowired
	private EmailTemplateService emailTemplateService;
	
	@Autowired
	private GenerateExcelReport generateExcelReport;
	
	@GetMapping("/")
	@PreAuthorize("hasPermission('','emailsetup', 'READ_PRIVILEGE')")
	public String listEmailSetup(Model theModel) {
		log.debug("Request to List Email Template Setup");
		List<EmailTemplate> emailSetup =  emailTemplateService.getEmailTemplate(0);
		//Add to Model
		theModel.addAttribute("emailSetup", emailSetup);
		return "systemAdmin/emailsetup/listemailsetup";
	}
	@GetMapping(value = "/viewEmailSetup")
	public String viewCommonSetup(@RequestParam("emailTemplateId") Long id,Model theModel,HttpServletRequest request) {
		log.debug("Request to View  Email Template Setup "+id );
		System.out.println("Request to Email Template Setup "+id);
		EmailTemplate emailSetup =  emailTemplateService.getEmailTemplateById(id);
		theModel.addAttribute("emailSetup", emailSetup);
	    return "systemAdmin/emailsetup/viewEmailSetup";
	}
	
	@GetMapping("/editEmailSetup")
	@PreAuthorize("hasPermission('','emailsetup', 'EDIT_PRIVILEGE')")
	public String showFormForUpdate(@RequestParam("emailTemplateId") Long id,Model theModel, HttpServletRequest request) {
		log.debug("Request to edit Email Template Setup" +id);
		System.out.println("Request to edit Email Template Setup "+id);
		EmailTemplate emailSetup = new EmailTemplate();
		//Get UserTemp by Id
		emailSetup =  emailTemplateService.getEmailTemplateById(id);
		theModel.addAttribute("emailSetup", emailSetup);
		return "systemAdmin/emailsetup/updateEmailSetup";
	}
	
	
	@PostMapping("/updateEmailSetup")
	@PostAuthorize("hasPermission('','emailsetup', 'EDIT_PRIVILEGE')")
	public String updateCentre(
			@ModelAttribute("emailSetup") @Valid EmailTemplate theEmailTemplate,
			BindingResult bindingResult
			,@RequestParam(required=false , value = "updatebutn") String updateFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		log.debug("Request to updateEmailSetup "+theEmailTemplate );
		System.out.println("Request to updateEmailSetup "+theEmailTemplate);
		String successMessage = ""; String errorMessage="";
		boolean isPresentFlag = false;
		if (bindingResult.hasErrors()) {
			return "systemAdmin/emailsetup/updateEmailSetup";
		}
		else if(!isPresentFlag) {
				successMessage =  Constants.UPDATE_SUCCESSFULLY;
				emailTemplateService.updateContactUsSetup(theEmailTemplate, request);
				redirectAttributes.addFlashAttribute("successMessage",successMessage);
			}
	

			return "redirect:/systemAdmin/emailsetup/";
		
	}
	@GetMapping(value = "/export")
	@PreAuthorize("hasPermission('','emailsetup', 'EXPORT_PRIVILEGE')")
	public ResponseEntity<InputStreamResource> excelCommonSetupReport() throws IOException {
		List<EmailTemplate> emailSetup =  emailTemplateService.getEmailTemplate(0);
		ByteArrayInputStream in = generateExcelReport.emailSetupToExcel(emailSetup);
		// return IO ByteArray(in);
		HttpHeaders headers = new HttpHeaders();
		// set filename in header
		headers.add("Content-Disposition", "attachment; filename=EmailSetup.xlsx");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}
	
}
