package com.iftas.eventportal.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.iftas.eventportal.dao.DesignationRepository;
import com.iftas.eventportal.entity.Designation;
import com.iftas.eventportal.entity.Organization;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.service.DesignationService;
import com.iftas.eventportal.util.GenerateExcelReport;

@Controller
@RequestMapping("/Masters/designation")
@PreAuthorize("hasPermission('','designation', 'READ_PRIVILEGE')")
public class DesignationController {
private final Logger log = LoggerFactory.getLogger(DesignationController.class);
	
	@Autowired
	DesignationRepository designationRepository;
	
	@Autowired
	DesignationService designationService;
	
	@Autowired
	private GenerateExcelReport generateExcelReport;
	
	@GetMapping("/")
	@PreAuthorize("hasPermission('','designation', 'READ_PRIVILEGE')")
	public String listDesignation(Model theModel, HttpServletRequest request) {
		log.debug("Request to list Designation");
		System.out.println("Request to list Designation");
		List<Designation> designation = designationService.getDesignationListing();
	    theModel.addAttribute("designation", designation);
	    return "Event/designation/listDesignation";
	}
	
	@GetMapping("/addDesignation")
	@PreAuthorize("hasPermission('','designation', 'ADD_PRIVILEGE')")
	public String showFormForAdd(Model theModel) {
		log.debug("Request to Add new Designation");
		System.out.println("Request to Add new Designation");
		Designation designation = new Designation();
		theModel.addAttribute("designation", designation);
		return "Event/designation/addDesignation";
	}
	
	@PostMapping("/createDesignation")
	@PostAuthorize("hasPermission('','designation', 'ADD_PRIVILEGE')")
	public String createDepartment(
			@ModelAttribute("designation") @Valid Designation theDesignation
			,BindingResult bindingResult
			,@RequestParam(required=false, value="addbutn") String addFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		
		log.debug("Request to Add new Designation" + theDesignation);
		System.out.println("Request to Add new Designation" + theDesignation);
		String succesMessage=""; String errorMessage="";
		if(bindingResult.hasErrors()) {
			return "/Event/designation/addDesignation";
		}else {
			if(designationRepository.findByDesignationNameIgnoreCase(request.getParameter("designationName")).isPresent()) {
				System.out.println("Designation Name already exists");
				errorMessage = "Designation Name already exists";
				redirectAttributes.addFlashAttribute("errorMessage", errorMessage);
			}
		else {
				succesMessage = Constants.ADD_SUCCESSFULLY;
				designationService.createDesignation(theDesignation,request);
				redirectAttributes.addFlashAttribute("succesMessage", succesMessage);
		}
		}
		redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
		return "redirect:/Masters/designation/";
		
}
	@GetMapping(value = "/viewDesignation")
	public String viewDesignation(@RequestParam("designationId") Long id,Model theModel,HttpServletRequest request) {
		log.debug("Request to View  Designation "+id );
		System.out.println("Request to View  Designation "+id);
		Designation designation =  designationService.getDesignationById(id);
		theModel.addAttribute("designation", designation);
	    return "Event/designation/viewdesignation";
	}
	
	@GetMapping("/editDesignation")
	@PreAuthorize("hasPermission('','designation', 'EDIT_PRIVILEGE')")
	public String showFormForUpdate(@RequestParam("designationId") Long id,Model theModel, HttpServletRequest request) {
		log.debug("Request to Update Designation" +id);
		System.out.println("Request to Update  Designation "+id);
		Designation designation = new Designation();
		//Get UserTemp by Id
		designation =  designationService.getDesignationById(id);
		theModel.addAttribute("designation", designation);
		return "Event/designation/updatedesignation";
	}
	
	
	@PostMapping("/updateDesignation")
	@PostAuthorize("hasPermission('','designation', 'EDIT_PRIVILEGE')")
	public String updateDesignation(
			@ModelAttribute("designation") @Valid Designation theDesignation,
			BindingResult bindingResult
			,@RequestParam(required=false , value = "updatebutn") String updateFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		log.debug("Request to Update Designation "+theDesignation );
		System.out.println("Request to Update Designation "+theDesignation);
		String successMessage = ""; String errorMessage="";
		boolean isPresentFlag = false;
		if (bindingResult.hasErrors()) {
			return "Event/designation/updatedesignation";
		}
		else {	
			Optional<Designation> existingDesignation =  designationRepository.findByDesignationNameIgnoreCase(theDesignation.getDesignationName());
			if(existingDesignation.isPresent() && (!theDesignation.getDesignationId().equals(existingDesignation.get().getDesignationId()))) {
				errorMessage = "Designation Already Present!";
				redirectAttributes.addFlashAttribute("errorMessage",errorMessage);
				isPresentFlag = true;
			}
			
			if(!isPresentFlag) {
				successMessage =  Constants.UPDATE_SUCCESSFULLY;
				//Step2 save the Holiday
				designationService.updateDesignation(theDesignation, request);
				redirectAttributes.addFlashAttribute("successMessage",successMessage);
			}
	

			return "redirect:/Masters/designation/";
		}
	}
	
	@GetMapping(value = "/export")
	@PreAuthorize("hasPermission('','designation', 'EXPORT_PRIVILEGE')")
	public ResponseEntity<InputStreamResource> excelCommonSetupReport() throws IOException {
		List<Designation> designation =  designationService.getDesignationListing();
		ByteArrayInputStream in = generateExcelReport.designationToExcel(designation);
		// return IO ByteArray(in);
		HttpHeaders headers = new HttpHeaders();
		// set filename in header
		headers.add("Content-Disposition", "attachment; filename=designation.xlsx");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}
}
