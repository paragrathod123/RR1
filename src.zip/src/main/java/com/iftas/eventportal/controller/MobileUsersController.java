package com.iftas.eventportal.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.iftas.eventportal.entity.Centres;
import com.iftas.eventportal.entity.EventMaster;
import com.iftas.eventportal.entity.MobileUsers;
import com.iftas.eventportal.helper.Constants;
import com.iftas.eventportal.service.MobileUserService;
import com.iftas.eventportal.util.GenerateExcelReport;

@Controller
@RequestMapping("/report/mobileusers")
@PreAuthorize("hasPermission('','mobileusers', 'READ_PRIVILEGE')")
public class MobileUsersController {
	private final Logger log = LoggerFactory.getLogger(MobileUsersController.class);
	
	@Autowired
	private MobileUserService mobileUserService;
	
	@Autowired
	private GenerateExcelReport generateExcelReport;
	
	
	
	@RequestMapping("/")
	public String listMobileUser(Model theModel, HttpServletRequest request) {
		log.debug("Request to list mobile Users");
		System.out.println("Requet to List Mobile Users");
		HttpSession session =  request.getSession();
		List<MobileUsers> mobileUsers = new ArrayList<MobileUsers>();
		
		if(session.getAttribute("markerType")!=null && !session.getAttribute("markerType").equals("") && !session.getAttribute("markerType").equals("null")) {
			if(Integer.parseInt((String)session.getAttribute("markerType")) == 0) {
				mobileUsers = mobileUserService.getMobileUserList();
			}
			if(Integer.parseInt((String)session.getAttribute("markerType")) == 1) {
				if(session.getAttribute("eventid")!=null && !session.getAttribute("eventid").equals("") && !session.getAttribute("eventid").equals("null")) {
					mobileUsers =  mobileUserService.getMobileUserListByEventId(Long.valueOf((String)session.getAttribute("eventid")));
				}
			}
		}
		theModel.addAttribute("mobileUsers", mobileUsers);
		return "Event/mobileusers/listmobileuser";
	}
	

	@GetMapping("/editMobileUser")
	@PreAuthorize("hasPermission('','mobileusers', 'EDIT_PRIVILEGE')")
	public String showFormForUpdate(@RequestParam("id") Long id,Model theModel, HttpServletRequest request) {
		log.debug("Request to Update Mobile User" +id);
		System.out.println("Request to Update  Mobile User "+id);
		MobileUsers mobileUser = new MobileUsers();
		mobileUser =  mobileUserService.getMobileUserById(id);
		theModel.addAttribute("mobileUser", mobileUser);
		return "Event/mobileusers/updateMobileUser";
	}
	
	@PostMapping("/updateMobileUser")
	@PostAuthorize("hasPermission('','mobileusers', 'EDIT_PRIVILEGE')")
	public String updateMobileUser(
			@ModelAttribute("mobileUser") @Valid MobileUsers theMobileUsers,
			BindingResult bindingResult
			,@RequestParam(required=false , value = "updatebutn") String updateFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		log.debug("Request to Update Mobile Users "+theMobileUsers );
		System.out.println("Request to Update Mobile Users "+theMobileUsers);
		String successMsg = ""; String errorMessage="";
		boolean isPresentFlag = false;
		if (bindingResult.hasErrors()) {
			return "Event/mobileusers/updateMobileUser";
		}
		else {
			successMsg =  Constants.UPDATE_SUCCESSFULLY;
			mobileUserService.updateMobileUsers(theMobileUsers, request);
			redirectAttributes.addFlashAttribute("successMsg",successMsg);
		}
		return "redirect:/Event/mobileusers/";
}
	
	@GetMapping(value = "/export")
	@PreAuthorize("hasPermission('','mobileusers', 'EXPORT_PRIVILEGE')")
	public ResponseEntity<InputStreamResource> excelCommonSetupReport(HttpServletRequest request) throws IOException {
        
		HttpSession session =  request.getSession();
		
		List<MobileUsers> mobileUsers = new ArrayList<MobileUsers>();
		
		if(session.getAttribute("markerType")!=null && !session.getAttribute("markerType").equals("") && !session.getAttribute("markerType").equals("null")) {
			if(Integer.parseInt((String)session.getAttribute("markerType")) == 0) {
				mobileUsers = mobileUserService.getMobileUserList();
			}
			if(Integer.parseInt((String)session.getAttribute("markerType")) == 1) {
				if(session.getAttribute("eventid")!=null && !session.getAttribute("eventid").equals("") && !session.getAttribute("eventid").equals("null")) {
					mobileUsers =  mobileUserService.getMobileUserListByEventId(Long.valueOf((String)session.getAttribute("eventid")));
				}
			}
		}
		ByteArrayInputStream in = generateExcelReport.mobileUserToExcel(mobileUsers);
		// return IO ByteArray(in);
		HttpHeaders headers = new HttpHeaders();
		// set filename in header
		headers.add("Content-Disposition", "attachment; filename=mobileUser.xlsx");
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}
}
