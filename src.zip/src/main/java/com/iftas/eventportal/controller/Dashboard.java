package com.iftas.eventportal.controller;


import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.iftas.eventportal.dao.EventSessionRepository;
import com.iftas.eventportal.dao.EventSpeakerRepository;
import com.iftas.eventportal.dao.RoleRepository;
import com.iftas.eventportal.dto.events;
import com.iftas.eventportal.entity.RoleMst;
import com.iftas.eventportal.entity.SpeakerMaster;
import com.iftas.eventportal.service.SpeakerService;

@RestController
@RequestMapping("/dashboard")
public class Dashboard {

	@Autowired
	EventSessionRepository eventSessionRepository;
	
	@Autowired
	RoleRepository roleRepository;
	
	@Autowired
	private SpeakerService speakerService;
	
	@Autowired
	private EventSpeakerRepository eventSpeakerRepository;
	
	@GetMapping("/api/events")
	public List<events> getEventSessionDetails(@RequestParam("Id") String eventId){
		
		List<events> events = new ArrayList<events>();
		events =  eventSessionRepository.getCalenderDashboardForGivenParameter(eventId);
		System.out.println("events Size "+events.size());
		return events;
	}
	
	@GetMapping("/api/getRoles")
	public List<RoleMst> getRoleDetails(@RequestParam("Id") int typeId){
		
		List<RoleMst> roles = new ArrayList<RoleMst>();
		if(typeId == 0) {
			roles   =  roleRepository.findAllMasterRole(0);
		}
		if(typeId == 1) {
			roles   =  roleRepository.findAllAdminRole(0);
		}
		return roles;
	}
	
	@GetMapping("/api/getSpeakers")
	public List<SpeakerMaster> getSpeakerDetails(@RequestParam("Id") Long id ,HttpServletRequest request, Model theModel){
		HttpSession session =  request.getSession();
		List<SpeakerMaster> speakers = new ArrayList<SpeakerMaster>();
	
				if(id != 0) {
					speakers = eventSpeakerRepository.findAllSpeakerByEventId(id);
				}
			for (SpeakerMaster speakerMaster : speakers) {
				System.out.println("dfdf "+speakerMaster.getSpeakerFirstName());
			}
		
		theModel.addAttribute("speakers", speakers);
		return speakers;
	}
	
	@GetMapping("/help")
	public void fileDownload(@RequestParam("url") String url, Model theModel,HttpServletRequest request,HttpServletResponse response ) throws IOException {
		//System.out.println("in file download  event ");
		System.out.println("url "+url);
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		System.out.println("filepath "+filePath);
		System.out.println(filePath + url);
		
		File file = new File(filePath + url);
		//file = file.getAbsoluteFile();
		//System.out.println("file "+file.getName().toString());
		//System.out.println("file absoule path : "+file.getAbsolutePath() + "canonical : "+file.getCanonicalPath());
		//File file = new File("F:\\DevelopmentEvent\\UploadFiles\\Templates\\EventUpload .xlsx");
		if (file.exists()) {

			//get the mimetype
			String mimeType = URLConnection.guessContentTypeFromName(file.getName());
			if (mimeType == null) {
				//unknown mimetype so set the mimetype to application/octet-stream
				mimeType = "application/octet-stream";
			}

			response.setContentType(mimeType);

			 //Here we have mentioned it to show as attachment
			 response.setHeader("Content-Disposition", String.format("attachment; filename=\"" + file.getName() + "\""));

			response.setContentLength((int) file.length());

			InputStream inputStream = new BufferedInputStream(new FileInputStream(file));

			FileCopyUtils.copy(inputStream, response.getOutputStream());
		}
 }
	
	
	
}
