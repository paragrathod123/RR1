package com.iftas.eventportal.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="privileges")
public class Privileges {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="privilegeid")
	private Long privilegeId;
	
	
	@Column(name="name")
	private String privilegeName;
	
	
	@ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name = "roleid")
	private RoleMst role;
	
	
	@OneToOne
	@JoinColumn(name="pageid")
	private PageMst pagePrivilages;
	
	@Column(name="is_Read")
	private Integer isReadPrivilage;
	
	@Column(name="is_Add")
	private Integer isAddPrivilage;
	
	@Column(name="is_Export")
	private Integer isExportPrivilage;
	
	@Column(name="is_Edit")
	private Integer isUpdatePrivilage;
	


	public Long getPrivilegeId() {
		return privilegeId;
	}


	public String getPrivilegeName() {
		return privilegeName;
	}


	
	public PageMst getPage() {
		return pagePrivilages;
	}


	public void setPrivilegeId(Long privilegeId) {
		this.privilegeId = privilegeId;
	}


	public void setPrivilegeName(String privilegeName) {
		this.privilegeName = privilegeName;
	}


	

	public void setPage(PageMst page) {
		this.pagePrivilages = page;
	}


	public RoleMst getRole() {
		return role;
	}


	public void setRole(RoleMst role) {
		this.role = role;
	}


	public PageMst getPagePrivilages() {
		return pagePrivilages;
	}


	public void setPagePrivilages(PageMst pagePrivilages) {
		this.pagePrivilages = pagePrivilages;
	}


	public Integer isReadPrivilage() {
		return isReadPrivilage;
	}


	public void setReadPrivilage(Integer isReadPrivilage) {
		this.isReadPrivilage = isReadPrivilage;
	}


	public Integer isAddPrivilage() {
		return isAddPrivilage;
	}


	public void setAddPrivilage(Integer isAddPrivilage) {
		this.isAddPrivilage = isAddPrivilage;
	}


	public Integer isExportPrivilage() {
		return isExportPrivilage;
	}


	public void setExportPrivilage(Integer isExportPrivilage) {
		this.isExportPrivilage = isExportPrivilage;
	}


	public Integer isUpdatePrivilage() {
		return isUpdatePrivilage;
	}


	public void setUpdatePrivilage(Integer isUpdatePrivilage) {
		this.isUpdatePrivilage = isUpdatePrivilage;
	}
	
}
