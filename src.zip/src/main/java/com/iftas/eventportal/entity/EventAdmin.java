package com.iftas.eventportal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.iftas.eventportal.helper.Constants;

@Entity
@Table(name="event_admin")
public class EventAdmin {
//`id`, `admin_full_name`, `admin_contact_address`, `admin_emailId`, `created_by`, `created_date`, `updated_by`, `updated_date`
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;
	
	
	//join column from event Master
	@JsonBackReference
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="event_id")
	private EventMaster eventAdmin; 
	
	@Column(name="admin_full_name")
	private String adminFullName;
	
	@Column(name="title")
	private String title;
	
	@OneToOne
	@JoinColumn(name="designation_id")
	private Designation designation;
	
	/*
	 * @Size(max = 12)
	 * 
	 * @Pattern(regexp="(^[0-9]*$)",message = "Please enter valid  Contact No")
	 */
	@Column(name="admin_contact_no")
	private String adminContactAddress; 
	
	/*
	 * @Email
	 * 
	 * @Pattern(regexp = Constants.EMAIL_PATTERN,message =
	 * "Please enter valid Email Id")
	 */
	@Size(min = 5, max = 100)
	@Column(name="admin_email_id")
	private String adminEmailId;
	
	@Column(name="created_by")
	private String adminCreatedBy;
	
	@Column(name="created_date")
	private String adminCreatedDate;
	
	@Column(name="updated_by")
	private String adminUpdatedBy;
	
	@Column(name="updated_date")
	private String adminUpdatedDate;
	
	@Column(name="active_status")
	private String activeStatus;
	
	public EventAdmin() {
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAdminFullName() {
		return adminFullName;
	}

	public void setAdminFullName(String adminFullName) {
		this.adminFullName = adminFullName;
	}

	public String getAdminContactAddress() {
		return adminContactAddress;
	}

	public void setAdminContactAddress(String adminContactAddress) {
		this.adminContactAddress = adminContactAddress;
	}

	public String getAdminEmailId() {
		return adminEmailId;
	}

	public void setAdminEmailId(String adminEmailId) {
		this.adminEmailId = adminEmailId;
	}

	public String getAdminCreatedBy() {
		return adminCreatedBy;
	}

	public void setAdminCreatedBy(String adminCreatedBy) {
		this.adminCreatedBy = adminCreatedBy;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Designation getDesignation() {
		return designation;
	}

	public void setDesignation(Designation designation) {
		this.designation = designation;
	}

	public String getAdminCreatedDate() {
		return adminCreatedDate;
	}

	public void setAdminCreatedDate(String adminCreatedDate) {
		this.adminCreatedDate = adminCreatedDate;
	}

	public String getAdminUpdatedBy() {
		return adminUpdatedBy;
	}

	public void setAdminUpdatedBy(String adminUpdatedBy) {
		this.adminUpdatedBy = adminUpdatedBy;
	}

	public String getAdminUpdatedDate() {
		return adminUpdatedDate;
	}

	public void setAdminUpdatedDate(String adminUpdatedDate) {
		this.adminUpdatedDate = adminUpdatedDate;
	}

	public EventMaster getEventAdmin() {
		return eventAdmin;
	}

	public void setEventAdmin(EventMaster eventAdmin) {
		this.eventAdmin = eventAdmin;
	}

	public String getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}
	
	
}
