package com.iftas.eventportal.entity;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="event_conference_information")
public class EventConferenceInformation {
	
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@OneToOne
	@JoinColumn(name="event_id")
	private EventMaster evenConferenceInfo;
	
	@Column(name="registeration_detail")
	private String registerationDetail;
	
	@Column(name="attendence_time_table")
	private String attendenceTimeTable;
	
	@Column(name="dress_code")
	private String dressCode;
	
	@Column(name="meals")
	private String meals;
	
	@Column(name="special_requirements")
	private String specialRequirements;
	
	@Column(name="presentations") 
	private String presentations;  
	
	@Column(name="transportation")
	private String transportation;
	
	
	@Column(name="welcome_message")
	private String welcomeMessage;


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public EventMaster getEvenConferenceInfo() {
		return evenConferenceInfo;
	}


	public void setEvenConferenceInfo(EventMaster evenConferenceInfo) {
		this.evenConferenceInfo = evenConferenceInfo;
	}


	public String getRegisterationDetail() {
		return registerationDetail;
	}


	public void setRegisterationDetail(String registerationDetail) {
		this.registerationDetail = registerationDetail;
	}


	public String getAttendenceTimeTable() {
		return attendenceTimeTable;
	}


	public void setAttendenceTimeTable(String attendenceTimeTable) {
		this.attendenceTimeTable = attendenceTimeTable;
	}


	public String getDressCode() {
		return dressCode;
	}


	public void setDressCode(String dressCode) {
		this.dressCode = dressCode;
	}


	public String getMeals() {
		return meals;
	}


	public void setMeals(String meals) {
		this.meals = meals;
	}


	public String getSpecialRequirements() {
		return specialRequirements;
	}


	public void setSpecialRequirements(String specialRequirements) {
		this.specialRequirements = specialRequirements;
	}


	public String getPresentations() {
		return presentations;
	}


	public void setPresentations(String presentations) {
		this.presentations = presentations;
	}


	public String getTransportation() {
		return transportation;
	}


	public void setTransportation(String transportation) {
		this.transportation = transportation;
	}


	public String getWelcomeMessage() {
		return welcomeMessage;
	}


	public void setWelcomeMessage(String welcomeMessage) {
		this.welcomeMessage = welcomeMessage;
	}


	@Override
	public String toString() {
		return "EventConferenceInformation [id=" + id + ", evenConferenceInfo=" + evenConferenceInfo
				+ ", registerationDetail=" + registerationDetail + ", attendenceTimeTable=" + attendenceTimeTable
				+ ", dressCode=" + dressCode + ", meals=" + meals + ", specialRequirements=" + specialRequirements
				+ ", presentations=" + presentations + ", transportation=" + transportation + ", welcomeMessage="
				+ welcomeMessage + "]";
	}
	
	
	
	
	
	

}
