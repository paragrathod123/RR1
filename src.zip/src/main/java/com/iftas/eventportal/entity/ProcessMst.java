package com.iftas.eventportal.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="processmst")
public class ProcessMst {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="processid")
	private Long processId;
	
	
	@Column(name="name")
	private String name;
	
	@Column(name="active_status")
	private int activeStatus;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="pageid")
	private PageMst page;
	
	

	public Long getProcessId() {
		return processId;
	}

	public void setProcessId(Long processId) {
		this.processId = processId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(int activeStatus) {
		this.activeStatus = activeStatus;
	}

	public PageMst getPage() {
		return page;
	}

	public void setPage(PageMst page) {
		this.page = page;
	}

}
