package com.iftas.eventportal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;



@Entity
@Table(name = "event_speakers")
public class EventSpeakers {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long eventSpeakerId;
	

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="event_id")
	private EventMaster eventSpeakers; 
	
	@OneToOne
	@JoinColumn(name="speaker_id")
	private SpeakerMaster eventSpeaker;
	
	@Column(name="room_no")
	private String roomNo;
	
	@Column(name="emergency_contact_no")
	private String emergencyContactNo;
	
	@Column(name="allergies")
	private String allergies;
	
	@Column(name="driver_name")
	private String driverName;
	
	
	@Transient
	private String loginId;
	
	@Transient
	private Integer isAdmin;
	
	@Transient
	private String loginMobileNo;
	
	
	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public String getDriverContactNo() {
		return driverContactNo;
	}

	public void setDriverContactNo(String driverContactNo) {
		this.driverContactNo = driverContactNo;
	}

	public String getDriverCabNo() {
		return driverCabNo;
	}

	public void setDriverCabNo(String driverCabNo) {
		this.driverCabNo = driverCabNo;
	}

	@Column(name="driver_contact_no")
	private String driverContactNo;
	
	@Column(name="driver_cab_no")
	private String driverCabNo;

	public Long getEventSpeakerId() {
		return eventSpeakerId;
	}

	public void setEventSpeakerId(Long eventSpeakerId) {
		this.eventSpeakerId = eventSpeakerId;
	}

	public EventMaster getEventSpeakers() {
		return eventSpeakers;
	}

	public void setEventSpeakers(EventMaster eventSpeakers) {
		this.eventSpeakers = eventSpeakers;
	}

	public SpeakerMaster getEventSpeaker() {
		return eventSpeaker;
	}

	public void setEventSpeaker(SpeakerMaster eventSpeaker) {
		this.eventSpeaker = eventSpeaker;
	}

	public String getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}

	public String getEmergencyContactNo() {
		return emergencyContactNo;
	}

	public void setEmergencyContactNo(String emergencyContactNo) {
		this.emergencyContactNo = emergencyContactNo;
	}

	public String getAllergies() {
		return allergies;
	}

	public void setAllergies(String allergies) {
		this.allergies = allergies;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public Integer getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Integer isAdmin) {
		this.isAdmin = isAdmin;
	}

	public String getLoginMobileNo() {
		return loginMobileNo;
	}

	public void setLoginMobileNo(String loginMobileNo) {
		this.loginMobileNo = loginMobileNo;
	}
	
	
	
	
	
}
