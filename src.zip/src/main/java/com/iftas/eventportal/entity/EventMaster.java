package com.iftas.eventportal.entity;

import java.time.Instant;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


@Entity
@Table(name = "event_master")
public class EventMaster {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long eventId;
	
	@OneToOne
	@JoinColumn(name="department_id")
	private Department eventDepartment;
	
	@OneToOne
	@JoinColumn(name="product_id")
	private ProductMaster eventProduct;

//	@ManyToOne(cascade=CascadeType.ALL)
//	@JoinColumn(name="department_id")
//	private Department eventDepartment;
//	
//	@ManyToOne(cascade=CascadeType.ALL)
//	@JoinColumn(name="product_id")
//	private ProductMaster eventProduct;
	
	@Column(name="event_name")
	private String eventName;
	
	@Column(name="event_start_date")
	private String eventStartDate ;
	
	@Column(name="event_end_date")
	private String eventEndDate ;
	
	@Column(name="event_expiry_date")
	private String eventExpiryDate ;
	
	@Column(name="event_location_place_name")
	private String eventLocationPlaceName ;
	
	@Column(name="event_location_information")
	private String eventLocationInformation ;
	
	@Column(name="venue_Address")
	private String eventVenueAddress ;
	
	
	@Column(name="venue_pincode")
	private String eventVenuePincode ;
	
	@Column(name="venue_longitude")
	private String eventVenueLongitude ;
	
	@Column(name="venue_latittude")
	private String eventVenueLatittude ;
	
	@Column(name="folder_name")
	private String eventVenueFolderName ;
	
	@Column(name="file_name")
	private String eventVenueFileName ;
	
	@Column(name="file_description")
	private String eventVenueFileDescription ;
	
	@Column(name="status")
	private int activeStatus;
	
	
	@Column(name="created_by")
	private Integer createdBy;
	
	@Column(name="created_date")
	private Instant createdDate;
	
	@Column(name="updated_by")
	private Integer modifiedBy;
	
	@Column(name="updated_date")
	private Instant modifiedDate;
	
	@Transient
	private String transportToVenueFileName; 
	
	@OneToOne(mappedBy="evenConferenceInfo")
	private EventConferenceInformation eventConferenceInformation;

	
	@OneToMany(mappedBy="eventSpeakers")
	Set<EventSpeakers> eventSpeakerSet;
	
	@OneToMany(mappedBy="eventParticipants")
	Set<EventParticipants> eventParticipantSet;
	
	
	@OneToMany(mappedBy="eventSessions")
	Set<EventSessionRef> eventSessionSet;

	@OneToMany(mappedBy="eventAdmin")
	Set<EventAdmin> eventAdminSet;
	
	@OneToMany(mappedBy="eventTransport")
	Set<EventTransportaion> eventTransportSet;
	
	@OneToMany(mappedBy="eventGallery")
	Set<EventGallery> eventGallerySet;
	

	public Set<EventGallery> getEventGallerySet() {
		return eventGallerySet;
	}


	public void setEventGallerySet(Set<EventGallery> eventGallerySet) {
		this.eventGallerySet = eventGallerySet;
	}


	public Long getEventId() {
		return eventId;
	}


	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}


	public Department getEventDepartment() {
		return eventDepartment;
	}


	public void setEventDepartment(Department eventDepartment) {
		this.eventDepartment = eventDepartment;
	}


	public ProductMaster getEventProduct() {
		return eventProduct;
	}


	public void setEventProduct(ProductMaster eventProduct) {
		this.eventProduct = eventProduct;
	}


	public String getEventName() {
		return eventName;
	}


	public void setEventName(String eventName) {
		this.eventName = eventName;
	}


	public String getEventStartDate() {
		return eventStartDate;
	}


	public void setEventStartDate(String eventStartDate) {
		this.eventStartDate = eventStartDate;
	}


	public String getEventEndDate() {
		return eventEndDate;
	}


	public void setEventEndDate(String eventEndDate) {
		this.eventEndDate = eventEndDate;
	}


	public String getEventExpiryDate() {
		return eventExpiryDate;
	}


	public void setEventExpiryDate(String eventExpiryDate) {
		this.eventExpiryDate = eventExpiryDate;
	}


	public String getEventLocationPlaceName() {
		return eventLocationPlaceName;
	}


	public void setEventLocationPlaceName(String eventLocationPlaceName) {
		this.eventLocationPlaceName = eventLocationPlaceName;
	}


	public String getEventLocationInformation() {
		return eventLocationInformation;
	}


	public void setEventLocationInformation(String eventLocationInformation) {
		this.eventLocationInformation = eventLocationInformation;
	}


	public String getEventVenueAddress() {
		return eventVenueAddress;
	}


	public void setEventVenueAddress(String eventVenueAddress) {
		this.eventVenueAddress = eventVenueAddress;
	}


	public String getEventVenuePincode() {
		return eventVenuePincode;
	}


	public void setEventVenuePincode(String eventVenuePincode) {
		this.eventVenuePincode = eventVenuePincode;
	}


	public String getEventVenueLongitude() {
		return eventVenueLongitude;
	}


	public void setEventVenueLongitude(String eventVenueLongitude) {
		this.eventVenueLongitude = eventVenueLongitude;
	}


	public String getEventVenueLatittude() {
		return eventVenueLatittude;
	}


	public void setEventVenueLatittude(String eventVenueLatittude) {
		this.eventVenueLatittude = eventVenueLatittude;
	}


	public String getEventVenueFolderName() {
		return eventVenueFolderName;
	}


	public void setEventVenueFolderName(String eventVenueFolderName) {
		this.eventVenueFolderName = eventVenueFolderName;
	}


	public String getEventVenueFileName() {
		return eventVenueFileName;
	}


	public void setEventVenueFileName(String eventVenueFileName) {
		this.eventVenueFileName = eventVenueFileName;
	}


	public String getEventVenueFileDescription() {
		return eventVenueFileDescription;
	}


	public void setEventVenueFileDescription(String eventVenueFileDescription) {
		this.eventVenueFileDescription = eventVenueFileDescription;
	}


	public int getActiveStatus() {
		return activeStatus;
	}


	public void setActiveStatus(int activeStatus) {
		this.activeStatus = activeStatus;
	}


	public Integer getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}


	public Instant getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}


	public Integer getModifiedBy() {
		return modifiedBy;
	}


	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}


	public Instant getModifiedDate() {
		return modifiedDate;
	}


	public void setModifiedDate(Instant modifiedDate) {
		this.modifiedDate = modifiedDate;
	}


	public EventConferenceInformation getEventConferenceInformation() {
		return eventConferenceInformation;
	}


	public void setEventConferenceInformation(EventConferenceInformation eventConferenceInformation) {
		this.eventConferenceInformation = eventConferenceInformation;
	}


	public Set<EventSpeakers> getEventSpeakerSet() {
		return eventSpeakerSet;
	}


	public void setEventSpeakerSet(Set<EventSpeakers> eventSpeakerSet) {
		this.eventSpeakerSet = eventSpeakerSet;
	}


	public Set<EventParticipants> getEventParticipantSet() {
		return eventParticipantSet;
	}


	public void setEventParticipantSet(Set<EventParticipants> eventParticipantSet) {
		this.eventParticipantSet = eventParticipantSet;
	}


	public Set<EventSessionRef> getEventSessionSet() {
		return eventSessionSet;
	}


	public void setEventSessionSet(Set<EventSessionRef> eventSessionSet) {
		this.eventSessionSet = eventSessionSet;
	}


	public Set<EventAdmin> getEventAdminSet() {
		return eventAdminSet;
	}


	public void setEventAdminSet(Set<EventAdmin> eventAdminSet) {
		this.eventAdminSet = eventAdminSet;
	}


	public Set<EventTransportaion> getEventTransportSet() {
		return eventTransportSet;
	}


	public void setEventTransportSet(Set<EventTransportaion> eventTransportSet) {
		this.eventTransportSet = eventTransportSet;
	}


	public String getTransportToVenueFileName() {
		return transportToVenueFileName;
	}


	public void setTransportToVenueFileName(String transportToVenueFileName) {
		this.transportToVenueFileName = transportToVenueFileName;
	}
	
	
	
	
	
	
	
	
	
	
	
}
