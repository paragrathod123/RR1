package com.iftas.eventportal.entity;

import java.time.Instant;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import com.iftas.eventportal.helper.Constants;


@Entity
@Table(name = "users")
public class User {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="userid")
	private Long userId;
	
	
	@NotNull
    @Pattern(regexp = Constants.LOGIN_REGEX,message = "Please enter valid login Id")
    @Size(min = 5, max = 50)
	@Column(name="login")
	private String login;
	
	@Column(name="password_hash")
	private String passwordHash;
	
	@Column(name="title")
	private String title;
	
	@NotNull
	@Size(max = 50)
	@Column(name="first_name")
	private String userName;
	
	@Size(max = 50)
	@Column(name="last_name")
	private String lastName;
	
	/*
	 * @Email
	 * 
	 * @Pattern(regexp = Constants.EMAIL_PATTERN,message =
	 * "Please enter valid Email Id")
	 */
	@Size(min = 5, max = 100)
    @Column(name="email")
	private String email;
	
    //@Size(max = 12)
    //@Pattern(regexp="(^$|[0-9]{10})",message = "Please enter valid Mobile No")
	@Column(name="mobile")
	private String mobileNo;
	
	@Column(name="markertype")
	private int markerType;
	
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "roleid")
	private RoleMst role;
	
	@Column(name="active_status")
	private int activeStatus;
	
	@Column(name="activation_key")
	private String activationKey;
	
	@Column(name="reset_date")
	private Instant resetDate;
	
	@Column(name="reset_key")
	private String resetKey;
	
	@Column(name="user_type")
	private int userType;
	
	
	@Column(name="remarks")
	private String remarks;
	
	
	@Column(name="created_by")
	private Integer createdBy;
	
	@Column(name="created_date")
	private Instant createdDate;
	
	@Column(name="last_modified_by")
	private Integer modifiedBy;
	
	@Column(name="last_modified_date")
	private Instant modifiedDate;

	@Column(name="failed_count")
	private int failedCount;
	
	@Column(name="locked")
	private int locked;
	
//	@JsonIgnore
//    @ManyToMany
//    @JoinTable(
//        name = "jhi_user_authority",
//        joinColumns = {@JoinColumn(name = "user_id", referencedColumnName = "userid")},
//        inverseJoinColumns = {@JoinColumn(name = "authority_name", referencedColumnName = "name")})
//    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
//    @BatchSize(size = 20)
//    private Set<Authority> authorities = new HashSet<>();
	
	@Column(name="ip_address")
	private String ipAdress;
	
	@Column(name="last_logged_on")
	private Instant loggedInTime;
	
	
	@OneToOne
	@JoinColumn(name="organization_id")
	private Organization userOrganization;
	
	@OneToOne
	@JoinColumn(name="center_id")
	private Centres userCenter;
	
	
	@OneToOne
	@JoinColumn(name="department_id")
	private Department userDepartment;
	
	@OneToOne
	@JoinColumn(name="designation_id")
	private Designation userDesignation;
	
	@Column(name="folder_name")
	private String userFolderName ;
	
	@Column(name="file_name")
	private String userFileName ;
	
	@Column(name="file_description")
	private String userFileDescription ;
	
	@Column(name="event_id")
	private Integer eventId;
	
	
	@Column(name="last_reset_date")
	private Instant lastResetDate;
	
	
	
	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userTempId) {
		this.userId = userTempId;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPasswordHash() {
		return passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getMarkerType() {
		return markerType;
	}

	public void setMarkerType(int markerType) {
		this.markerType = markerType;
	}

	
	
	
	public RoleMst getRole() {
		return role;
	}

	public void setRole(RoleMst role) {
		this.role = role;
	}

	public int getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(int activeStatus) {
		this.activeStatus = activeStatus;
	}

	public String getActivationKey() {
		return activationKey;
	}

	public void setActivationKey(String activationKey) {
		this.activationKey = activationKey;
	}

	public Instant getResetDate() {
		return resetDate;
	}

	public void setResetDate(Instant resetDate) {
		this.resetDate = resetDate;
	}

	public String getResetKey() {
		return resetKey;
	}

	public void setResetKey(String resetKey) {
		this.resetKey = resetKey;
	}

	public int getUserType() {
		return userType;
	}

	public void setUserType(int userType) {
		this.userType = userType;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Instant getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Instant modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public int getFailedCount() {
		return failedCount;
	}

	public void setFailedCount(int failedCount) {
		this.failedCount = failedCount;
	}

	public int getLocked() {
		return locked;
	}

	public void setLocked(int locked) {
		this.locked = locked;
	}

	public String getIpAdress() {
		return ipAdress;
	}

	public void setIpAdress(String ipAdress) {
		this.ipAdress = ipAdress;
	}

	public Instant getLoggedInTime() {
		return loggedInTime;
	}

	public void setLoggedInTime(Instant loggedInTime) {
		this.loggedInTime = loggedInTime;
	}

	public Organization getUserOrganization() {
		return userOrganization;
	}

	public void setUserOrganization(Organization userOrganization) {
		this.userOrganization = userOrganization;
	}

	public Centres getUserCenter() {
		return userCenter;
	}

	public void setUserCenter(Centres userCenter) {
		this.userCenter = userCenter;
	}

	public Department getUserDepartment() {
		return userDepartment;
	}

	public void setUserDepartment(Department userDepartment) {
		this.userDepartment = userDepartment;
	}

	public Designation getUserDesignation() {
		return userDesignation;
	}

	public void setUserDesignation(Designation userDesignation) {
		this.userDesignation = userDesignation;
	}

	public String getUserFolderName() {
		return userFolderName;
	}

	public void setUserFolderName(String userFolderName) {
		this.userFolderName = userFolderName;
	}

	public String getUserFileName() {
		return userFileName;
	}

	public void setUserFileName(String userFileName) {
		this.userFileName = userFileName;
	}

	public String getUserFileDescription() {
		return userFileDescription;
	}

	public void setUserFileDescription(String userFileDescription) {
		this.userFileDescription = userFileDescription;
	}

	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	public Instant getLastResetDate() {
		return lastResetDate;
	}

	public void setLastResetDate(Instant lastResetDate) {
		this.lastResetDate = lastResetDate;
	}
	
	
//	 public Set<Authority> getAuthorities() {
//	        return authorities;
//	    }
//
//	    public void setAuthorities(Set<Authority> authorities) {
//	        this.authorities = authorities;
//	    }
	
	/*
	 * @Override public boolean equals(Object obj) { if (this == obj) return true;
	 * if (obj == null) return false; if (getClass() != obj.getClass()) return
	 * false; User other = (User) obj; if (userId != other.userId) return false;
	 * return true; }
	 */

	
	
	
	
}
