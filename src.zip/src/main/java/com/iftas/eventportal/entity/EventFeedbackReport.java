package com.iftas.eventportal.entity;

public class EventFeedbackReport {

	private String departmentName;
	private String eventName;
	private String SessionName;
	private String speakerName;
	private String RatingName;
	private String eventDate;
	private String userName;
	
	
	public EventFeedbackReport(String departmentName, String eventName, String sessionName, String speakerName,
			String ratingName, String eventDate, String userName) {
		super();
		this.departmentName = departmentName;
		this.eventName = eventName;
		this.SessionName = sessionName;
		this.speakerName = speakerName;
		this.RatingName = ratingName;
		this.eventDate = eventDate;
		this.userName = userName;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getSessionName() {
		return SessionName;
	}
	public void setSessionName(String sessionName) {
		SessionName = sessionName;
	}

	public String getSpeakerName() {
		return speakerName;
	}
	public void setSpeakerName(String speakerName) {
		this.speakerName = speakerName;
	}
	public String getRatingName() {
		return RatingName;
	}
	public void setRatingName(String ratingName) {
		RatingName = ratingName;
	}
	public String getEventDate() {
		return eventDate;
	}
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Override
	public String toString() {
		return "EventFeedbackReport [departmentName=" + departmentName + ", eventName=" + eventName + ", SessionName="
				+ SessionName + ", speakerName=" + speakerName + ", RatingName=" + RatingName + ", eventDate=" + eventDate
				+ ", userName=" + userName + "]";
	}
	
	
	 
	
	
}
