package com.iftas.eventportal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "transportation_details")
public class EventTransportaion {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long transportId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="event_id")
	private EventMaster eventTransport; 
	
	@Column(name="folder_name")
	private String transportFolderName ;
	
	@Column(name="file_name")
	private String transportFileName ;
	
	@Column(name="file_description")
	private String transportFileDescription ;

	public Long getTransportId() {
		return transportId;
	}

	public void setTransportId(Long transportId) {
		this.transportId = transportId;
	}

	public EventMaster getEventTransport() {
		return eventTransport;
	}

	public void setEventTransport(EventMaster eventTransport) {
		this.eventTransport = eventTransport;
	}

	public String getTransportFolderName() {
		return transportFolderName;
	}

	public void setTransportFolderName(String transportFolderName) {
		this.transportFolderName = transportFolderName;
	}

	public String getTransportFileName() {
		return transportFileName;
	}

	public void setTransportFileName(String transportFileName) {
		this.transportFileName = transportFileName;
	}

	public String getTransportFileDescription() {
		return transportFileDescription;
	}

	public void setTransportFileDescription(String transportFileDescription) {
		this.transportFileDescription = transportFileDescription;
	}
	
	
	

}
