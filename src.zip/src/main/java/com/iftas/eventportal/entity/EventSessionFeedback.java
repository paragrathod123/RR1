package com.iftas.eventportal.entity;

import java.time.Instant;
//department_name, event_name, session_name, speaker_name, rating_name, event_date, user_name

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
@SqlResultSetMapping(name="eventFeedbackList",
classes = {
		  @ConstructorResult(
		          targetClass = EventFeedbackReport.class,
		          columns = {
		           
		              @ColumnResult(name="department_name", type = String.class),
		              @ColumnResult(name="event_name", type = String.class),
		              @ColumnResult(name="session_name", type = String.class),
		              @ColumnResult(name="speaker_name", type = String.class),
		              @ColumnResult(name="rating_name", type = String.class),
		              @ColumnResult(name="event_date", type = String.class),
		              @ColumnResult(name="user_name", type = String.class),
		        
		          })
		})
@Entity
@Table(name="event_session_feedback")
public class EventSessionFeedback {

	// id, department_id, event_Id, event_session_Id, ,user_id
//user_type, rating_type, rating_name, created_date, created_by, isFeedbackSubmit
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="department_id")
	private Integer departmentId;
	
	@Column(name="event_Id")
	private Integer eventId;
	
	@Column(name="event_session_Id")
	private Integer eventSessionId;
	
	@Column(name="user_id")
	private Integer userId;
	
	@Column(name="user_type")
	private Integer userType;
	
	@Column(name="rating_type")
	private Integer ratingType;
	
	@Column(name="rating_name")
	private String ratingName;
	
	@Column(name="created_date")
	private Instant createdDate;
	
	@Column(name="created_by")
	private Integer createdBy;
	
	@Column(name="is_feedback_submit")
	private Integer isFeebbackSubmit;

	@Column(name="speaker_id")
	private Integer speakerId;
	
	public EventSessionFeedback() {
		
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	public Integer getEventSessionId() {
		return eventSessionId;
	}

	public void setEventSessionId(Integer eventSessionId) {
		this.eventSessionId = eventSessionId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getUserType() {
		return userType;
	}

	public void setUserType(Integer userType) {
		this.userType = userType;
	}

	public Integer getRatingType() {
		return ratingType;
	}

	public void setRatingType(Integer ratingType) {
		this.ratingType = ratingType;
	}

	public String getRatingName() {
		return ratingName;
	}

	public void setRatingName(String ratingName) {
		this.ratingName = ratingName;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getIsFeebbackSubmit() {
		return isFeebbackSubmit;
	}

	public void setIsFeebbackSubmit(Integer isFeebbackSubmit) {
		this.isFeebbackSubmit = isFeebbackSubmit;
	}

	
	


	public Integer getSpeakerId() {
		return speakerId;
	}

	public void setSpeakerId(Integer speakerId) {
		this.speakerId = speakerId;
	}

	@Override
	public String toString() {
		return "EventSessionFeedback [id=" + id + ", departmentId=" + departmentId + ", eventId=" + eventId
				+ ", eventSessionId=" + eventSessionId + ", userId=" + userId + ", userType=" + userType
				+ ", ratingType=" + ratingType + ", ratingName=" + ratingName + ", createdDate=" + createdDate
				+ ", createdBy=" + createdBy + ", isFeebbackSubmit=" + isFeebbackSubmit + ", speakerId=" + speakerId
				+ "]";
	}

	
	

	
}
