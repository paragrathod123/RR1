package com.iftas.eventportal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "event_gallery")
public class EventGallery {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long eventGalleryId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="event_id")
	private EventMaster eventGallery; 
	
	@Column(name="folder_name")
	private String galleryFolderName ;
	
	@Column(name="file_name")
	private String galleryFileName ;
	
	@Column(name="file_description")
	private String galleryFileDescription ;

	public Long getEventGalleryId() {
		return eventGalleryId;
	}

	public void setEventGalleryId(Long eventGalleryId) {
		this.eventGalleryId = eventGalleryId;
	}

	public EventMaster getEventGallery() {
		return eventGallery;
	}

	public void setEventGallery(EventMaster eventGallery) {
		this.eventGallery = eventGallery;
	}

	public String getGalleryFolderName() {
		return galleryFolderName;
	}

	public void setGalleryFolderName(String galleryFolderName) {
		this.galleryFolderName = galleryFolderName;
	}

	public String getGalleryFileName() {
		return galleryFileName;
	}

	public void setGalleryFileName(String galleryFileName) {
		this.galleryFileName = galleryFileName;
	}

	public String getGalleryFileDescription() {
		return galleryFileDescription;
	}

	public void setGalleryFileDescription(String galleryFileDescription) {
		this.galleryFileDescription = galleryFileDescription;
	}
	
	
	
	
}
