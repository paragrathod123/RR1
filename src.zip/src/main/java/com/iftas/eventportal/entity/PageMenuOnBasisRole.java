package com.iftas.eventportal.entity;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;



@Entity
@SqlResultSetMapping(name="PagesWithPrivilegesOnBasisOfRoleId",entities={
	       @EntityResult(entityClass=PageMenuOnBasisRole.class, fields={ 
	       @FieldResult(name="pageid", column="pageid"),
	       @FieldResult(name="pageName", column="pageName"),
	       @FieldResult(name="menuId", column="menuid"),
	       @FieldResult(name="readPrivilage", column="is_Read"),
	       @FieldResult(name="addPrivilage", column="is_Add"),
	       @FieldResult(name="exportPrivilage", column="is_Export"),
	       @FieldResult(name="updatePrivilage", column="is_Edit")})
	})
@SqlResultSetMapping(name="SelectedPagesWithPrivilegesOnBasisOfRoleId",entities={
       @EntityResult(entityClass=PageMenuOnBasisRole.class, fields={ 
       @FieldResult(name="pageid", column="pageid"),
       @FieldResult(name="pageName", column="pageName"),
       @FieldResult(name="menuId", column="menuid"),
       @FieldResult(name="readPrivilage", column="is_Read"),
       @FieldResult(name="addPrivilage", column="is_Add"),
       @FieldResult(name="exportPrivilage", column="is_Export"),
       @FieldResult(name="updatePrivilage", column="is_Edit")})
})
@Table(name = "pagemenuonbasisrole")
public class PageMenuOnBasisRole {

	@Id
	private Long pageid;
	
	private String pageName;
	
	private Long menuId;
	
	private Integer readPrivilage;
	
	private Integer addPrivilage;
	
	private Integer exportPrivilage;
	
	private Integer updatePrivilage;

	
	public PageMenuOnBasisRole() {
		
	}


	public Long getPageid() {
		return pageid;
	}


	public void setPageid(Long pageid) {
		this.pageid = pageid;
	}


	public String getPageName() {
		return pageName;
	}


	public void setPageName(String pageName) {
		this.pageName = pageName;
	}


	public Long getMenuId() {
		return menuId;
	}


	public void setMenuId(Long menuId) {
		this.menuId = menuId;
	}


	public Integer getReadPrivilage() {
		return readPrivilage;
	}


	public void setReadPrivilage(Integer readPrivilage) {
		this.readPrivilage = readPrivilage;
	}


	public Integer getAddPrivilage() {
		return addPrivilage;
	}


	public void setAddPrivilage(Integer addPrivilage) {
		this.addPrivilage = addPrivilage;
	}


	public Integer getExportPrivilage() {
		return exportPrivilage;
	}


	public void setExportPrivilage(Integer exportPrivilage) {
		this.exportPrivilage = exportPrivilage;
	}


	public Integer getUpdatePrivilage() {
		return updatePrivilage;
	}


	public void setUpdatePrivilage(Integer updatePrivilage) {
		this.updatePrivilage = updatePrivilage;
	}
}
