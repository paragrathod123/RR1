package com.iftas.eventportal.entity;

import java.time.Instant;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name="speakers")
public class SpeakerMaster {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long speakerId;
	
	@Column(name="title")
	private String title;
	
	@Column(name="first_name")
	private String speakerFirstName;
	
	@Column(name="last_name")
	private String speakerLastName;
	
	@OneToOne
	@JoinColumn(name="organization_id")
	private Organization speakerOrganization;
	
	@OneToOne
	@JoinColumn(name="center_id")
	private Centres speakerCenter;
	
	
	@OneToOne
	@JoinColumn(name="department_id")
	private Department speakerDepartment;
	
	@OneToOne
	@JoinColumn(name="designation_id")
	private Designation speakerDesignation;
	
	
	@Column(name="profile")
	private String speakerProfile;
	
	@Column(name="mobile_no")
	private String speakerMobileNo;
	
	@Column(name="email_id")
	private String speakerEmailId;
	
	@Column(name="folder_name")
	private String speakerFolderName ;
	
	@Column(name="file_name")
	private String speakerFileName ;
	
	@Column(name="file_description")
	private String speakerFileDescription ;
	
	
	@Column(name="active_status")
	private int activeStatus;
	
	@Column(name="is_panelist")
	private int isPanelist;
	
	@Column(name="created_by")
	private Integer  createdBy;
	
	@Column(name="created_date")
	private Instant createdDate;
	
	@Column(name="last_modified_by")
	private Integer modifiedBy;
	
	@Column(name="last_modified_date")
	private Instant modifiedDate;
	
	
	@Transient
	List<MultipartFile> speakerProfilePic;
	
	@OneToMany(mappedBy="speakerPanel")
	Set<SpeakerPanelist> speakerPanelListSet;
	
	
	@Transient
	private Integer rowNumber;

	public Long getSpeakerId() {
		return speakerId;
	}

	public void setSpeakerId(Long speakerId) {
		this.speakerId = speakerId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSpeakerFirstName() {
		return speakerFirstName;
	}

	public void setSpeakerFirstName(String speakerFirstName) {
		this.speakerFirstName = speakerFirstName;
	}

	public String getSpeakerLastName() {
		return speakerLastName;
	}

	public void setSpeakerLastName(String speakerLastName) {
		this.speakerLastName = speakerLastName;
	}

	

	public String getSpeakerProfile() {
		return speakerProfile;
	}

	public void setSpeakerProfile(String speakerProfile) {
		this.speakerProfile = speakerProfile;
	}

	public String getSpeakerMobileNo() {
		return speakerMobileNo;
	}

	public void setSpeakerMobileNo(String speakerMobileNo) {
		this.speakerMobileNo = speakerMobileNo;
	}

	public String getSpeakerEmailId() {
		return speakerEmailId;
	}

	public void setSpeakerEmailId(String speakerEmailId) {
		this.speakerEmailId = speakerEmailId;
	}

	public String getSpeakerFolderName() {
		return speakerFolderName;
	}

	public void setSpeakerFolderName(String speakerFolderName) {
		this.speakerFolderName = speakerFolderName;
	}

	public String getSpeakerFileName() {
		return speakerFileName;
	}

	public void setSpeakerFileName(String speakerFileName) {
		this.speakerFileName = speakerFileName;
	}

	public String getSpeakerFileDescription() {
		return speakerFileDescription;
	}

	public void setSpeakerFileDescription(String speakerFileDescription) {
		this.speakerFileDescription = speakerFileDescription;
	}

	public Organization getSpeakerOrganization() {
		return speakerOrganization;
	}

	public void setSpeakerOrganization(Organization speakerOrganization) {
		this.speakerOrganization = speakerOrganization;
	}

	public Centres getSpeakerCenter() {
		return speakerCenter;
	}

	public void setSpeakerCenter(Centres speakerCenter) {
		this.speakerCenter = speakerCenter;
	}

	public Designation getSpeakerDesignation() {
		return speakerDesignation;
	}

	public void setSpeakerDesignation(Designation speakerDesignation) {
		this.speakerDesignation = speakerDesignation;
	}

	public Department getSpeakerDepartment() {
		return speakerDepartment;
	}

	public void setSpeakerDepartment(Department speakerDepartment) {
		this.speakerDepartment = speakerDepartment;
	}

	public int getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(int activeStatus) {
		this.activeStatus = activeStatus;
	}

	public int getIsPanelist() {
		return isPanelist;
	}

	public void setIsPanelist(int isPanelist) {
		this.isPanelist = isPanelist;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Instant getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Instant modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(Integer rowNumber) {
		this.rowNumber = rowNumber;
	}

	public List<MultipartFile> getSpeakerProfilePic() {
		return speakerProfilePic;
	}

	public void setSpeakerProfilePic(List<MultipartFile> speakerProfilePic) {
		this.speakerProfilePic = speakerProfilePic;
	}

	public Set<SpeakerPanelist> getSpeakerPanelListSet() {
		return speakerPanelListSet;
	}

	public void setSpeakerPanelListSet(Set<SpeakerPanelist> speakerPanelListSet) {
		this.speakerPanelListSet = speakerPanelListSet;
	}
	
	
	
	
	
	
	
	
}
