package com.iftas.eventportal.entity;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "userlogindetails")
public class UserLoggedActivity {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long userLoginDetailsId;
	
	@Column(name="user_id")
	private Integer userId;
	
	@Column(name="user_type")
	private Integer userType;
	
	@Column(name="login_time")
	private Instant loginTimeDate;
	
	@Column(name="logout_time")
	private Instant logoutTimeDate;
	
	@Column(name="created_date")
	private Instant createdDate;
	
	@Column(name="ip_address")
	private String ipAddress;

	public Long getUserLoginDetailsId() {
		return userLoginDetailsId;
	}

	public void setUserLoginDetailsId(Long userLoginDetailsId) {
		this.userLoginDetailsId = userLoginDetailsId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getUserType() {
		return userType;
	}

	public void setUserType(Integer userType) {
		this.userType = userType;
	}

	public Instant getLoginTimeDate() {
		return loginTimeDate;
	}

	public void setLoginTimeDate(Instant loginTimeDate) {
		this.loginTimeDate = loginTimeDate;
	}

	public Instant getLogoutTimeDate() {
		return logoutTimeDate;
	}

	public void setLogoutTimeDate(Instant logoutTimeDate) {
		this.logoutTimeDate = logoutTimeDate;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	
	
	

}
