package com.iftas.eventportal.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.OneToOne;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.iftas.eventportal.dto.events;

@SqlResultSetMappings({@SqlResultSetMapping(name = "eventDashboard", 
classes = {@ConstructorResult(targetClass = com.iftas.eventportal.dto.events.class, 
columns = {@ColumnResult(name = "id", type = String.class)
        , @ColumnResult(name = "start", type = String.class)
		, @ColumnResult(name = "end", type = String.class)        
		, @ColumnResult(name = "title", type = String.class)
		, @ColumnResult(name = "allDay", type = boolean.class)
		, @ColumnResult(name = "className", type = String.class)
		 })})})
		@NamedNativeQueries({@NamedNativeQuery(name = "EventSessionRef.getCalenderDashboardForGivenParameter", 
											 query = "Select id, start, end, title, allDay, className from( "
											 		+ "SELECT eventMaster.id ,CONCAT(eventMaster.event_start_date,'T',CAST('00:00:00' AS TIME)) as start "
											 		+ ",CONCAT(eventMaster.event_end_date,'T',CAST('24:00:00' AS TIME)) as end ,CONCAT(eventMaster.event_name,'-', product.product_name,'-',dep.department_name) as title "
											 		+ ",true as allDay,'bg-red' as className,eventMaster.id as eventId "
											 		+ "from event_master eventMaster , productmst product , department dep   "
											 		+ " where eventMaster.product_id =  product.id and eventMaster.department_id =  dep.department_id  "
//											 		+ " Union "
//											 		+ "SELECT eventSession.id,CONCAT(eventSession.event_date,'T',CAST(eventSession.session_start_time AS TIME)) as start "
//											 		+ ",CONCAT(eventSession.event_date,'T',CAST(eventSession.session_end_time AS TIME)) as end ,eventSession.session_name as title "
//											 		+ ",false as allDay,Case When is_session='Y' then 'bg-green' else 'bg-navy' end as className,eventSession.event_id as eventId"
//											 		+ " FROM event_session_ref eventSession "
											 		+ ") as abc"
											 		+ " Where 1=1 "
											 		+ " and (?1='' or eventId = ?1 ) "
											 		+ " and title is not NULL and start is not NULL  "
											 		+ " Order by eventId ,start", 
											 		resultSetMapping = "eventDashboard")
	 })
@Entity
@Table(name="event_session_ref")
public class EventSessionRef {

	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long sessionId;
	
	@Column(name="day")
	private Integer day;
	
	//join column from event Master
	@JsonBackReference
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="event_id")
	private EventMaster eventSessions; 
	
	@Column(name="event_date")
	private String eventDate;
	
	@Column(name="session_name")
	private String sessionName;
	
	@Column(name="session_description")
	private String sessionTopic;
	
	@Column(name="session_start_time")
	private String sessionStartTime;
	
	@Column(name="session_end_time")
	private String sessionEndTime;
	
	
	@OneToOne
	@JoinColumn(name="speaker_id")
	private SpeakerMaster speaker;
	
	@OneToOne
	@JoinColumn(name="reading_material_id")
	private RelavantReading readingMaterial;
	
	@Column(name="is_session")
	private String isSession;

	@Column(name="is_feedback")
	private String isfeedback;

	public Long getSessionId() {
		return sessionId;
	}

	public void setSessionId(Long sessionId) {
		this.sessionId = sessionId;
	}

	public Integer getDay() {
		return day;
	}

	public void setDay(Integer day) {
		this.day = day;
	}

	public EventMaster getEventSessions() {
		return eventSessions;
	}

	public void setEventSessions(EventMaster eventSessions) {
		this.eventSessions = eventSessions;
	}

	public String getEventDate() {
		return eventDate;
	}

	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}

	public String getSessionName() {
		return sessionName;
	}

	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}

	public String getSessionTopic() {
		return sessionTopic;
	}

	public void setSessionTopic(String sessionTopic) {
		this.sessionTopic = sessionTopic;
	}

	public String getSessionStartTime() {
		return sessionStartTime;
	}

	public void setSessionStartTime(String sessionStartTime) {
		this.sessionStartTime = sessionStartTime;
	}

	public String getSessionEndTime() {
		return sessionEndTime;
	}

	public void setSessionEndTime(String sessionEndTime) {
		this.sessionEndTime = sessionEndTime;
	}

	public SpeakerMaster getSpeaker() {
		return speaker;
	}

	public void setSpeaker(SpeakerMaster speaker) {
		this.speaker = speaker;
	}

	public RelavantReading getReadingMaterial() {
		return readingMaterial;
	}

	public void setReadingMaterial(RelavantReading readingMaterial) {
		this.readingMaterial = readingMaterial;
	}

	public String getIsSession() {
		return isSession;
	}

	public void setIsSession(String isSession) {
		this.isSession = isSession;
	}

	public String getIsfeedback() {
		return isfeedback;
	}

	public void setIsfeedback(String isfeedback) {
		this.isfeedback = isfeedback;
	}
	
	
	
}
