package com.iftas.eventportal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="relavant_reading")
public class RelavantReading {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	
	@Column(name="folder_name")
	private String speakerFolderName ;
	
	@Column(name="file_name")
	private String speakerFileName ;
	
	@Column(name="file_description")
	private String speakerFileDescription ;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSpeakerFolderName() {
		return speakerFolderName;
	}

	public void setSpeakerFolderName(String speakerFolderName) {
		this.speakerFolderName = speakerFolderName;
	}

	public String getSpeakerFileName() {
		return speakerFileName;
	}

	public void setSpeakerFileName(String speakerFileName) {
		this.speakerFileName = speakerFileName;
	}

	public String getSpeakerFileDescription() {
		return speakerFileDescription;
	}

	public void setSpeakerFileDescription(String speakerFileDescription) {
		this.speakerFileDescription = speakerFileDescription;
	}
	
	
	

}
