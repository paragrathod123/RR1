package com.iftas.eventportal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name = "event_participants")
public class EventParticipants {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long eventParticipantId;
	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="event_id")
	private EventMaster eventParticipants; 
	
	@OneToOne
	@JoinColumn(name="participant_id")
	private ParticipantMaster eventParticipant;
	
	@Column(name="room_no")
	private String roomNo;
	
    //@Size(max = 12)
   // @Pattern(regexp="(^[0-9]*$)",message = "Please enter valid Emergency Contact No")
    @Column(name="emergency_contact_no")
	private String emergencyContactNo;
	
	@Column(name="allergies")
	private String allergies;
	
	@Column(name="driver_name")
	private String driverName;
	
	
	// @Size(max = 12)
	//@Pattern(regexp="(^[0-9]*$)",message = "Driver's Contact No is Invalid") 
	@Column(name="driver_contact_no")
	private String driverContactNo;
	
	@Column(name="driver_cab_no")
	private String driverCabNo;
	
	@Transient
	private String loginId;
	
	@Transient
	private Integer isAdmin;
	
	@Transient
	private String loginMobileNo;

	public Long getEventParticipantId() {
		return eventParticipantId;
	}

	public void setEventParticipantId(Long eventParticipantId) {
		this.eventParticipantId = eventParticipantId;
	}

	public EventMaster getEventParticipants() {
		return eventParticipants;
	}

	public void setEventParticipants(EventMaster eventParticipants) {
		this.eventParticipants = eventParticipants;
	}

	public ParticipantMaster getEventParticipant() {
		return eventParticipant;
	}

	public void setEventParticipant(ParticipantMaster eventParticipant) {
		this.eventParticipant = eventParticipant;
	}

	public String getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}

	public String getEmergencyContactNo() {
		return emergencyContactNo;
	}

	public void setEmergencyContactNo(String emergencyContactNo) {
		this.emergencyContactNo = emergencyContactNo;
	}

	public String getAllergies() {
		return allergies;
	}

	public void setAllergies(String allergies) {
		this.allergies = allergies;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public String getDriverContactNo() {
		return driverContactNo;
	}

	public void setDriverContactNo(String driverContactNo) {
		this.driverContactNo = driverContactNo;
	}

	public String getDriverCabNo() {
		return driverCabNo;
	}

	public void setDriverCabNo(String driverCabNo) {
		this.driverCabNo = driverCabNo;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public Integer getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Integer isAdmin) {
		this.isAdmin = isAdmin;
	}

	public String getLoginMobileNo() {
		return loginMobileNo;
	}

	public void setLoginMobileNo(String loginMobileNo) {
		this.loginMobileNo = loginMobileNo;
	}
	
	
	
	
}
