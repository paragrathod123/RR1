package com.iftas.eventportal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="mobile_user_events")
public class MobileEventUsers {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;
	
	@Column(name="event_id")
	private Long eventId;
	
	@Column(name="mobile_user_id")
	private Long mobileUserId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getEventId() {
		return eventId;
	}

	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}

	public Long getMobileUserId() {
		return mobileUserId;
	}

	public void setMobileUserId(Long mobileUserId) {
		this.mobileUserId = mobileUserId;
	}
	
	

}
