package com.iftas.eventportal.entity;

import java.time.Instant;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name="rolemst")
public class RoleMst {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="roleid")
	private Long roleId;
	
	@Column(name="name")
	private String roleName;
	
	@Column(name="active_status")
	private int activeStatus;
	
	
	@Column(name="created_by")
	private int createdBy;
	
	@Column(name="created_date")
	private Instant createdDate;
	
	@Column(name="last_modified_by")
	private int modifiedBy;
	
	@Column(name="last_modified_date")
	private Instant modifiedDate;
	

	
	
	@OneToMany(mappedBy = "role")
	List<User> user;
	
	
	@OneToMany(mappedBy = "role",cascade= CascadeType.ALL)
	List<Privileges> privileges;
	
	
	
	


	public Long getRoleId() {
		return roleId;
	}


	public String getRoleName() {
		return roleName;
	}


	public int getActiveStatus() {
		return activeStatus;
	}


	public int getCreatedBy() {
		return createdBy;
	}


	public Instant getCreatedDate() {
		return createdDate;
	}


	public int getModifiedBy() {
		return modifiedBy;
	}


	public Instant getModifiedDate() {
		return modifiedDate;
	}


	

	public List<Privileges> getPrivileges() {
		return privileges;
	}


	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}


	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}


	public void setActiveStatus(int activeStatus) {
		this.activeStatus = activeStatus;
	}


	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}


	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}


	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}


	public void setModifiedDate(Instant modifiedDate) {
		this.modifiedDate = modifiedDate;
	}


	

	public void setPrivileges(List<Privileges> privileges) {
		this.privileges = privileges;
	}





	public List<User> getUser() {
		return user;
	}


	public void setUser(List<User> user) {
		this.user = user;
	}   
	
}
