package com.iftas.eventportal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name="speakerpanelref")
public class SpeakerPanelist {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long speakerPanelId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="speaker_id")
	private SpeakerMaster speakerPanel; 
	
	
	@Column(name="title")
	private String title;
	
	@Column(name="first_name")
	private String speakerFirstName;
	
	@Column(name="last_name")
	private String speakerLastName;
	
	@OneToOne
	@JoinColumn(name="organization_id")
	private Organization speakerOrganization;
	
	@OneToOne
	@JoinColumn(name="center_id")
	private Centres speakerCenter;
	
	
	@OneToOne
	@JoinColumn(name="department_id")
	private Department speakerDepartment;
	
	@OneToOne
	@JoinColumn(name="designation_id")
	private Designation speakerDesignation;
	
	
	@Column(name="profile")
	private String speakerProfile;
	
	@Size(max = 12)
	@Pattern(regexp="(^$|[0-9]{10})",message = "Please enter valid Mobile No")
	@Column(name="mobile_no")
	private String speakerMobileNo;
	
	@Column(name="email_id")
	private String speakerEmailId;
	
	@Column(name="folder_name")
	private String speakerFolderName ;
	
	@Column(name="file_name")
	private String speakerFileName ;
	
	@Column(name="file_description")
	private String speakerFileDescription ;

	public Long getSpeakerPanelId() {
		return speakerPanelId;
	}

	public void setSpeakerPanelId(Long speakerPanelId) {
		this.speakerPanelId = speakerPanelId;
	}

	public SpeakerMaster getSpeakerPanel() {
		return speakerPanel;
	}

	public void setSpeakerPanel(SpeakerMaster speakerPanel) {
		this.speakerPanel = speakerPanel;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSpeakerFirstName() {
		return speakerFirstName;
	}

	public void setSpeakerFirstName(String speakerFirstName) {
		this.speakerFirstName = speakerFirstName;
	}

	public String getSpeakerLastName() {
		return speakerLastName;
	}

	public void setSpeakerLastName(String speakerLastName) {
		this.speakerLastName = speakerLastName;
	}

	public Organization getSpeakerOrganization() {
		return speakerOrganization;
	}

	public void setSpeakerOrganization(Organization speakerOrganization) {
		this.speakerOrganization = speakerOrganization;
	}

	public Centres getSpeakerCenter() {
		return speakerCenter;
	}

	public void setSpeakerCenter(Centres speakerCenter) {
		this.speakerCenter = speakerCenter;
	}

	public Department getSpeakerDepartment() {
		return speakerDepartment;
	}

	public void setSpeakerDepartment(Department speakerDepartment) {
		this.speakerDepartment = speakerDepartment;
	}

	public Designation getSpeakerDesignation() {
		return speakerDesignation;
	}

	public void setSpeakerDesignation(Designation speakerDesignation) {
		this.speakerDesignation = speakerDesignation;
	}

	public String getSpeakerProfile() {
		return speakerProfile;
	}

	public void setSpeakerProfile(String speakerProfile) {
		this.speakerProfile = speakerProfile;
	}

	public String getSpeakerMobileNo() {
		return speakerMobileNo;
	}

	public void setSpeakerMobileNo(String speakerMobileNo) {
		this.speakerMobileNo = speakerMobileNo;
	}

	public String getSpeakerEmailId() {
		return speakerEmailId;
	}

	public void setSpeakerEmailId(String speakerEmailId) {
		this.speakerEmailId = speakerEmailId;
	}

	public String getSpeakerFolderName() {
		return speakerFolderName;
	}

	public void setSpeakerFolderName(String speakerFolderName) {
		this.speakerFolderName = speakerFolderName;
	}

	public String getSpeakerFileName() {
		return speakerFileName;
	}

	public void setSpeakerFileName(String speakerFileName) {
		this.speakerFileName = speakerFileName;
	}

	public String getSpeakerFileDescription() {
		return speakerFileDescription;
	}

	public void setSpeakerFileDescription(String speakerFileDescription) {
		this.speakerFileDescription = speakerFileDescription;
	}

	
	
}
