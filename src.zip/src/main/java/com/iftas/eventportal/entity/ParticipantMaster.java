package com.iftas.eventportal.entity;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.iftas.eventportal.helper.Constants;

@Entity
@Table(name="participants")
public class ParticipantMaster {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Long participantId;
	
	@Column(name="title")
	private String title;
	
	@Column(name="first_name")
	private String participantFirstName;
	
	@Column(name="last_name")
	private String participantLastName;
	
	
	@OneToOne
	@JoinColumn(name="organization_id")
	private Organization participantOrganization;
	
	@OneToOne
	@JoinColumn(name="center_id")
	private Centres participantCenter;
	
	@OneToOne
	@JoinColumn(name="department_id")
	private Department participantDepartment;
	
	@OneToOne
	@JoinColumn(name="designation_id")
	private Designation participantDesignation;
	
	
	@Column(name="profile")
	private String participantProfile;
	
	 //@Size(max = 12) 
	//@Pattern(regexp="(^$|[0-9]{10})",message = "Please enter valid Mobile No")
	@Column(name="mobile_no")
	private String participantMobileNo;
	
	//@Email
	//@Pattern(regexp = Constants.EMAIL_PATTERN,message = "Please enter valid Email Id")
	//@Size(min = 5, max = 100)
	@Column(name="email_id")
	private String participantEmailId;
	
	@Column(name="folder_name")
	private String participantFolderName ;
	
	@Column(name="file_name")
	private String participantFileName ;
	
	@Column(name="file_description")
	private String participantFileDescription ;
	
	@Column(name="active_status")
	private int activeStatus;
	
	@Column(name="created_by")
	private Integer  createdBy;
	
	@Column(name="created_date")
	private Instant createdDate;
	
	@Column(name="last_modified_by")
	private Integer modifiedBy;
	
	@Column(name="last_modified_date")
	private Instant modifiedDate;

	
	public Long getParticipantId() {
		return participantId;
	}

	public void setParticipantId(Long participantId) {
		this.participantId = participantId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getParticipantFirstName() {
		return participantFirstName;
	}

	public void setParticipantFirstName(String participantFirstName) {
		this.participantFirstName = participantFirstName;
	}

	public String getParticipantLastName() {
		return participantLastName;
	}

	public void setParticipantLastName(String participantLastName) {
		this.participantLastName = participantLastName;
	}

	

	public String getParticipantProfile() {
		return participantProfile;
	}

	public void setParticipantProfile(String participantProfile) {
		this.participantProfile = participantProfile;
	}

	public String getParticipantMobileNo() {
		return participantMobileNo;
	}

	public void setParticipantMobileNo(String participantMobileNo) {
		this.participantMobileNo = participantMobileNo;
	}

	public String getParticipantEmailId() {
		return participantEmailId;
	}

	public void setParticipantEmailId(String participantEmailId) {
		this.participantEmailId = participantEmailId;
	}

	public String getParticipantFolderName() {
		return participantFolderName;
	}

	public void setParticipantFolderName(String participantFolderName) {
		this.participantFolderName = participantFolderName;
	}

	public String getParticipantFileName() {
		return participantFileName;
	}

	public void setParticipantFileName(String participantFileName) {
		this.participantFileName = participantFileName;
	}

	public String getParticipantFileDescription() {
		return participantFileDescription;
	}

	public void setParticipantFileDescription(String participantFileDescription) {
		this.participantFileDescription = participantFileDescription;
	}

	public Department getParticipantDepartment() {
		return participantDepartment;
	}

	public void setParticipantDepartment(Department participantDepartment) {
		this.participantDepartment = participantDepartment;
	}

	public int getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(int activeStatus) {
		this.activeStatus = activeStatus;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Instant getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Instant modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Organization getParticipantOrganization() {
		return participantOrganization;
	}

	public void setParticipantOrganization(Organization participantOrganization) {
		this.participantOrganization = participantOrganization;
	}

	public Centres getParticipantCenter() {
		return participantCenter;
	}

	public void setParticipantCenter(Centres participantCenter) {
		this.participantCenter = participantCenter;
	}

	public Designation getParticipantDesignation() {
		return participantDesignation;
	}

	public void setParticipantDesignation(Designation participantDesignation) {
		this.participantDesignation = participantDesignation;
	}
	
	
	
	
	
}
