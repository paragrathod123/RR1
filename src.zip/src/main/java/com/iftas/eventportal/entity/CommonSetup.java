package com.iftas.eventportal.entity;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="commonsetup")
public class CommonSetup {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="commonsetupid")	
	private Long commonSetupId;
	
	@Column(name="session_time_out")
	private Integer sessionTimeOut;
	
	@Column(name="max_login_attempts")
	private Integer maxLoginAttempts;
	
	@Column(name="password_expiry_no_of_days")
	private Integer passwordExpiryAfterNoOfDays;
	
	@Column(name="active_status")
	private int activeStatus;
	
	@Column(name="created_by")
	private Integer  createdBy;
	
	@Column(name="created_date")
	private Instant createdDate;
	
	@Column(name="last_modified_by")
	private Integer modifiedBy;
	
	@Column(name="last_modified_date")
	private Instant modifiedDate;
	
	public CommonSetup() {
		
	}

	public Long getCommonSetupId() {
		return commonSetupId;
	}

	public void setCommonSetupId(Long commonSetupId) {
		this.commonSetupId = commonSetupId;
	}

	public Integer getSessionTimeOut() {
		return sessionTimeOut;
	}

	public void setSessionTimeOut(Integer sessionTimeOut) {
		this.sessionTimeOut = sessionTimeOut;
	}

	public Integer getMaxLoginAttempts() {
		return maxLoginAttempts;
	}

	public void setMaxLoginAttempts(Integer maxLoginAttempts) {
		this.maxLoginAttempts = maxLoginAttempts;
	}

	public Integer getPasswordExpiryAfterNoOfDays() {
		return passwordExpiryAfterNoOfDays;
	}

	public void setPasswordExpiryAfterNoOfDays(Integer passwordExpiryAfterNoOfDays) {
		this.passwordExpiryAfterNoOfDays = passwordExpiryAfterNoOfDays;
	}

	public int getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(int activeStatus) {
		this.activeStatus = activeStatus;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Instant getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Instant modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	@Override
	public String toString() {
		return "CommonSetup [commonSetupId=" + commonSetupId + ", sessionTimeOut=" + sessionTimeOut
				+ ", maxLoginAttempts=" + maxLoginAttempts + ", passwordExpiryAfterNoOfDays="
				+ passwordExpiryAfterNoOfDays + ", activeStatus=" + activeStatus + ", createdBy=" + createdBy
				+ ", createdDate=" + createdDate + ", modifiedBy=" + modifiedBy + ", modifiedDate=" + modifiedDate
				+ "]";
	}
	
	
}
