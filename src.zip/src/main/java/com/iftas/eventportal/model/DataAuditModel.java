package com.iftas.eventportal.model;

import java.time.Instant;

public class DataAuditModel {

	
	
	
	private String approveOrRejectedBy;
	
	private Instant approveOrRejectedDate;
	
	private String ipAddress;
	
	private String status;
	
	private String remarks;
	
	private String markerTypeStr;

	private Long sourceId;
	
	public String getApproveOrRejectedBy() {
		return approveOrRejectedBy;
	}

	public void setApproveOrRejectedBy(String approveOrRejectedBy) {
		this.approveOrRejectedBy = approveOrRejectedBy;
	}

	public Instant getApproveOrRejectedDate() {
		return approveOrRejectedDate;
	}

	public void setApproveOrRejectedDate(Instant approveOrRejectedDate) {
		this.approveOrRejectedDate = approveOrRejectedDate;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getMarkerTypeStr() {
		return markerTypeStr;
	}

	public void setMarkerTypeStr(String markerTypeStr) {
		this.markerTypeStr = markerTypeStr;
	}

	public Long getSourceId() {
		return sourceId;
	}

	public void setSourceId(Long sourceId) {
		this.sourceId = sourceId;
	}
	
	
	
	
	
}
