package com.iftas.eventportal.model;

import java.time.Instant;

public class CustomerRecentActivityDTO {
	
	private String transactionType;
	
	private Instant  transactionDate;
	
	private String branchId;
	
	private String cbsCustomerId;

	public CustomerRecentActivityDTO(String transactionType, Instant transactionDate, String branchId,
			String cbsCustomerId) {
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.branchId = branchId;
		this.cbsCustomerId = cbsCustomerId;
	}
	
	public CustomerRecentActivityDTO() {
		
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Instant getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Instant transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getCbsCustomerId() {
		return cbsCustomerId;
	}

	public void setCbsCustomerId(String cbsCustomerId) {
		this.cbsCustomerId = cbsCustomerId;
	}
	
	
	

}
