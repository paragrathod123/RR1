package com.iftas.eventportal.helper;

import java.io.File;
import java.nio.file.Files;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.util.ResourceUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.iftas.eventportal.entity.MenuMaster;

public class GlobalMenus {

	private final Logger log = LoggerFactory.getLogger(GlobalMenus.class);
	
	public static List<MenuMaster> siteMenus;

	public void loadSiteMenu(Long long1, HttpServletRequest httpRequest) {
		log.debug("Inside GlobalMenus.loadSiteMenu(Long long1, HttpServletRequest httpRequest)");
		try {
			HttpSession session = httpRequest.getSession();
			String pathUrl = (String) session.getAttribute("pathUrl");
			ObjectMapper object = new ObjectMapper();
			File file = ResourceUtils.getFile(pathUrl.trim() + "/Roles/" + "/Role_" + long1 + ".json");
			byte[] jsonData = Files.readAllBytes(file.toPath());
			GlobalMenus.siteMenus = object.reader().forType(new TypeReference<List<MenuMaster>>() {
			}).readValue(jsonData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		log.debug("Exist GlobalMenus.loadSiteMenu(Long long1, HttpServletRequest httpRequest)");

	}

}
