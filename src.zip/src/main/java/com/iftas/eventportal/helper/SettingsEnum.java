package com.iftas.eventportal.helper;

public class SettingsEnum {
	public enum eHandlerSettings {
		PATH;
	}
}
