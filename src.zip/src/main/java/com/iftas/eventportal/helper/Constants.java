package com.iftas.eventportal.helper;

/**
 * Application constants.
 */
public final class Constants {

    // Regex for acceptable logins
    public static final String LOGIN_REGEX = "^[_.@A-Za-z0-9-]*$";
    
    public static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
			+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    
    public static final String SYSTEM_ACCOUNT = "system";
    public static final String DEFAULT_LANGUAGE = "en";
    public static final String ANONYMOUS_USER = "anonymoususer";
    
    public static final String ADD_SUCCESSFULLY = "Record added successfully";
    public static final String ADD_SEND_SUCCESSFULLY = "Record added and send successfully";
    
    
    public static final String UPDATE_SUCCESSFULLY = "Record updated successfully";
    public static final String UPDATE_SEND_SUCCESSFULLY = "Record updated and send successfully";
    
    
    public static final String APPROVED_SUCCESSFULLY = "Record approved successfully";
    public static final String REJECTED_SUCCESSFULLY = "Record rejected successfully";
    
    public static final String DISCARD_SUCCESSFULLY = "Record discard successfully";
    
    public static final String SUCCESSALERTCLASS = "alert-info";
    
    public static final  String FAILEDALERTCLASS = "alert-danger";
    
    
    public static final String TO_BE_SEND ="TO BE SEND";
    public static final String APPROVED ="APPROVED";
    public static final String FOR_APPROVAL ="FOR APPROVAL";
    public static final String REJECTED ="REJECTED";
    
    
    public static final String PASSWORD_RESET_SUCCESSFULLY = "Password Reset successfully ";
    
    public static final String UPLOAD_SUCCESSFULLY = "Records uploaded successfully";
    
    

    private Constants() {
    }
}