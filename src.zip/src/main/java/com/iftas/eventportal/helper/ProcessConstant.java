package com.iftas.eventportal.helper;

public class ProcessConstant {
	
	public static final int PUSHNOTIFICATION = 5;
	
	public static final int EMAILSETUP = 4;
	
	public static final int COMMONSETUP = 3;
	
	public static final int USERPID = 2;
   
	public static final int ROLEID = 1;
	
	private ProcessConstant() {
    }
	
	
}
