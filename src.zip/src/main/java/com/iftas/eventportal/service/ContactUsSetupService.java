package com.iftas.eventportal.service;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iftas.eventportal.dao.ContactUsSetupRepository;
import com.iftas.eventportal.entity.ContactUsSetup;

@Service
@Transactional
public class ContactUsSetupService {

	@Autowired
	private ContactUsSetupRepository contactUsSetupRepository;
	
	public List<ContactUsSetup> getContactUsSetups(int activeStatus){
		return contactUsSetupRepository.findAllByActiveStatus(activeStatus);
	}
	
	public ContactUsSetup getContactUsSetupById(Long id) {
		return contactUsSetupRepository.findById(id).get();
	}
	
	public ContactUsSetup updateContactUsSetup(ContactUsSetup theContactUsSetup, HttpServletRequest request) {
		Optional<ContactUsSetup> contactUsSetups = contactUsSetupRepository.findById(theContactUsSetup.getContactUsSetupId());
		ContactUsSetup contactUsSetup = new ContactUsSetup();
		contactUsSetup = contactUsSetups.get();
		contactUsSetup.setDescription(theContactUsSetup.getDescription());
		contactUsSetup.setActiveStatus(theContactUsSetup.getActiveStatus());
		contactUsSetup.setRemarks(theContactUsSetup.getRemarks());
		contactUsSetupRepository.save(contactUsSetup);
		return contactUsSetup;
	}
}
