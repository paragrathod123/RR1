package com.iftas.eventportal.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iftas.eventportal.dao.MobileEventUserRepository;
import com.iftas.eventportal.dao.MobileUserRepository;
import com.iftas.eventportal.entity.MobileEventUsers;
import com.iftas.eventportal.entity.MobileUsers;

@Service
@Transactional
public class MobileUserService {

	@Autowired
	private MobileUserRepository mobileUserRepository;
	
	@Autowired
	private MobileEventUserRepository mobileEventUserRepository;
	
	
	public List<MobileUsers> getMobileUserList(){
		
		List<MobileUsers> mobileUsers = new ArrayList<MobileUsers>();
		List<MobileEventUsers> mobileEventUsers =  mobileEventUserRepository.findAll();
		for (MobileEventUsers mobileEventUsers2 : mobileEventUsers) {
			Optional<MobileUsers> optionMobileUser =  mobileUserRepository.findById(mobileEventUsers2.getMobileUserId());
			if(optionMobileUser.isPresent()) {
				mobileUsers.add(optionMobileUser.get());
			}
		}
		return mobileUsers;
	}
	
	public MobileUsers getMobileUserById(Long id) {
		 return mobileUserRepository.findById(id).get();
	}
	
	public List<MobileUsers> getMobileUserListByEventId(Long Id){
		
		List<MobileUsers> mobileUsers = new ArrayList<MobileUsers>();
		
		List<MobileEventUsers> mobileEventUsers =  mobileEventUserRepository.findByEventId(Id);
		for (MobileEventUsers mobileEventUsers2 : mobileEventUsers) {
			
			Optional<MobileUsers> optionMobileUser =  mobileUserRepository.findById(mobileEventUsers2.getMobileUserId());
			if(optionMobileUser.isPresent()) {
				mobileUsers.add(optionMobileUser.get());
			}
		}
		return mobileUsers;
	}
	 
	 public MobileUsers updateMobileUsers(MobileUsers theMobileUsers, HttpServletRequest request) {
		 Optional<MobileUsers> mobileUsers = mobileUserRepository.findById(theMobileUsers.getId());
		 MobileUsers mobileUser = new MobileUsers();
		 mobileUser = mobileUsers.get();
		 mobileUser.setActiveStatus(theMobileUsers.getActiveStatus());
		 mobileUser.setIsAdmin(theMobileUsers.getIsAdmin());
		 mobileUserRepository.save(mobileUser);
		 return mobileUser;

	 }
}
