package com.iftas.eventportal.service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iftas.eventportal.dao.CentreRepository;
import com.iftas.eventportal.entity.Centres;

@Service
@Transactional
public class CentreService {

	@Autowired
	private CentreRepository centreRepository;
	
	public List<Centres>getCentreList(){
		return centreRepository.findAll();
	}
	
	public Centres getCentreById(Long id) {
		return centreRepository.findById(id).get();	
	}
	
	public Centres creatCentres(Centres theCentre, HttpServletRequest request) {
		Centres centre = new Centres();
		HttpSession session =  request.getSession();
		centre.setCentreName(theCentre.getCentreName());
		centre.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
		centre.setCreatedDate(Instant.now());
		centre.setModifiedBy(0);
		centre.setActiveStatus(theCentre.getActiveStatus());
		centreRepository.save(centre);
		return centre;
	}
	
	public Centres updateCentres(Centres theCentres, HttpServletRequest request) {
		Optional<Centres> centres = centreRepository.findById(theCentres.getCentreId());
		Centres centre = new Centres();
		HttpSession session =  request.getSession();
		centre = centres.get();
		centre.setCentreName(theCentres.getCentreName());
		centre.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
		centre.setModifiedDate(Instant.now());
		centre.setActiveStatus(theCentres.getActiveStatus());
		centreRepository.save(centre);
		return centre;
	}
}
