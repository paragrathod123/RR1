package com.iftas.eventportal.service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iftas.eventportal.dao.CommonSetupRepository;
import com.iftas.eventportal.entity.CommonSetup;


@Service
@Transactional
public class CommonSetupService {
	
	@Autowired
	private CommonSetupRepository commonSetupRepository;
	
	public List<CommonSetup> getCommonSetupListing(int activeStatus){
		return commonSetupRepository.findAllByActiveStatus(activeStatus);
	}
	public CommonSetup getCommonSetupById(Long id) {
		return commonSetupRepository.findById(id).get();	
	}
	
	public CommonSetup updateCommonSetup(CommonSetup theCommonSetup, HttpServletRequest request) {
		HttpSession session =  request.getSession();
		Optional<CommonSetup> commonSetups = commonSetupRepository.findById(theCommonSetup.getCommonSetupId());
		CommonSetup commonSetup = new CommonSetup();
		commonSetup = commonSetups.get();
		commonSetup.setSessionTimeOut(theCommonSetup.getSessionTimeOut());
		commonSetup.setMaxLoginAttempts(theCommonSetup.getMaxLoginAttempts());
		commonSetup.setPasswordExpiryAfterNoOfDays(theCommonSetup.getPasswordExpiryAfterNoOfDays());;
		commonSetup.setActiveStatus(theCommonSetup.getActiveStatus());
		commonSetup.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
		commonSetup.setModifiedDate(Instant.now());
		commonSetupRepository.save(commonSetup);
		return commonSetup;
	}
}
