package com.iftas.eventportal.service;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.iftas.eventportal.dao.EmailTemplateRepository;

import com.iftas.eventportal.entity.EmailTemplate;

@Service
@Transactional
public class EmailTemplateService {
	@Autowired
	private EmailTemplateRepository emailTemplateRepository;
	
	public List<EmailTemplate> getEmailTemplate(int activeStatus){
		return emailTemplateRepository.findAllByActiveStatus(activeStatus);
	}
	
	public EmailTemplate getEmailTemplateById(Long id) {
		return emailTemplateRepository.findById(id).get();
	}
	
	public EmailTemplate updateContactUsSetup(EmailTemplate theEmailTemplate, HttpServletRequest request) {
		Optional<EmailTemplate> emaailTemplates = emailTemplateRepository.findById(theEmailTemplate.getEmailTemplateId());
		EmailTemplate emaailTemplate = new EmailTemplate();
		emaailTemplate = emaailTemplates.get();
		emaailTemplate.setEmailId(theEmailTemplate.getEmailId());
		emaailTemplate.setDescription(theEmailTemplate.getDescription());
		emaailTemplate.setActiveStatus(theEmailTemplate.getActiveStatus());
		emaailTemplate.setRemarks(theEmailTemplate.getRemarks());
		emailTemplateRepository.save(emaailTemplate);
		return emaailTemplate;
	}
}
