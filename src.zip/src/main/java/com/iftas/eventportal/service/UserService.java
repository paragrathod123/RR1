package com.iftas.eventportal.service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.aspectj.internal.lang.annotation.ajcDeclareAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.iftas.eventportal.dao.DepartmentRepository;
import com.iftas.eventportal.dao.DesignationRepository;
import com.iftas.eventportal.dao.EventMasterRepository;
import com.iftas.eventportal.dao.MenuRepository;
import com.iftas.eventportal.dao.ProductMasterRepository;
import com.iftas.eventportal.dao.RoleRepository;
import com.iftas.eventportal.dao.UserRepository;
import com.iftas.eventportal.entity.Department;
import com.iftas.eventportal.entity.Designation;
import com.iftas.eventportal.entity.EventMaster;
import com.iftas.eventportal.entity.MenuMaster;
import com.iftas.eventportal.entity.ProductMaster;
import com.iftas.eventportal.entity.RoleMst;
import com.iftas.eventportal.entity.User;
import com.iftas.eventportal.security.SecurityUtils;
import com.iftas.eventportal.util.RandomUtil;




/**
 * Service class for managing users.
 */
@Service
@Transactional
public class UserService  {
	
	
	
	
	@Autowired
	private UserRepository userRepository; 
	
	
	@Autowired
	private MailService  mailService;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private MenuRepository menuRepository;
	
	@Autowired
	private DepartmentRepository departmentRepository;
	
	@Autowired
	private DesignationRepository designationRepository;
	
	@Autowired
	private EventMasterRepository eventMasterRepository ;
	
	@Autowired
	private ProductMasterRepository productMasterRepository;
	
	
	private PasswordEncoder passwordEncoder =  new BCryptPasswordEncoder();
	
	
	
	public void changePassword(String newPassword) {
		
		SecurityUtils.getCurrentUserLogin()
		.flatMap(userRepository::findOneByLogin)
		.ifPresent(
				user->{
					String encryptedPassword = passwordEncoder.encode(newPassword);
	                user.setPasswordHash(encryptedPassword);
	                user.setLastResetDate(Instant.now());
	                userRepository.save(user);
				}
				
	    );
		
	}
	
	
	 public Optional<User> completePasswordReset(String newPassword, String key) {
	        return userRepository.findOneByResetKey(key)
	            //.filter(user -> user.getResetDate().isAfter(Instant.now().minusSeconds(86400)))
	            .map(user -> {
	                user.setPasswordHash(passwordEncoder.encode(newPassword));
	                user.setResetKey(null);
	                user.setResetDate(null);
	                user.setLocked(0);
	                user.setLastResetDate(Instant.now());
	                userRepository.save(user);
	                return user;
	            });
	  }

	 
	 public Optional<User> requestPasswordReset(String mail) {
	        return userRepository.findOneByEmailIgnoreCase(mail)
	         //   .filter(User::getActivated)
	            .map(user -> {
	                user.setResetKey(RandomUtil.generateResetKey());
	                user.setResetDate(Instant.now());
	                userRepository.save(user);
	                return user;
	            });
	    }


	public List<User> getUserList() {
		return userRepository.findAll();
	}


	public User createUser(User theUser, HttpServletRequest request,MultipartFile imageDataFile) {
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		//User user = new User();
		Long roleId =  Long.valueOf(request.getParameter("roleId"));
		Optional<RoleMst> role =  roleRepository.findById(roleId);
		theUser.setRole(role.get());
		
		Long departmentId =  Long.valueOf(request.getParameter("departmentId"));
		Optional<Department> departmentOption  =  departmentRepository.findById(departmentId);
		theUser.setUserDepartment(departmentOption.get());
		
		Long designationId =  Long.valueOf(request.getParameter("designationId"));
		Optional<Designation> designationOption =  designationRepository.findById(designationId);
		theUser.setUserDesignation(designationOption.get());
		
		
		theUser.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
		theUser.setCreatedDate(Instant.now());
		
//		user.setUserName(theUser.getUserName());
//		user.setLastName(theUser.getLastName());
//		user.setEmail(theUser.getEmail());
//		user.setMobileNo(theUser.getMobileNo());
//		user.setActiveStatus(theUser.getActiveStatus());
		String passwordTemp = "123456";
		String encryptedPassword = passwordEncoder.encode(passwordTemp);
		theUser.setPasswordHash(encryptedPassword);
		theUser.setResetKey(RandomUtil.generateResetKey());
		theUser.setResetDate(Instant.now());
		
		if(!imageDataFile.isEmpty()) {
        	final String fileName = UUID.randomUUID().toString() + ".jpg";
        	final String folderPath =   "Users" +"/" +"profile_pic";
            final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
            
            byte[] bytes;
			try {
				 bytes = imageDataFile.getBytes();
				 FileOutputStream writer = new FileOutputStream(fileImagePath);
	              writer.write(bytes);
	              writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			theUser.setUserFileName(fileName);
			theUser.setUserFolderName(folderPath);
        }else {
        	//This for setting default Image 
        	theUser.setUserFileName("avatar.png");
			theUser.setUserFolderName("default");
        }
		
		//Getting the User Marker Type 
		//We need to Set Event Type
		Integer markerType =  theUser.getMarkerType();
		if(markerType == 1) {
			EventMaster theEvent = new EventMaster();
			theEvent.setEventDepartment(theUser.getUserDepartment());
			theEvent.setEventName(request.getParameter("eventName"));
			
			Long productId =  Long.valueOf(request.getParameter("productId"));
			Optional<ProductMaster> productOpt = productMasterRepository.findById(productId);
			if(productOpt.isPresent()) {
				ProductMaster productMaster = productOpt.get();
				theEvent.setEventProduct(productMaster);
			}
			
			eventMasterRepository.save(theEvent);
			theUser.setEventId(theEvent.getEventId().intValue());
		}
		
		try {
			mailService.sendCreationEmail(theUser);
		}catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error Sending Mail");
		}
		
		userRepository.save(theUser);
		
		return theUser;
		
		
		
	}
	
	public User updateUser(User theUser, HttpServletRequest request,MultipartFile imageDataFile) {
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		
		Long roleId =  Long.valueOf(request.getParameter("roleId"));
		Optional<RoleMst> role =  roleRepository.findById(roleId);
		theUser.setRole(role.get());
		
		Long departmentId =  Long.valueOf(request.getParameter("departmentId"));
		Optional<Department> departmentOption  =  departmentRepository.findById(departmentId);
		theUser.setUserDepartment(departmentOption.get());
		
		Long designationId =  Long.valueOf(request.getParameter("designationId"));
		Optional<Designation> designationOption =  designationRepository.findById(designationId);
		theUser.setUserDesignation(designationOption.get());
		
		theUser.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
		theUser.setModifiedDate(Instant.now());
		
		
		Optional<User> result =  userRepository.findById(theUser.getUserId());
		User userTemp = null;
		if(result.isPresent()) {
			userTemp = result.get();
		}
		
		theUser.setPasswordHash(userTemp.getPasswordHash());
		theUser.setCreatedBy(userTemp.getCreatedBy());
		theUser.setCreatedDate(userTemp.getCreatedDate());
		theUser.setLoggedInTime(userTemp.getLoggedInTime());
		theUser.setIpAdress(userTemp.getIpAdress());
		
		//Getting the User Marker Type 
		if(theUser.getMarkerType() != userTemp.getMarkerType()) { //This Means Marker Type as  been changed
			//set event id // since getting deleted or replaced
			if(userTemp.getEventId()!=null)
			theUser.setEventId(userTemp.getEventId().intValue());
		}
		//We need to Set Event Type
		Integer markerType =  theUser.getMarkerType();
		if(markerType == 1) {
			EventMaster theEvent = new EventMaster();
			if(theUser.getEventId()!=null) {
				Optional<EventMaster> optionalEvent  =  eventMasterRepository.findById(Long.valueOf(theUser.getEventId()));
				if(optionalEvent.isPresent()) {
					theEvent =  optionalEvent.get();
				}
			}
			theEvent.setEventDepartment(theUser.getUserDepartment());
			theEvent.setEventName(request.getParameter("eventName"));
			Long productId =  Long.valueOf(request.getParameter("productId"));
			Optional<ProductMaster> productOpt = productMasterRepository.findById(productId);
			if(productOpt.isPresent()) {
				ProductMaster productMaster = productOpt.get();
				theEvent.setEventProduct(productMaster);
			}
			eventMasterRepository.save(theEvent);
			theUser.setEventId(theEvent.getEventId().intValue());
		}
		
		if(!imageDataFile.isEmpty()) {
        	final String fileName = UUID.randomUUID().toString() + ".jpg";
        	final String folderPath =   "Users" +"/" +"profile_pic";
            final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
            
            byte[] bytes;
			try {
				 bytes = imageDataFile.getBytes();
				 FileOutputStream writer = new FileOutputStream(fileImagePath);
	              writer.write(bytes);
	              writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			theUser.setUserFileName(fileName);
			theUser.setUserFolderName(folderPath);
        }
		
		if(theUser.getUserFileName() == null || theUser.getUserFileName() == "") {
			
			//This for setting default Image 
        	theUser.setUserFileName("avatar.png");
			theUser.setUserFolderName("default");
		}
		
        userRepository.save(theUser);
		
		return theUser;
	}


	public User getUserDetail(Long id) {
		Optional<User> result =  userRepository.findById(id);
		User userTemp = null;
		if(result.isPresent()) {
			userTemp = result.get();
		}
		return userTemp;
	}


	public User createOrUpdateUser(@Valid User theUser, HttpServletRequest request) {
		return userRepository.save(theUser);
	}
	
	
	public RoleMst getRole(String roleName) {
		RoleMst role =null;
		try {
			System.out.println(roleRepository.toString());
			if(roleRepository == null) {
				System.out.println("is Null");
			}
			
			Optional<RoleMst> roles =  roleRepository.findByRoleName(roleName);
			System.out.println(roles.isPresent());
			role =  roles.get();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return role;
		
	}
	
	public MenuMaster getMenuMaster(Long tempId) {
		return menuRepository.findByMenuId(tempId).get();
	}
	
}
