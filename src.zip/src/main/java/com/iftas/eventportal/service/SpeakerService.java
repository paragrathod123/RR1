package com.iftas.eventportal.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.apache.poi.ss.usermodel.PictureData;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFPicture;
import org.apache.poi.xssf.usermodel.XSSFShape;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.iftas.eventportal.dao.CentreRepository;
import com.iftas.eventportal.dao.DepartmentRepository;
import com.iftas.eventportal.dao.DesignationRepository;
import com.iftas.eventportal.dao.EventAdminRepository;
import com.iftas.eventportal.dao.EventMasterRepository;
import com.iftas.eventportal.dao.EventSpeakerRepository;
import com.iftas.eventportal.dao.MobileEventUserRepository;
import com.iftas.eventportal.dao.MobileUserRepository;
import com.iftas.eventportal.dao.OrganizationRepository;
import com.iftas.eventportal.dao.SpeakersRepository;
import com.iftas.eventportal.dto.SpeakerUploadDTO;
import com.iftas.eventportal.entity.Centres;
import com.iftas.eventportal.entity.EventAdmin;
import com.iftas.eventportal.entity.EventMaster;
import com.iftas.eventportal.entity.EventParticipants;
import com.iftas.eventportal.entity.EventSpeakers;
import com.iftas.eventportal.entity.MobileEventUsers;
import com.iftas.eventportal.entity.MobileUsers;
import com.iftas.eventportal.entity.Organization;
import com.iftas.eventportal.entity.ParticipantMaster;
import com.iftas.eventportal.entity.SpeakerMaster;
import com.iftas.eventportal.entity.User;
import com.iftas.eventportal.utils.DataRow;
import com.iftas.eventportal.utils.DataTable;
import com.iftas.eventportal.utils.ExcelTable;

@Service
@Transactional
public class SpeakerService {
	
	
	@Autowired
	private SpeakersRepository  speakersRepository;
	
	@Autowired
	private OrganizationRepository organizationRepository;
	
	@Autowired
	private CentreRepository centreRepository;
	
	@Autowired
	private DepartmentRepository departmentRepository;
	
	@Autowired
	private DesignationRepository designationRepository;
	
	@Autowired
	private EventSpeakerRepository eventSpeakerRepository;
	
	@Autowired
	private EventMasterRepository eventMasterRepository;
	
	@Autowired
	private MobileUserRepository mobileUserRepository;
	
	@Autowired
	private MobileEventUserRepository mobileEventUserRepository;
	
	@Autowired
	private EventAdminRepository eventAdminRepository;
	
	
	public List<SpeakerMaster>getSpeakerList(){
		return speakersRepository.findAllByOrderBySpeakerFirstNameAsc();
	}
	
	public List<SpeakerMaster>getSpeakerListByActiveStatus(int activeStatus){
		return speakersRepository.findAllByActiveStatusOrderBySpeakerFirstNameAsc(activeStatus);
	}
	
	public SpeakerMaster getSpeakerById(Long id) {
		return speakersRepository.findById(id).get();	
	}
	
	
	
	public void uploadSpeakers(
			MultipartFile reapExcelDataFile,
			HttpServletRequest request) throws IOException {
		
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		Map<Integer, SpeakerMaster> uploadSpeakerMap =  new HashMap<Integer, SpeakerMaster>();
 		
		final String label = UUID.randomUUID().toString() + ".xlsx";
	    final String filepath1 = filePath+"temp/" + label;
	    byte[] bytes = reapExcelDataFile.getBytes();
	    File fh = new File(filePath+"temp/");
	    if(!fh.exists()){
	         fh.mkdir();
	    }
	    //SpeakerUploadDTO speakerUpload = new SpeakerUploadDTO();
	    try {
	    	
	    	
	    	  FileOutputStream writer = new FileOutputStream(filepath1);
	          writer.write(bytes);
	          writer.close();
	          FileInputStream inputStream = new FileInputStream(filepath1);
	          
	          //For Sheet 0
	          DataTable table = ExcelTable.load(() -> inputStream,0);
	          int rowCount = table.rowCount();
	          for(int i=0; i < rowCount; ++i) {
	             DataRow row = table.row(i);
	             
	             String Title = row.cell("Title");
	             String FirstName = row.cell("FirstName");
	             String LastName = row.cell("LastName");
	             String Organization = row.cell("Organization");
	             String Center = row.cell("Center");
	             String Department = row.cell("Department");
	             String Designation = row.cell("Designation");
	             String EmailId = row.cell("EmailId");
	             String MobileNo = row.cell("MobileNo");
	             
	             if(EmailId!="" && !EmailId.equals("") && !EmailId.equals("null") ) { 
		             SpeakerMaster speakerMaster = new SpeakerMaster();
		             speakerMaster.setTitle(Title);
		             speakerMaster.setSpeakerFirstName(FirstName);
		             speakerMaster.setSpeakerLastName(LastName);
		             
		             if(organizationRepository.findByOrganizationNameIgnoreCase(Organization).isPresent()) {
		            	 speakerMaster.setSpeakerOrganization(organizationRepository.findByOrganizationNameIgnoreCase(Organization).get());
		             }
		             
		             if(centreRepository.findByCentreName(Center).isPresent()) {
		            	 speakerMaster.setSpeakerCenter(centreRepository.findByCentreName(Center).get());
		             }
		             
		             if(departmentRepository.findByDepartmentNameIgnoreCase(Department).isPresent()) {
		            	 speakerMaster.setSpeakerDepartment(departmentRepository.findByDepartmentNameIgnoreCase(Department).get());
		             }
		             
		             if(designationRepository.findByDesignationNameIgnoreCase(Designation).isPresent()) {
		            	 speakerMaster.setSpeakerDesignation(designationRepository.findByDesignationNameIgnoreCase(Designation).get());
		             }
		             
		             speakerMaster.setSpeakerEmailId(EmailId);
		             speakerMaster.setSpeakerMobileNo(MobileNo);
		             speakerMaster.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
		             speakerMaster.setCreatedDate(Instant.now());
		             speakerMaster.setModifiedBy(0);
		             uploadSpeakerMap.put(i+1, speakerMaster);
	             }
	          }
	          
	          
	          
	          //Below Part for Storing Image
	          //Below for getting image 
	          FileInputStream inputStream1 = new FileInputStream(filepath1);
	          XSSFWorkbook  wb = new XSSFWorkbook(inputStream1);
	          XSSFSheet sheet = wb.getSheetAt(0);
	          XSSFDrawing xssDrawing = sheet.getDrawingPatriarch();
	          List<XSSFShape> shapes = xssDrawing.getShapes();
	          int shapeCount=0; //skiping first
	          for (XSSFShape shape : shapes) {
	             
	              if (shape instanceof XSSFPicture) {
	                 
	                 
	                  XSSFPicture hssfPicture = (XSSFPicture) shape;
	                  int rowIndex = hssfPicture.getClientAnchor().getRow1();
	                  
	                  
	                  //For Filename get
	                  final String fileName = UUID.randomUUID().toString() +".jpg";
	                  //Set File Name & Folder Name
	                  final String folderPath =   "Speakers" +"/" +"profile_pic";
	                  final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
	                  
	                  
	                  
	                  System.out.println(fileName);
	                  System.out.println(folderPath);
	                  System.out.println(fileImagePath);
	                  System.out.println(rowIndex);
	                  
	                  PictureData data = hssfPicture.getPictureData();
	                  byte [] picData = data.getData();
	                  FileOutputStream fos = new FileOutputStream(new File(fileImagePath));
	                  fos.write(picData);
	                  fos.close();
	                 
	                 
	                  int colIndex = hssfPicture.getClientAnchor().getCol1();
	                  System.out.println("Picture  is located row: " + rowIndex+ ", col: " + colIndex);
	                  
	                  //Get Map Value 
	                  if(uploadSpeakerMap.get(rowIndex)!=null) {
		                  SpeakerMaster speaker =  uploadSpeakerMap.get(rowIndex);
		                  speaker.setSpeakerFileName(fileName);
		                  speaker.setSpeakerFolderName(folderPath);
		                  uploadSpeakerMap.put(rowIndex, speaker);
	                  }
	              }
	             
	              shapeCount++;
	          }
	          
	    	
	    	
	    }catch (Exception e) {
			e.printStackTrace();
		}
	    
	    //finally Data insert begin 
	    for (Map.Entry<Integer, SpeakerMaster> entry : uploadSpeakerMap.entrySet()) {
	    	SpeakerMaster speaker =  entry.getValue();
	    	speakersRepository.save(speaker);
	    }
    	
	}
	
	public void uploadEventSpeakers(
			MultipartFile reapExcelDataFile,
			HttpServletRequest request) throws IOException {
		
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		Map<Integer, SpeakerMaster> uploadSpeakerMap =  new HashMap<Integer, SpeakerMaster>();
 		
		final String label = UUID.randomUUID().toString() + ".xlsx";
	    final String filepath1 = filePath+"temp/" + label;
	    byte[] bytes = reapExcelDataFile.getBytes();
	    File fh = new File(filePath+"temp/");
	    if(!fh.exists()){
	         fh.mkdir();
	    }
	    
	    try {
	    	
	    	FileOutputStream writer = new FileOutputStream(filepath1);
	        writer.write(bytes);
	        writer.close();
	          
	    	EventMaster eventMaster = new EventMaster();
	        //Below Code for Mapping Event Speaker and Other Related Data 
	        if(request.getParameter("eventId") !=null  && !request.getParameter("eventId").equals("")
	      		  && !request.getParameter("eventId").equals("null")) {
	      	  Optional<EventMaster> eventOptionalMaster = eventMasterRepository.findById(Long.valueOf(request.getParameter("eventId")));
	      	  if(eventOptionalMaster.isPresent()) {
	      		  eventMaster = eventOptionalMaster.get();
	      	  }
	        }	
	    	  //For Sheet 0 -- > Event Speaker Start
	          Map<Integer, EventSpeakers> uploadEventSpeakerMap =  new HashMap<Integer, EventSpeakers>();
	          FileInputStream inputStream2 = new FileInputStream(filepath1);
	          DataTable table = ExcelTable.load(() -> inputStream2,0);
	          int rowCount = table.rowCount();
	          for(int i=0; i < rowCount; ++i) {
	        	 SpeakerMaster speakerMaster = new SpeakerMaster();
	        	 EventSpeakers eventSpeakers = new EventSpeakers();
	             DataRow row = table.row(i);
	             
	             String Title = row.cell("Title");
	             String FirstName = row.cell("FirstName");
	             String LastName = row.cell("LastName");
	             String Organization = row.cell("Organization");
	             String Center = row.cell("Center");
	             String Department = row.cell("Department");
	             String Designation = row.cell("Designation");
	             String EmailId = row.cell("EmailId");
	             String MobileNo = row.cell("MobileNo");
	             String roomNo = row.cell("Room no");
	             String emergencyContactNo = row.cell("Emergency Contact No");
	             String allergies = row.cell("Allergies");
	             String driverName = row.cell("Driver Name");
	             String driverContactNo = row.cell("Driver Contact No");
	             String driverCABNo = row.cell("Driver CAB No");
	             
	             if(EmailId!=null && !EmailId.equals("")
							&& !EmailId.equals("null")) {
	            	Optional<SpeakerMaster> optionalSpeaker = speakersRepository.findOneBySpeakerEmailIdIgnoreCase(EmailId);
	            	if(optionalSpeaker.isPresent()) {
	            		speakerMaster =  optionalSpeaker.get();
	            		speakerMaster.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
	            		speakerMaster.setModifiedDate(Instant.now());
	            	}else {
	            		speakerMaster.setSpeakerEmailId(EmailId);
	            		speakerMaster.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
	   	                speakerMaster.setCreatedDate(Instant.now());
	            	}
	             }
	             
	             if(Title!=null && !Title.equals("")
							&& !Title.equals("null")) {
	            	 speakerMaster.setTitle(Title);
	             } 
	             if(FirstName!=null && !FirstName.equals("")
							&& !FirstName.equals("null")) {
	            	 speakerMaster.setSpeakerFirstName(FirstName);
	             } 
	             if(LastName!=null && !LastName.equals("")
							&& !LastName.equals("null")) {
	            	 speakerMaster.setSpeakerLastName(LastName);
	             }
	             if(Organization!=null && !Organization.equals("")
							&& !Organization.equals("null")) {
	            	 if(organizationRepository.findByOrganizationNameIgnoreCase(Organization).isPresent()) {
		            	 speakerMaster.setSpeakerOrganization(organizationRepository.findByOrganizationNameIgnoreCase(Organization).get());
		             }
	             }
	             if(Center!=null && !Center.equals("")
							&& !Center.equals("null")) {
	            	 if(centreRepository.findByCentreName(Center).isPresent()) {
		            	 speakerMaster.setSpeakerCenter(centreRepository.findByCentreName(Center).get());
		             }
	             }
	             if(Department!=null && !Department.equals("")
							&& !Department.equals("null")) {
	            	 if(departmentRepository.findByDepartmentNameIgnoreCase(Department).isPresent()) {
		            	 speakerMaster.setSpeakerDepartment(departmentRepository.findByDepartmentNameIgnoreCase(Department).get());
		             }
	             }
	             if(Designation!=null && !Designation.equals("")
							&& !Designation.equals("null")) {
	            	 if(designationRepository.findByDesignationNameIgnoreCase(Designation).isPresent()) {
		            	 speakerMaster.setSpeakerDesignation(designationRepository.findByDesignationNameIgnoreCase(Designation).get());
		             }
	             }
	             
	             if(MobileNo!=null && !MobileNo.equals("")
							&& !MobileNo.equals("null")) {
	            	 speakerMaster.setSpeakerMobileNo(MobileNo);
	             }
	             
	             eventSpeakers.setEventSpeaker(speakerMaster);;
	             
	             if(roomNo!=null && !roomNo.equals("")
							&& !roomNo.equals("null")) {
	            	 eventSpeakers.setRoomNo(roomNo);
	             }
	             if(emergencyContactNo!=null && !emergencyContactNo.equals("")
							&& !emergencyContactNo.equals("null")) {
	            	 eventSpeakers.setEmergencyContactNo(emergencyContactNo);
	             }
	             if(allergies!=null && !allergies.equals("")
							&& !allergies.equals("null")) {
	            	 eventSpeakers.setAllergies(allergies);
	             }
	             if(driverName!=null && !driverName.equals("")
							&& !driverName.equals("null")) {
	            	 eventSpeakers.setDriverName(driverName);
	             }
	             if(driverContactNo!=null && !driverContactNo.equals("")
							&& !driverContactNo.equals("null")) {
	            	 eventSpeakers.setDriverContactNo(driverContactNo);
	             }
	             if(driverCABNo!=null && !driverCABNo.equals("")
							&& !driverCABNo.equals("null")) {
	            	 eventSpeakers.setDriverCabNo(driverCABNo);
	             }
	             eventSpeakers.setEventSpeakers(eventMaster);
	             uploadEventSpeakerMap.put(i+1, eventSpeakers);
	             //eventSpeakerRepository.save(eventSpeakers);
	          }
	          
	          //Below Part for Storing Image
	          //Below for getting image 
	          FileInputStream inputStream2_image = new FileInputStream(filepath1);
	          XSSFWorkbook  wb = new XSSFWorkbook(inputStream2_image);
	          XSSFSheet sheet = wb.getSheetAt(0);
	          XSSFDrawing xssDrawing = sheet.getDrawingPatriarch();
	          List<XSSFShape> shapes = xssDrawing.getShapes();
	          int shapeCount=0; //skiping first
	          for (XSSFShape shape : shapes) {
	              if (shape instanceof XSSFPicture) {
	                 
	                  XSSFPicture hssfPicture = (XSSFPicture) shape;
	                  int rowIndex = hssfPicture.getClientAnchor().getRow1();
	                  //For Filename get
	                  final String fileName = UUID.randomUUID().toString() +".jpg";
	                  //Set File Name & Folder Name
	                  final String folderPath =   "Speakers" +"/" +"profile_pic";
	                  final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
	                  System.out.println(fileName);
	                  System.out.println(folderPath);
	                  System.out.println(fileImagePath);
	                  System.out.println(rowIndex);
	                  PictureData data = hssfPicture.getPictureData();
	                  byte [] picData = data.getData();
	                  FileOutputStream fos = new FileOutputStream(new File(fileImagePath));
	                  fos.write(picData);
	                  fos.close();
	                  int colIndex = hssfPicture.getClientAnchor().getCol1();
	                  System.out.println("Picture  is located row: " + rowIndex+ ", col: " + colIndex);
	                  //Get Map Value 
	                  if(uploadEventSpeakerMap.get(rowIndex)!=null) {
	                	  EventSpeakers eventSpeaker =  uploadEventSpeakerMap.get(rowIndex);
		                  SpeakerMaster speaker =  eventSpeaker.getEventSpeaker();
		                  speaker.setSpeakerFileName(fileName);
		                  speaker.setSpeakerFolderName(folderPath);
		                  eventSpeaker.setEventSpeaker(speaker);
		                  uploadEventSpeakerMap.put(rowIndex, eventSpeaker);
	                  }
	              }
	             
	              shapeCount++;
	          }
	          //Finally Saving Parts Starts Here
	          //finally Data insert begin 
	  	      for (Map.Entry<Integer, EventSpeakers> entry : uploadEventSpeakerMap.entrySet()) {
	  	    	EventSpeakers eventSpeaker =  entry.getValue();
	  	    	speakersRepository.save(eventSpeaker.getEventSpeaker());
	  	    	eventSpeakerRepository.save(eventSpeaker);
	  	      }
	          
	         //For Sheet 0 -- > Event Speaker Ends 
	    	
	    	
	    }catch (Exception e) {
				e.printStackTrace();
		}
	    	
	}


	
	
	public SpeakerMaster creatSpeaker(SpeakerMaster theSpeaker,MultipartFile reapExcelDataFile, HttpServletRequest request) {
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		
		
		Long organizationId =  Long.valueOf(request.getParameter("organizationId"));
		Long centreId = Long.valueOf(request.getParameter("centreId"));
		Long departmentId = Long.valueOf(request.getParameter("departmentId"));
		Long designationId = Long.valueOf(request.getParameter("designationId"));
		
		
		if(organizationRepository.findById(organizationId).isPresent()) {
			theSpeaker.setSpeakerOrganization(organizationRepository.findById(organizationId).get());
        }
        
        if(centreRepository.findById(centreId).isPresent()) {
        	theSpeaker.setSpeakerCenter(centreRepository.findById(centreId).get());
        }
        
        if(departmentRepository.findById(departmentId).isPresent()) {
        	theSpeaker.setSpeakerDepartment(departmentRepository.findById(departmentId).get());
        }
        
        if(designationRepository.findById(designationId).isPresent()) {
        	theSpeaker.setSpeakerDesignation(designationRepository.findById(departmentId).get());
        }
		
        
        if(!reapExcelDataFile.isEmpty()) {
        	final String fileName = UUID.randomUUID().toString() + ".jpg";
        	final String folderPath =   "Speakers" +"/" +"profile_pic";
            final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
            
            byte[] bytes;
			try {
				 bytes = reapExcelDataFile.getBytes();
				 FileOutputStream writer = new FileOutputStream(fileImagePath);
	              writer.write(bytes);
	              writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			theSpeaker.setSpeakerFileName(fileName);
			theSpeaker.setSpeakerFolderName(folderPath);
        }
        
        
      //Setting Created By  //Let Say Default
      theSpeaker.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
	  //Setting Created Date
      theSpeaker.setCreatedDate(Instant.now());
     
      speakersRepository.save(theSpeaker);
	  return theSpeaker;
	}

	public void updateSpeaker(@Valid SpeakerMaster theSpeaker, HttpServletRequest request,
			MultipartFile imageDataFile) {
		
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		
		Long organizationId =  Long.valueOf(request.getParameter("organizationId"));
		Long centreId = Long.valueOf(request.getParameter("centreId"));
		Long departmentId = Long.valueOf(request.getParameter("departmentId"));
		Long designationId = Long.valueOf(request.getParameter("designationId"));
		
		
		if(organizationRepository.findById(organizationId).isPresent()) {
			theSpeaker.setSpeakerOrganization(organizationRepository.findById(organizationId).get());
        }
        
        if(centreRepository.findById(centreId).isPresent()) {
        	theSpeaker.setSpeakerCenter(centreRepository.findById(centreId).get());
        }
        
        if(departmentRepository.findById(departmentId).isPresent()) {
        	theSpeaker.setSpeakerDepartment(departmentRepository.findById(departmentId).get());
        }
        
        if(designationRepository.findById(designationId).isPresent()) {
        	theSpeaker.setSpeakerDesignation(designationRepository.findById(departmentId).get());
        }
        
        theSpeaker.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
        theSpeaker.setModifiedDate(Instant.now());
		
        SpeakerMaster speakerTemp =  getSpeakerById(theSpeaker.getSpeakerId());
        theSpeaker.setCreatedBy(speakerTemp.getCreatedBy());
        theSpeaker.setCreatedDate(speakerTemp.getCreatedDate());
        
        if(!imageDataFile.isEmpty()) {
        	final String fileName = UUID.randomUUID().toString() + ".jpg";
        	final String folderPath =   "Speakers" +"/" +"profile_pic";
            final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
            
            byte[] bytes;
			try {
				 bytes = imageDataFile.getBytes();
				 FileOutputStream writer = new FileOutputStream(fileImagePath);
	              writer.write(bytes);
	              writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			theSpeaker.setSpeakerFileName(fileName);
			theSpeaker.setSpeakerFolderName(folderPath);
        }
		
		if(theSpeaker.getSpeakerFileName() == null || theSpeaker.getSpeakerFileName() == "") {
			//This for setting default Image 
			theSpeaker.setSpeakerFileName("avatar.png");
			theSpeaker.setSpeakerFolderName("default");
		}
		speakersRepository.save(theSpeaker);
	}
	
	
	
      public SpeakerMaster createEventSpeaker(SpeakerMaster theSpeaker,MultipartFile reapExcelDataFile, HttpServletRequest request) {
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		
		
		Long organizationId =  Long.valueOf(request.getParameter("organizationId"));
		Long centreId = Long.valueOf(request.getParameter("centreId"));
		Long departmentId = Long.valueOf(request.getParameter("departmentId"));
		Long designationId = Long.valueOf(request.getParameter("designationId"));
		
		
		if(organizationRepository.findById(organizationId).isPresent()) {
			theSpeaker.setSpeakerOrganization(organizationRepository.findById(organizationId).get());
        }
        
        if(centreRepository.findById(centreId).isPresent()) {
        	theSpeaker.setSpeakerCenter(centreRepository.findById(centreId).get());
        }
        
        if(departmentRepository.findById(departmentId).isPresent()) {
        	theSpeaker.setSpeakerDepartment(departmentRepository.findById(departmentId).get());
        }
        
        if(designationRepository.findById(designationId).isPresent()) {
        	theSpeaker.setSpeakerDesignation(designationRepository.findById(designationId).get());
        }
		
        
        if(!reapExcelDataFile.isEmpty()) {
        	final String fileName = UUID.randomUUID().toString() + ".jpg";
        	final String folderPath =   "Speakers" +"/" +"profile_pic";
            final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
            
            byte[] bytes;
			try {
				 bytes = reapExcelDataFile.getBytes();
				 FileOutputStream writer = new FileOutputStream(fileImagePath);
	              writer.write(bytes);
	              writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			theSpeaker.setSpeakerFileName(fileName);
			theSpeaker.setSpeakerFolderName(folderPath);
        }else {
        	//This for setting default Image 
        	theSpeaker.setSpeakerFileName("avatar.png");
        	theSpeaker.setSpeakerFolderName("default");
        }
        
        
      //Setting Created By  //Let Say Default
      theSpeaker.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
	  //Setting Created Date
      theSpeaker.setCreatedDate(Instant.now());
     
      speakersRepository.save(theSpeaker);
      
      EventMaster eventMaster = new EventMaster();
      EventSpeakers eventSpeaker = new EventSpeakers();
      //Below Code for Mapping Event Speaker and Other Related Data 
      if(request.getParameter("eventId") !=null  && !request.getParameter("eventId").equals("")
    		  && !request.getParameter("eventId").equals("null")) {
    	  Optional<EventMaster> eventOptionalMaster = eventMasterRepository.findById(Long.valueOf(request.getParameter("eventId")));
    	  if(eventOptionalMaster.isPresent()) {
    		  eventMaster = eventOptionalMaster.get();
    	  }
      }
      
      if(request.getParameter("speakerRoomNo") !=null  && !request.getParameter("speakerRoomNo").equals("")
    		  && !request.getParameter("speakerRoomNo").equals("null")) {
    	  eventSpeaker.setRoomNo(request.getParameter("speakerRoomNo"));
      }
      if(request.getParameter("speakerEmergencyContactNo") !=null  && !request.getParameter("speakerEmergencyContactNo").equals("")
    		  && !request.getParameter("speakerEmergencyContactNo").equals("null")) {
    	  eventSpeaker.setEmergencyContactNo(request.getParameter("speakerEmergencyContactNo"));
      }
      if(request.getParameter("speakerAllergies") !=null  && !request.getParameter("speakerAllergies").equals("")
    		  && !request.getParameter("speakerAllergies").equals("null")) {
    	  eventSpeaker.setAllergies(request.getParameter("speakerAllergies"));
      }
      if(request.getParameter("speakerDriverName") !=null  && !request.getParameter("speakerDriverName").equals("")
    		  && !request.getParameter("speakerDriverName").equals("null")) {
    	  eventSpeaker.setDriverName(request.getParameter("speakerDriverName"));
      }
      if(request.getParameter("speakerDriverPhoneNo") !=null  && !request.getParameter("speakerDriverPhoneNo").equals("")
    		  && !request.getParameter("speakerDriverPhoneNo").equals("null")) {
    	  eventSpeaker.setDriverContactNo(request.getParameter("speakerDriverPhoneNo"));
      }
      if(request.getParameter("speakerDriverCabNo") !=null  && !request.getParameter("speakerDriverCabNo").equals("")
    		  && !request.getParameter("speakerDriverCabNo").equals("null")) {
    	  eventSpeaker.setDriverCabNo(request.getParameter("speakerDriverCabNo"));
      }
      
      if(eventMaster!=null) {
    	  eventSpeaker.setEventSpeakers(eventMaster);
    	  eventSpeaker.setEventSpeaker(theSpeaker);
    	  eventSpeakerRepository.save(eventSpeaker);
      }
      
      
      
      if(request.getParameter("loginId") !=null  && !request.getParameter("loginId").equals("")
    		  && !request.getParameter("loginId").equals("null")) {
    	  
    	  //Finally Enter Record Inside Mobile_User Table & Mobile User Event Table 
          MobileUsers mobileUser = new MobileUsers();
          EventAdmin eventAdmin = new EventAdmin();
          Optional<MobileUsers> optionalMobileUser = mobileUserRepository.findOneByUserIdIgnoreCase(request.getParameter("loginId").trim());
          if(optionalMobileUser.isPresent()) {
        	  mobileUser = optionalMobileUser.get();
          }
          if(theSpeaker.getSpeakerMobileNo() !=null) {
        	  mobileUser.setUserMobileNo("91"+theSpeaker.getSpeakerMobileNo());
          }
          //mobileUser.setUserType(0);
          //mobileUser.setUserTypeId(theSpeaker.getSpeakerId().intValue());
          if(request.getParameter("isAdmin") !=null  && !request.getParameter("isAdmin").equals("")
        		  && !request.getParameter("isAdmin").equals("null")) {
        	  mobileUser.setIsAdmin(Integer.parseInt(request.getParameter("isAdmin")));
          }
    	  mobileUser.setUserId(request.getParameter("loginId").trim());
    	  mobileUser.setEmail_id(theSpeaker.getSpeakerEmailId());
    	  mobileUser.setUserName(theSpeaker.getSpeakerFirstName() + " " + ((theSpeaker.getSpeakerLastName()!=null && theSpeaker.getSpeakerLastName()!="")?theSpeaker.getSpeakerLastName():""));
          mobileUser.setActiveStatus(theSpeaker.getActiveStatus());
          mobileUserRepository.save(mobileUser);
          MobileEventUsers mobileEventUsers = new MobileEventUsers();
          mobileEventUsers.setEventId(eventMaster.getEventId());
          mobileEventUsers.setMobileUserId(mobileUser.getId());
          mobileEventUserRepository.save(mobileEventUsers);
          
          
          if(mobileUser.getIsAdmin() ==  1) {
         	 Optional<EventAdmin> optionEventAdmin =  eventAdminRepository.findAllByEventIdAndMail(eventMaster.getEventId(), theSpeaker.getSpeakerEmailId());
         	 if(optionEventAdmin.isPresent()) {
         		 eventAdmin =  optionEventAdmin.get();
         	 }
         	 eventAdmin.setAdminEmailId(theSpeaker.getSpeakerEmailId());
         	 eventAdmin.setAdminContactAddress(theSpeaker.getSpeakerMobileNo());
         	 eventAdmin.setAdminFullName(theSpeaker.getSpeakerFirstName() + " " + ((theSpeaker.getSpeakerLastName()!=null && theSpeaker.getSpeakerLastName()!="")?theSpeaker.getSpeakerLastName():""));
         	 eventAdmin.setEventAdmin(eventMaster);
         	 eventAdminRepository.save(eventAdmin);
	      }
      }
     
      
      
	  return theSpeaker;
	}
      
      
      public SpeakerMaster updateEventSpeaker(SpeakerMaster theSpeaker,MultipartFile imageDataFile, HttpServletRequest request) {
  		
    	HttpSession session =  request.getSession();
  		String filePath = (String)session.getAttribute("pathUrl");
  		
  		Long organizationId =  Long.valueOf(request.getParameter("organizationId"));
  		Long centreId = Long.valueOf(request.getParameter("centreId"));
  		Long departmentId = Long.valueOf(request.getParameter("departmentId"));
  		Long designationId = Long.valueOf(request.getParameter("designationId"));
  		
  		
  		  if(organizationRepository.findById(organizationId).isPresent()) {
  			theSpeaker.setSpeakerOrganization(organizationRepository.findById(organizationId).get());
          }
          
          if(centreRepository.findById(centreId).isPresent()) {
          	theSpeaker.setSpeakerCenter(centreRepository.findById(centreId).get());
          }
          
          if(departmentRepository.findById(departmentId).isPresent()) {
          	theSpeaker.setSpeakerDepartment(departmentRepository.findById(departmentId).get());
          }
          
          if(designationRepository.findById(designationId).isPresent()) {
          	theSpeaker.setSpeakerDesignation(designationRepository.findById(designationId).get());
          }
          
          theSpeaker.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
          theSpeaker.setModifiedDate(Instant.now());
  		
          SpeakerMaster speakerTemp =  getSpeakerById(theSpeaker.getSpeakerId());
          theSpeaker.setCreatedBy(speakerTemp.getCreatedBy());
          theSpeaker.setCreatedDate(speakerTemp.getCreatedDate());
          
          if(!imageDataFile.isEmpty()) {
          	final String fileName = UUID.randomUUID().toString() + ".jpg";
          	final String folderPath =   "Speakers" +"/" +"profile_pic";
              final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
              
              byte[] bytes;
  			try {
  				 bytes = imageDataFile.getBytes();
  				 FileOutputStream writer = new FileOutputStream(fileImagePath);
  	              writer.write(bytes);
  	              writer.close();
  			} catch (IOException e) {
  				// TODO Auto-generated catch block
  				e.printStackTrace();
  			}
  			
  			theSpeaker.setSpeakerFileName(fileName);
  			theSpeaker.setSpeakerFolderName(folderPath);
          }
  		
  		if(theSpeaker.getSpeakerFileName() == null || theSpeaker.getSpeakerFileName() == "") {
  			//This for setting default Image 
  			theSpeaker.setSpeakerFileName("avatar.png");
  			theSpeaker.setSpeakerFolderName("default");
  		}
  		speakersRepository.save(theSpeaker);
        
		
  		EventMaster eventMaster = new EventMaster();
        EventSpeakers eventSpeaker = new EventSpeakers();
        //Below Code for Mapping Event Speaker and Other Related Data 
        if(request.getParameter("eventId") !=null  && !request.getParameter("eventId").equals("")
      		  && !request.getParameter("eventId").equals("null")) {
        	  //Getting Data from event Speaker & event Id
        	  Optional<EventMaster> eventOptionalMaster = eventMasterRepository.findById(Long.valueOf(request.getParameter("eventId")));
	      	  if(eventOptionalMaster.isPresent()) {
	      		  eventMaster = eventOptionalMaster.get();
	      	  }
    		  Optional<EventSpeakers> optionalEventSpeaker = eventSpeakerRepository.findBySpeakerAndEventId(eventMaster.getEventId(), theSpeaker.getSpeakerId());
	    	  if(optionalEventSpeaker.isPresent()) {
	    			eventSpeaker = optionalEventSpeaker.get();
	    	  }else {
	    		    eventSpeaker.setEventSpeakers(eventMaster);
	    	  }
        }
        
        if(request.getParameter("speakerRoomNo") !=null  && !request.getParameter("speakerRoomNo").equals("")
      		  && !request.getParameter("speakerRoomNo").equals("null")) {
      	  eventSpeaker.setRoomNo(request.getParameter("speakerRoomNo"));
        }
        if(request.getParameter("speakerEmergencyContactNo") !=null  && !request.getParameter("speakerEmergencyContactNo").equals("")
      		  && !request.getParameter("speakerEmergencyContactNo").equals("null")) {
      	  eventSpeaker.setEmergencyContactNo(request.getParameter("speakerEmergencyContactNo"));
        }
        if(request.getParameter("speakerAllergies") !=null  && !request.getParameter("speakerAllergies").equals("")
      		  && !request.getParameter("speakerAllergies").equals("null")) {
      	  eventSpeaker.setAllergies(request.getParameter("speakerAllergies"));
        }
        if(request.getParameter("speakerDriverName") !=null  && !request.getParameter("speakerDriverName").equals("")
      		  && !request.getParameter("speakerDriverName").equals("null")) {
      	  eventSpeaker.setDriverName(request.getParameter("speakerDriverName"));
        }
        if(request.getParameter("speakerDriverPhoneNo") !=null  && !request.getParameter("speakerDriverPhoneNo").equals("")
      		  && !request.getParameter("speakerDriverPhoneNo").equals("null")) {
      	  eventSpeaker.setDriverContactNo(request.getParameter("speakerDriverPhoneNo"));
        }
        if(request.getParameter("speakerDriverCabNo") !=null  && !request.getParameter("speakerDriverCabNo").equals("")
      		  && !request.getParameter("speakerDriverCabNo").equals("null")) {
      	  eventSpeaker.setDriverCabNo(request.getParameter("speakerDriverCabNo"));
        }
          
      	eventSpeaker.setEventSpeaker(theSpeaker);
      	eventSpeakerRepository.save(eventSpeaker);
      	
      	
      
      if(request.getParameter("loginId") !=null  && !request.getParameter("loginId").equals("")
    		  && !request.getParameter("loginId").equals("null")) {
    	  
    	  //Finally Enter Record Inside Mobile_User Table & Mobile User Event Table 
          MobileUsers mobileUser = new MobileUsers();	
          EventAdmin eventAdmin = new EventAdmin();
          Optional<MobileUsers> optionalMobileUser = mobileUserRepository.findOneByUserIdIgnoreCase(request.getParameter("loginId").trim());
          if(optionalMobileUser.isPresent()) {
        	  mobileUser = optionalMobileUser.get();
          }
          //Add Condition to check by User Id 
          if(theSpeaker.getSpeakerMobileNo() !=null) {
        	  mobileUser.setUserMobileNo("91"+theSpeaker.getSpeakerMobileNo());
          }
          //mobileUser.setUserType(0);
          //mobileUser.setUserTypeId(theSpeaker.getSpeakerId().intValue());
          if(request.getParameter("isAdmin") !=null  && !request.getParameter("isAdmin").equals("")
        		  && !request.getParameter("isAdmin").equals("null")) {
        	  mobileUser.setIsAdmin(Integer.parseInt(request.getParameter("isAdmin")));
          }
    	  
    	  mobileUser.setUserId(request.getParameter("loginId").trim());
    	  mobileUser.setUserName(theSpeaker.getSpeakerFirstName() + " " + ((theSpeaker.getSpeakerLastName()!=null && theSpeaker.getSpeakerLastName()!="")?theSpeaker.getSpeakerLastName():""));
          mobileUser.setActiveStatus(theSpeaker.getActiveStatus());
          mobileUserRepository.save(mobileUser);
          MobileEventUsers mobileEventUsers = new MobileEventUsers();
          Optional<MobileEventUsers> optionalMobileEventUsers = mobileEventUserRepository.findByEventIdAndMobileUserId(eventMaster.getEventId(), mobileUser.getId());
          if(optionalMobileEventUsers.isPresent()) {
        	  mobileEventUsers = optionalMobileEventUsers.get();
          }
          mobileEventUsers.setEventId(eventMaster.getEventId());
          mobileEventUsers.setMobileUserId(mobileUser.getId());
          mobileEventUserRepository.save(mobileEventUsers);
          
          if(mobileUser.getIsAdmin() ==  1) {
          	 Optional<EventAdmin> optionEventAdmin =  eventAdminRepository.findAllByEventIdAndMail(eventMaster.getEventId(), theSpeaker.getSpeakerEmailId());
          	 if(optionEventAdmin.isPresent()) {
          		 eventAdmin =  optionEventAdmin.get();
          	 }
          	 eventAdmin.setAdminEmailId(theSpeaker.getSpeakerEmailId());
          	 eventAdmin.setAdminContactAddress(theSpeaker.getSpeakerMobileNo());
          	 eventAdmin.setAdminFullName(theSpeaker.getSpeakerFirstName() + " " + ((theSpeaker.getSpeakerLastName()!=null && theSpeaker.getSpeakerLastName()!="")?theSpeaker.getSpeakerLastName():""));
          	 eventAdmin.setEventAdmin(eventMaster);
          	 eventAdminRepository.save(eventAdmin);
 	      }else {
 	    	 Optional<EventAdmin> optionEventAdmin =  eventAdminRepository.findAllByEventIdAndMail(eventMaster.getEventId(), theSpeaker.getSpeakerEmailId());
          	 if(optionEventAdmin.isPresent()) {
          		 eventAdmin =  optionEventAdmin.get();
          	 }
          	 eventAdminRepository.delete(eventAdmin);
 	      }
      }
      
        
  	  return theSpeaker;
  	}

}
