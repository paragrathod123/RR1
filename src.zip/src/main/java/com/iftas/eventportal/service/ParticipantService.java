package com.iftas.eventportal.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.apache.poi.ss.usermodel.PictureData;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFPicture;
import org.apache.poi.xssf.usermodel.XSSFShape;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.iftas.eventportal.dao.CentreRepository;
import com.iftas.eventportal.dao.DepartmentRepository;
import com.iftas.eventportal.dao.DesignationRepository;
import com.iftas.eventportal.dao.EventAdminRepository;
import com.iftas.eventportal.dao.EventMasterRepository;
import com.iftas.eventportal.dao.EventParticipantRepository;
import com.iftas.eventportal.dao.MobileEventUserRepository;
import com.iftas.eventportal.dao.MobileUserRepository;
import com.iftas.eventportal.dao.OrganizationRepository;
import com.iftas.eventportal.dao.ParticipantRepository;
import com.iftas.eventportal.entity.EventAdmin;
import com.iftas.eventportal.entity.EventMaster;
import com.iftas.eventportal.entity.EventParticipants;
import com.iftas.eventportal.entity.EventSpeakers;
import com.iftas.eventportal.entity.MobileEventUsers;
import com.iftas.eventportal.entity.MobileUsers;
import com.iftas.eventportal.entity.ParticipantMaster;
import com.iftas.eventportal.utils.DataRow;
import com.iftas.eventportal.utils.DataTable;
import com.iftas.eventportal.utils.ExcelTable;

@Service
@Transactional
public class ParticipantService {

	@Autowired
	private ParticipantRepository participantRepository;
	
	@Autowired
	private OrganizationRepository organizationRepository;
	
	@Autowired
	private CentreRepository centreRepository;
	
	@Autowired
	private DepartmentRepository departmentRepository;
	
	@Autowired
	private DesignationRepository designationRepository;
	
	@Autowired
	private EventMasterRepository eventMasterRepository;
	
	@Autowired
	private EventParticipantRepository eventParticipantRepository;
	
	@Autowired
	private MobileUserRepository mobileUserRepository;
	
	@Autowired
	private MobileEventUserRepository mobileEventUserRepository;
	
	@Autowired
	private EventAdminRepository eventAdminRepository;
	

	public List<ParticipantMaster> getParticipantList() {
		return participantRepository.findAllByOrderByParticipantFirstNameAsc();
	}
	
	public List<ParticipantMaster> getParticipantListByActiveStatus(int activeStatus) {
		return participantRepository.findAllByActiveStatus(activeStatus);
	}
	
	public ParticipantMaster getParticipantById(Long id) {
		return participantRepository.findById(id).get();	
	}
	
	
	
	public void uploadParticipants(
			MultipartFile reapExcelDataFile,
			HttpServletRequest request) throws IOException {
		
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		Map<Integer, ParticipantMaster> uploadParticipantMap =  new HashMap<Integer, ParticipantMaster>();
 		
		final String label = UUID.randomUUID().toString() + ".xlsx";
	    final String filepath1 = filePath+"temp/" + label;
	    byte[] bytes = reapExcelDataFile.getBytes();
	    File fh = new File(filePath+"temp/");
	    if(!fh.exists()){
	         fh.mkdir();
	    }
	    //SpeakerUploadDTO speakerUpload = new SpeakerUploadDTO();
	    try {
	    	
	    	
	    	  FileOutputStream writer = new FileOutputStream(filepath1);
	          writer.write(bytes);
	          writer.close();
	          FileInputStream inputStream = new FileInputStream(filepath1);
	          
	          //For Sheet 0
	          DataTable table = ExcelTable.load(() -> inputStream,0);
	          int rowCount = table.rowCount();
	          for(int i=0; i < rowCount; ++i) {
	             DataRow row = table.row(i);
	             
	             String Title = row.cell("Title");
	             String FirstName = row.cell("FirstName");
	             String LastName = row.cell("LastName");
	             String Organization = row.cell("Organization");
	             String Center = row.cell("Center");
	             String Department = row.cell("Department");
	             String Designation = row.cell("Designation");
	             String EmailId = row.cell("EmailId");
	             String MobileNo = row.cell("MobileNo");
	             
	             if(EmailId!="" && !EmailId.equals("") && !EmailId.equals("null") ) { 
		             ParticipantMaster participantMaster = new ParticipantMaster();
		             participantMaster.setTitle(Title);
		             participantMaster.setParticipantFirstName(FirstName);
		             participantMaster.setParticipantLastName(LastName);
		             
		             if(organizationRepository.findByOrganizationNameIgnoreCase(Organization).isPresent()) {
		            	 participantMaster.setParticipantOrganization(organizationRepository.findByOrganizationNameIgnoreCase(Organization).get());
		             }
		             
		             if(centreRepository.findByCentreName(Center).isPresent()) {
		            	 participantMaster.setParticipantCenter(centreRepository.findByCentreName(Center).get());
		             }
		             
		             if(departmentRepository.findByDepartmentNameIgnoreCase(Department).isPresent()) {
		            	 participantMaster.setParticipantDepartment(departmentRepository.findByDepartmentNameIgnoreCase(Department).get());
		             }
		             
		             if(designationRepository.findByDesignationNameIgnoreCase(Designation).isPresent()) {
		            	 participantMaster.setParticipantDesignation(designationRepository.findByDesignationNameIgnoreCase(Designation).get());
		             }
		             
		             participantMaster.setParticipantEmailId(EmailId);
		             participantMaster.setParticipantMobileNo(MobileNo);
		             participantMaster.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
		             participantMaster.setCreatedDate(Instant.now());
		             participantMaster.setModifiedBy(0);
		             uploadParticipantMap.put(i+1, participantMaster);
	             }
	          }
	          
	          
	          
	          //Below Part for Storing Image
	          //Below for getting image 
	          FileInputStream inputStream1 = new FileInputStream(filepath1);
	          XSSFWorkbook  wb = new XSSFWorkbook(inputStream1);
	          XSSFSheet sheet = wb.getSheetAt(0);
	          XSSFDrawing xssDrawing = sheet.getDrawingPatriarch();
	          List<XSSFShape> shapes = xssDrawing.getShapes();
	          int shapeCount=0; //skiping first
	          for (XSSFShape shape : shapes) {
	             
	              if (shape instanceof XSSFPicture) {
	                 
	                 
	                  XSSFPicture hssfPicture = (XSSFPicture) shape;
	                  int rowIndex = hssfPicture.getClientAnchor().getRow1();
	                  
	                  
	                  //For Filename get
	                  final String fileName = UUID.randomUUID().toString() +".jpg";
	                  //Set File Name & Folder Name
	                  final String folderPath =   "Participants" +"/" +"profile_pic";
	                  final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
	                  
	                  
	                  
	                  System.out.println(fileName);
	                  System.out.println(folderPath);
	                  System.out.println(fileImagePath);
	                  System.out.println(rowIndex);
	                  
	                  PictureData data = hssfPicture.getPictureData();
	                  byte [] picData = data.getData();
	                  FileOutputStream fos = new FileOutputStream(new File(fileImagePath));
	                  fos.write(picData);
	                  fos.close();
	                 
	                 
	                  int colIndex = hssfPicture.getClientAnchor().getCol1();
	                  System.out.println("Picture  is located row: " + rowIndex+ ", col: " + colIndex);
	                  
	                  //Get Map Value 
	                  if(uploadParticipantMap.get(rowIndex)!=null) {
		                  ParticipantMaster participant =  uploadParticipantMap.get(rowIndex);
		                  participant.setParticipantFileName(fileName);
		                  participant.setParticipantFolderName(folderPath);
		                  uploadParticipantMap.put(rowIndex, participant);
	                  }
	              }
	             
	              shapeCount++;
	          }
	          
	    	
	    	
	    }catch (Exception e) {
			e.printStackTrace();
		}
	    
	    //finally Data insert begin 
	    for (Map.Entry<Integer, ParticipantMaster> entry : uploadParticipantMap.entrySet()) {
	    	ParticipantMaster participant =  entry.getValue();
	    	participantRepository.save(participant);
	    }
    	
	}
	
	
       public ParticipantMaster creatParticipant(ParticipantMaster theParticipant,MultipartFile reapExcelDataFile, HttpServletRequest request) {
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		
		
		Long organizationId =  Long.valueOf(request.getParameter("organizationId"));
		Long centreId = Long.valueOf(request.getParameter("centreId"));
		Long departmentId = Long.valueOf(request.getParameter("departmentId"));
		Long designationId = Long.valueOf(request.getParameter("designationId"));
		
		
		if(organizationRepository.findById(organizationId).isPresent()) {
			theParticipant.setParticipantOrganization(organizationRepository.findById(organizationId).get());
        }
        
        if(centreRepository.findById(centreId).isPresent()) {
        	theParticipant.setParticipantCenter(centreRepository.findById(centreId).get());
        }
        
        if(departmentRepository.findById(departmentId).isPresent()) {
        	theParticipant.setParticipantDepartment(departmentRepository.findById(departmentId).get());
        }
        
        if(designationRepository.findById(designationId).isPresent()) {
        	theParticipant.setParticipantDesignation(designationRepository.findById(designationId).get());
        }
		
        
        if(!reapExcelDataFile.isEmpty()) {
        	final String fileName = UUID.randomUUID().toString() + ".jpg";
        	final String folderPath =   "Participants" +"/" +"profile_pic";
            final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
            
            byte[] bytes;
			try {
				 bytes = reapExcelDataFile.getBytes();
				 FileOutputStream writer = new FileOutputStream(fileImagePath);
	              writer.write(bytes);
	              writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			theParticipant.setParticipantFileName(fileName);
			theParticipant.setParticipantFolderName(folderPath);
        }
        
        
      //Setting Created By  //Let Say Default
      theParticipant.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
	  //Setting Created Date
      theParticipant.setCreatedDate(Instant.now());
     
      participantRepository.save(theParticipant);
	  return theParticipant;
	}

	public void updateParticipant(@Valid ParticipantMaster theParticipant, HttpServletRequest request,
			MultipartFile imageDataFile) {
		
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		
		Long organizationId =  Long.valueOf(request.getParameter("organizationId"));
		Long centreId = Long.valueOf(request.getParameter("centreId"));
		Long departmentId = Long.valueOf(request.getParameter("departmentId"));
		Long designationId = Long.valueOf(request.getParameter("designationId"));
		
		
		if(organizationRepository.findById(organizationId).isPresent()) {
			theParticipant.setParticipantOrganization(organizationRepository.findById(organizationId).get());
        }
        
        if(centreRepository.findById(centreId).isPresent()) {
        	theParticipant.setParticipantCenter(centreRepository.findById(centreId).get());
        }
        
        if(departmentRepository.findById(departmentId).isPresent()) {
        	theParticipant.setParticipantDepartment(departmentRepository.findById(departmentId).get());
        }
        
        if(designationRepository.findById(designationId).isPresent()) {
        	theParticipant.setParticipantDesignation(designationRepository.findById(departmentId).get());
        }
        
        theParticipant.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
        theParticipant.setModifiedDate(Instant.now());
		
        ParticipantMaster participantTemp =  getParticipantById(theParticipant.getParticipantId());
        theParticipant.setCreatedBy(participantTemp.getCreatedBy());
        theParticipant.setCreatedDate(participantTemp.getCreatedDate());
        
        if(!imageDataFile.isEmpty()) {
        	final String fileName = UUID.randomUUID().toString() + ".jpg";
        	final String folderPath =   "Participants" +"/" +"profile_pic";
            final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
            
            byte[] bytes;
			try {
				 bytes = imageDataFile.getBytes();
				 FileOutputStream writer = new FileOutputStream(fileImagePath);
	              writer.write(bytes);
	              writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			theParticipant.setParticipantFileName(fileName);
			theParticipant.setParticipantFolderName(folderPath);
        }
		
		if(theParticipant.getParticipantFileName() == null || theParticipant.getParticipantFileName() == "") {
			//This for setting default Image 
			theParticipant.setParticipantFileName("avatar.png");
			theParticipant.setParticipantFolderName("default");
		}
		participantRepository.save(theParticipant);
	}
	
	
	
      public ParticipantMaster createEventParticipant(ParticipantMaster theParticipant,MultipartFile reapExcelDataFile, HttpServletRequest request) {
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		
		
		Long organizationId =  Long.valueOf(request.getParameter("organizationId"));
		Long centreId = Long.valueOf(request.getParameter("centreId"));
		Long departmentId = Long.valueOf(request.getParameter("departmentId"));
		Long designationId = Long.valueOf(request.getParameter("designationId"));
		
		
		if(organizationRepository.findById(organizationId).isPresent()) {
			theParticipant.setParticipantOrganization(organizationRepository.findById(organizationId).get());
        }
        
        if(centreRepository.findById(centreId).isPresent()) {
        	theParticipant.setParticipantCenter(centreRepository.findById(centreId).get());
        }
        
        if(departmentRepository.findById(departmentId).isPresent()) {
        	theParticipant.setParticipantDepartment(departmentRepository.findById(departmentId).get());
        }
        
        if(designationRepository.findById(designationId).isPresent()) {
        	theParticipant.setParticipantDesignation(designationRepository.findById(designationId).get());
        }
		
        
        if(!reapExcelDataFile.isEmpty()) {
        	final String fileName = UUID.randomUUID().toString() + ".jpg";
        	final String folderPath =   "Participants" +"/" +"profile_pic";
            final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
            
            byte[] bytes;
			try {
				 bytes = reapExcelDataFile.getBytes();
				 FileOutputStream writer = new FileOutputStream(fileImagePath);
	              writer.write(bytes);
	              writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			theParticipant.setParticipantFileName(fileName);
			theParticipant.setParticipantFolderName(folderPath);
        }else {
        	//This for setting default Image 
        	theParticipant.setParticipantFileName("avatar.png");
        	theParticipant.setParticipantFolderName("default");
        }
        
        
      //Setting Created By  //Let Say Default
      theParticipant.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
	  //Setting Created Date
      theParticipant.setCreatedDate(Instant.now());
     
      participantRepository.save(theParticipant);
      
      
      EventMaster eventMaster = new EventMaster();
      EventParticipants eventParticipant = new EventParticipants();
      //Below Code for Mapping Event Speaker and Other Related Data 
      if(request.getParameter("eventId") !=null  && !request.getParameter("eventId").equals("")
    		  && !request.getParameter("eventId").equals("null")) {
    	  Optional<EventMaster> eventOptionalMaster = eventMasterRepository.findById(Long.valueOf(request.getParameter("eventId")));
    	  if(eventOptionalMaster.isPresent()) {
    		  eventMaster = eventOptionalMaster.get();
    	  }
      }
      
      if(request.getParameter("speakerRoomNo") !=null  && !request.getParameter("speakerRoomNo").equals("")
    		  && !request.getParameter("speakerRoomNo").equals("null")) {
    	  eventParticipant.setRoomNo(request.getParameter("speakerRoomNo"));
      }
      if(request.getParameter("speakerEmergencyContactNo") !=null  && !request.getParameter("speakerEmergencyContactNo").equals("")
    		  && !request.getParameter("speakerEmergencyContactNo").equals("null")) {
    	  eventParticipant.setEmergencyContactNo(request.getParameter("speakerEmergencyContactNo"));
      }
      if(request.getParameter("speakerAllergies") !=null  && !request.getParameter("speakerAllergies").equals("")
    		  && !request.getParameter("speakerAllergies").equals("null")) {
    	  eventParticipant.setAllergies(request.getParameter("speakerAllergies"));
      }
      if(request.getParameter("speakerDriverName") !=null  && !request.getParameter("speakerDriverName").equals("")
    		  && !request.getParameter("speakerDriverName").equals("null")) {
    	  eventParticipant.setDriverName(request.getParameter("speakerDriverName"));
      }
      if(request.getParameter("speakerDriverPhoneNo") !=null  && !request.getParameter("speakerDriverPhoneNo").equals("")
    		  && !request.getParameter("speakerDriverPhoneNo").equals("null")) {
    	  eventParticipant.setDriverContactNo(request.getParameter("speakerDriverPhoneNo"));
      }
      if(request.getParameter("speakerDriverCabNo") !=null  && !request.getParameter("speakerDriverCabNo").equals("")
    		  && !request.getParameter("speakerDriverCabNo").equals("null")) {
    	  eventParticipant.setDriverCabNo(request.getParameter("speakerDriverCabNo"));
      }
      if(eventMaster!=null) {
    	  eventParticipant.setEventParticipants(eventMaster);
    	  eventParticipant.setEventParticipant(theParticipant);
    	  eventParticipantRepository.save(eventParticipant);
      }
      
      
      if(request.getParameter("loginId") !=null  && !request.getParameter("loginId").equals("")
    		  && !request.getParameter("loginId").equals("null")) {
    	  
    	  //Finally Enter Record Inside Mobile_User Table & Mobile User Event Table 
          MobileUsers mobileUser = new MobileUsers();
          EventAdmin eventAdmin = new EventAdmin();
          Optional<MobileUsers> optionalMobileUser = mobileUserRepository.findOneByUserIdIgnoreCase(request.getParameter("loginId").trim());
          if(optionalMobileUser.isPresent()) {
        	  mobileUser = optionalMobileUser.get();
          }
          if(theParticipant.getParticipantMobileNo() !=null) {
        	  mobileUser.setUserMobileNo("91"+theParticipant.getParticipantMobileNo());
          }
          //mobileUser.setUserType(1);
          //mobileUser.setUserTypeId(theParticipant.getParticipantId().intValue());
          if(request.getParameter("isAdmin") !=null  && !request.getParameter("isAdmin").equals("")
        		  && !request.getParameter("isAdmin").equals("null")) {
        	  mobileUser.setIsAdmin(Integer.parseInt(request.getParameter("isAdmin")));
          }
    	  mobileUser.setUserId(request.getParameter("loginId").trim());
    	  mobileUser.setEmail_id(theParticipant.getParticipantEmailId());
    	  mobileUser.setUserName(theParticipant.getParticipantFirstName() + " " + ((theParticipant.getParticipantLastName()!=null && theParticipant.getParticipantLastName()!="")?theParticipant.getParticipantLastName():""));
          mobileUser.setActiveStatus(theParticipant.getActiveStatus());
          mobileUserRepository.save(mobileUser);
          MobileEventUsers mobileEventUsers = new MobileEventUsers();
          mobileEventUsers.setEventId(eventMaster.getEventId());
          mobileEventUsers.setMobileUserId(mobileUser.getId());
          mobileEventUserRepository.save(mobileEventUsers);
          
          
          if(mobileUser.getIsAdmin() ==  1) {
         	 Optional<EventAdmin> optionEventAdmin =  eventAdminRepository.findAllByEventIdAndMail(eventMaster.getEventId(), theParticipant.getParticipantEmailId());
         	 if(optionEventAdmin.isPresent()) {
         		 eventAdmin =  optionEventAdmin.get();
         	 }
         	 eventAdmin.setAdminEmailId(theParticipant.getParticipantEmailId());
         	 eventAdmin.setAdminContactAddress(theParticipant.getParticipantMobileNo());
         	 eventAdmin.setAdminFullName(theParticipant.getParticipantFirstName() + " " + ((theParticipant.getParticipantLastName()!=null && theParticipant.getParticipantLastName()!="")?theParticipant.getParticipantLastName():""));
         	 eventAdmin.setEventAdmin(eventMaster);
         	 eventAdminRepository.save(eventAdmin);
	       }
          
          
      }
     
      
	  return theParticipant;
	}
      
      
      public void updateEventParticipant(@Valid ParticipantMaster theParticipant, HttpServletRequest request,
  			MultipartFile imageDataFile) {
  		
  		
  		HttpSession session =  request.getSession();
  		String filePath = (String)session.getAttribute("pathUrl");
  		
  		Long organizationId =  Long.valueOf(request.getParameter("organizationId"));
  		Long centreId = Long.valueOf(request.getParameter("centreId"));
  		Long departmentId = Long.valueOf(request.getParameter("departmentId"));
  		Long designationId = Long.valueOf(request.getParameter("designationId"));
  		
  		
  		if(organizationRepository.findById(organizationId).isPresent()) {
  			theParticipant.setParticipantOrganization(organizationRepository.findById(organizationId).get());
          }
          
          if(centreRepository.findById(centreId).isPresent()) {
          	theParticipant.setParticipantCenter(centreRepository.findById(centreId).get());
          }
          
          if(departmentRepository.findById(departmentId).isPresent()) {
          	theParticipant.setParticipantDepartment(departmentRepository.findById(departmentId).get());
          }
          
          if(designationRepository.findById(designationId).isPresent()) {
          	theParticipant.setParticipantDesignation(designationRepository.findById(designationId).get());
          }
          
          theParticipant.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
          theParticipant.setModifiedDate(Instant.now());
  		
          ParticipantMaster participantTemp =  getParticipantById(theParticipant.getParticipantId());
          theParticipant.setCreatedBy(participantTemp.getCreatedBy());
          theParticipant.setCreatedDate(participantTemp.getCreatedDate());
          
          if(!imageDataFile.isEmpty()) {
          	final String fileName = UUID.randomUUID().toString() + ".jpg";
          	final String folderPath =   "Participants" +"/" +"profile_pic";
              final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
              
              byte[] bytes;
  			try {
  				 bytes = imageDataFile.getBytes();
  				 FileOutputStream writer = new FileOutputStream(fileImagePath);
  	              writer.write(bytes);
  	              writer.close();
  			} catch (IOException e) {
  				// TODO Auto-generated catch block
  				e.printStackTrace();
  			}
  			
  			theParticipant.setParticipantFileName(fileName);
  			theParticipant.setParticipantFolderName(folderPath);
          }
  		
  		if(theParticipant.getParticipantFileName() == null || theParticipant.getParticipantFileName() == "") {
  			//This for setting default Image 
  			theParticipant.setParticipantFileName("avatar.png");
  			theParticipant.setParticipantFolderName("default");
  		}
  		participantRepository.save(theParticipant);
  		
  		
  		EventMaster eventMaster = new EventMaster();
        EventParticipants eventParticipant = new EventParticipants();
        //Below Code for Mapping Event Speaker and Other Related Data 
        if(request.getParameter("eventId") !=null  && !request.getParameter("eventId").equals("")
      		  && !request.getParameter("eventId").equals("null")) {
        	  //Getting Data from event Speaker & event Id
        	  Optional<EventMaster> eventOptionalMaster = eventMasterRepository.findById(Long.valueOf(request.getParameter("eventId")));
	      	  if(eventOptionalMaster.isPresent()) {
	      		  eventMaster = eventOptionalMaster.get();
	      	  }
    		  Optional<EventParticipants> optionalEventParticipant = eventParticipantRepository.findByParticipantAndEventId(eventMaster.getEventId(), theParticipant.getParticipantId());
	    	  if(optionalEventParticipant.isPresent()) {
	    		  eventParticipant = optionalEventParticipant.get();
	    	  }else {
	    		  eventParticipant.setEventParticipants(eventMaster);
	    	  }
        }
        
        if(request.getParameter("speakerRoomNo") !=null  && !request.getParameter("speakerRoomNo").equals("")
      		  && !request.getParameter("speakerRoomNo").equals("null")) {
        	eventParticipant.setRoomNo(request.getParameter("speakerRoomNo"));
        }
        if(request.getParameter("speakerEmergencyContactNo") !=null  && !request.getParameter("speakerEmergencyContactNo").equals("")
      		  && !request.getParameter("speakerEmergencyContactNo").equals("null")) {
        	eventParticipant.setEmergencyContactNo(request.getParameter("speakerEmergencyContactNo"));
        }
        if(request.getParameter("speakerAllergies") !=null  && !request.getParameter("speakerAllergies").equals("")
      		  && !request.getParameter("speakerAllergies").equals("null")) {
        	eventParticipant.setAllergies(request.getParameter("speakerAllergies"));
        }
        if(request.getParameter("speakerDriverName") !=null  && !request.getParameter("speakerDriverName").equals("")
      		  && !request.getParameter("speakerDriverName").equals("null")) {
        	eventParticipant.setDriverName(request.getParameter("speakerDriverName"));
        }
        if(request.getParameter("speakerDriverPhoneNo") !=null  && !request.getParameter("speakerDriverPhoneNo").equals("")
      		  && !request.getParameter("speakerDriverPhoneNo").equals("null")) {
        	eventParticipant.setDriverContactNo(request.getParameter("speakerDriverPhoneNo"));
        }
        if(request.getParameter("speakerDriverCabNo") !=null  && !request.getParameter("speakerDriverCabNo").equals("")
      		  && !request.getParameter("speakerDriverCabNo").equals("null")) {
        	eventParticipant.setDriverCabNo(request.getParameter("speakerDriverCabNo"));
        }
          
        eventParticipant.setEventParticipant(theParticipant);
      	eventParticipantRepository.save(eventParticipant);
      	
      	
        
        if(request.getParameter("loginId") !=null  && !request.getParameter("loginId").equals("")
      		  && !request.getParameter("loginId").equals("null")) {
        	
            //Finally Enter Record Inside Mobile_User Table & Mobile User Event Table 
	        MobileUsers mobileUser = new MobileUsers();	
	        EventAdmin eventAdmin = new EventAdmin();
	        Optional<MobileUsers> optionalMobileUser = mobileUserRepository.findOneByUserIdIgnoreCase(request.getParameter("loginId"));
	        if(optionalMobileUser.isPresent()) {
	      	  mobileUser = optionalMobileUser.get();
	        }
	        if(theParticipant.getParticipantMobileNo() !=null) {
	      	  mobileUser.setUserMobileNo("91"+theParticipant.getParticipantMobileNo());
	        }
	        //mobileUser.setUserType(1);
	        //mobileUser.setUserTypeId(theParticipant.getParticipantId().intValue());
	        if(request.getParameter("isAdmin") !=null  && !request.getParameter("isAdmin").equals("")
	      		  && !request.getParameter("isAdmin").equals("null")) {
	      	  mobileUser.setIsAdmin(Integer.parseInt(request.getParameter("isAdmin")));
	        }	
	        mobileUser.setEmail_id(theParticipant.getParticipantEmailId());
      	    mobileUser.setUserId(request.getParameter("loginId").trim());
	      	mobileUser.setUserName(theParticipant.getParticipantFirstName() + " " + ((theParticipant.getParticipantLastName()!=null && theParticipant.getParticipantLastName()!="")?theParticipant.getParticipantLastName():""));
	        mobileUser.setActiveStatus(theParticipant.getActiveStatus());
	        mobileUserRepository.save(mobileUser);
	        MobileEventUsers mobileEventUsers = new MobileEventUsers();
	        Optional<MobileEventUsers> optionalMobileEventUsers = mobileEventUserRepository.findByEventIdAndMobileUserId(eventMaster.getEventId(), mobileUser.getId());
	        if(optionalMobileEventUsers.isPresent()) {
	      	  mobileEventUsers = optionalMobileEventUsers.get();
	        }
	        mobileEventUsers.setEventId(eventMaster.getEventId());
	        mobileEventUsers.setMobileUserId(mobileUser.getId());
	        mobileEventUserRepository.save(mobileEventUsers);
	        
	        
	        if(mobileUser.getIsAdmin() ==  1) {
	         	 Optional<EventAdmin> optionEventAdmin =  eventAdminRepository.findAllByEventIdAndMail(eventMaster.getEventId(), theParticipant.getParticipantEmailId());
	         	 if(optionEventAdmin.isPresent()) {
	         		 eventAdmin =  optionEventAdmin.get();
	         	 }
	         	 eventAdmin.setAdminEmailId(theParticipant.getParticipantEmailId());
	         	 eventAdmin.setAdminContactAddress(theParticipant.getParticipantMobileNo());
	         	 eventAdmin.setAdminFullName(theParticipant.getParticipantFirstName() + " " + ((theParticipant.getParticipantLastName()!=null && theParticipant.getParticipantLastName()!="")?theParticipant.getParticipantLastName():""));
	         	 eventAdmin.setEventAdmin(eventMaster);
	         	 eventAdminRepository.save(eventAdmin);
		     }else {
		    	 Optional<EventAdmin> optionEventAdmin =  eventAdminRepository.findAllByEventIdAndMail(eventMaster.getEventId(), theParticipant.getParticipantEmailId());
	         	 if(optionEventAdmin.isPresent()) {
	         		 eventAdmin =  optionEventAdmin.get();
	         	 }
	         	eventAdminRepository.delete(eventAdmin);
		     }
        }
        
  	}
      
      
      
      
      
      
      public void uploadEventParticipants(
  			MultipartFile reapExcelDataFile,
  			HttpServletRequest request) throws IOException {
  		
  		
  		HttpSession session =  request.getSession();
  		String filePath = (String)session.getAttribute("pathUrl");
  		Map<Integer, ParticipantMaster> uploadParticipantMap =  new HashMap<Integer, ParticipantMaster>();
   		
  		final String label = UUID.randomUUID().toString() + ".xlsx";
  	    final String filepath1 = filePath+"temp/" + label;
  	    byte[] bytes = reapExcelDataFile.getBytes();
  	    File fh = new File(filePath+"temp/");
  	    if(!fh.exists()){
  	         fh.mkdir();
  	    }
  	 
  	    try {
  	    	
  	    	EventMaster eventMaster = new EventMaster();
	        //Below Code for Mapping Event Speaker and Other Related Data 
	        if(request.getParameter("eventId") !=null  && !request.getParameter("eventId").equals("")
	      		  && !request.getParameter("eventId").equals("null")) {
	      	  Optional<EventMaster> eventOptionalMaster = eventMasterRepository.findById(Long.valueOf(request.getParameter("eventId")));
	      	  if(eventOptionalMaster.isPresent()) {
	      		  eventMaster = eventOptionalMaster.get();
	      	  }
	        }
	        
  	    	  FileOutputStream writer = new FileOutputStream(filepath1);
  	          writer.write(bytes);
  	          writer.close();
  	          
  	          // For Sheet 4 -- > Event Event Participant Start 
	          Map<Integer, EventParticipants> uploadEventParticipantMap =  new HashMap<Integer, EventParticipants>();
	          FileInputStream inputStream4 = new FileInputStream(filepath1);
	          DataTable table = ExcelTable.load(() -> inputStream4,0);
	          int rowCount = table.rowCount();
	          for(int i=0; i < rowCount; ++i) {
	        	  ParticipantMaster participantMaster = new ParticipantMaster();
	        	  EventParticipants eventParticipants = new EventParticipants(); 
	              DataRow row = table.row(i);
	             
	             String Title = row.cell("Title");
	             String FirstName = row.cell("FirstName");
	             String LastName = row.cell("LastName");
	             String Organization = row.cell("Organization");
	             String Center = row.cell("Center");
	             String Department = row.cell("Department");
	             String Designation = row.cell("Designation");
	             String EmailId = row.cell("EmailId");
	             String MobileNo = row.cell("MobileNo");
	             String roomNo = row.cell("Room no");
	             String emergencyContactNo = row.cell("Emergency Contact No");
	             String allergies = row.cell("Allergies");
	             String driverName = row.cell("Driver Name");
	             String driverContactNo = row.cell("Driver Contact No");
	             String driverCABNo = row.cell("Driver CAB No");
	           
	             if(EmailId!=null && !EmailId.equals("")
							&& !EmailId.equals("null")) {
	            	 Optional<ParticipantMaster> optionParticipant = participantRepository.findOneByParticipantEmailIdIgnoreCase(EmailId);
	            	 if(optionParticipant.isPresent()) {
	            		 participantMaster =  optionParticipant.get();
	            		 participantMaster.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
			             participantMaster.setModifiedDate(Instant.now());
	            	 }else {
	            		 participantMaster.setParticipantEmailId(EmailId);
	            		 participantMaster.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
			             participantMaster.setCreatedDate(Instant.now());
	            	 }
	             }
	             if(Title!=null && !Title.equals("")
							&& !Title.equals("null")) {
	            	 participantMaster.setTitle(Title);
		             
	             }
	             if(FirstName!=null && !FirstName.equals("")
							&& !FirstName.equals("null")) {
	            	 participantMaster.setParticipantFirstName(FirstName);
		            
	             }
	             if(LastName!=null && !LastName.equals("")
							&& !LastName.equals("null")) {
	            	 participantMaster.setParticipantLastName(LastName);
	             }
	             if(Organization!=null && !Organization.equals("")
							&& !Organization.equals("null")) {
	            	 if(organizationRepository.findByOrganizationNameIgnoreCase(Organization).isPresent()) {
		            	 participantMaster.setParticipantOrganization(organizationRepository.findByOrganizationNameIgnoreCase(Organization).get());
		             }
	             }
	             if(Center!=null && !Center.equals("")
							&& !Center.equals("null")) {
	            	 if(centreRepository.findByCentreName(Center).isPresent()) {
		            	 participantMaster.setParticipantCenter(centreRepository.findByCentreName(Center).get());
		             }
	             }
	             if(Department!=null && !Department.equals("")
							&& !Department.equals("null")) {
	            	 if(departmentRepository.findByDepartmentNameIgnoreCase(Department).isPresent()) {
		            	 participantMaster.setParticipantDepartment(departmentRepository.findByDepartmentNameIgnoreCase(Department).get());
		             }
	             }
	             if(Designation!=null && !Designation.equals("")
							&& !Designation.equals("null")) {
	            	 if(designationRepository.findByDesignationNameIgnoreCase(Designation).isPresent()) {
		            	 participantMaster.setParticipantDesignation(designationRepository.findByDesignationNameIgnoreCase(Designation).get());
		             }
	             }
	            
	             if(MobileNo!=null && !MobileNo.equals("")
							&& !MobileNo.equals("null")) {
	            	 participantMaster.setParticipantMobileNo(MobileNo);
	             }
	             
	             eventParticipants.setEventParticipant(participantMaster);
	             
	             if(roomNo!=null && !roomNo.equals("")
							&& !roomNo.equals("null")) {
	            	 eventParticipants.setRoomNo(roomNo);
	             }
	             if(emergencyContactNo!=null && !emergencyContactNo.equals("")
							&& !emergencyContactNo.equals("null")) {
	            	 eventParticipants.setEmergencyContactNo(emergencyContactNo);
	             }
	             if(allergies!=null && !allergies.equals("")
							&& !allergies.equals("null")) {
	            	 eventParticipants.setAllergies(allergies);
	             }
	             if(driverName!=null && !driverName.equals("")
							&& !driverName.equals("null")) {
	            	 eventParticipants.setDriverName(driverName);
	             }
	             if(driverContactNo!=null && !driverContactNo.equals("")
							&& !driverContactNo.equals("null")) {
	            	 eventParticipants.setDriverContactNo(driverContactNo);
	             }
	             if(driverCABNo!=null && !driverCABNo.equals("")
							&& !driverCABNo.equals("null")) {
	            	 eventParticipants.setDriverCabNo(driverCABNo);
	             }
	             eventParticipants.setEventParticipants(eventMaster);
	             uploadEventParticipantMap.put(i+1, eventParticipants);
	             //eventParticipantRepository.save(eventParticipants);
	          } 
	        //Below Part for Storing Image
	          //Below for getting image 
	          FileInputStream inputStream4_image = new FileInputStream(filepath1);
	          XSSFWorkbook wb = new XSSFWorkbook(inputStream4_image);
	          XSSFSheet sheet = wb.getSheetAt(0);
	          XSSFDrawing xssDrawing = sheet.getDrawingPatriarch();
	          List<XSSFShape> shapes = xssDrawing.getShapes();
	          int shapeCount=0; //skiping first
	          for (XSSFShape shape : shapes) {
	              if (shape instanceof XSSFPicture) {
	                  XSSFPicture hssfPicture = (XSSFPicture) shape;
	                  int rowIndex = hssfPicture.getClientAnchor().getRow1();
	                  //For Filename get
	                  final String fileName = UUID.randomUUID().toString() +".jpg";
	                  //Set File Name & Folder Name
	                  final String folderPath =   "Participants" +"/" +"profile_pic";
	                  final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
	                  System.out.println(fileName);
	                  System.out.println(folderPath);
	                  System.out.println(fileImagePath);
	                  System.out.println(rowIndex);
	                  PictureData data = hssfPicture.getPictureData();
	                  byte [] picData = data.getData();
	                  FileOutputStream fos = new FileOutputStream(new File(fileImagePath));
	                  fos.write(picData);
	                  fos.close();
	                  int colIndex = hssfPicture.getClientAnchor().getCol1();
	                  System.out.println("Picture  is located row: " + rowIndex+ ", col: " + colIndex);
	                  //Get Map Value 
	                  if(uploadEventParticipantMap.get(rowIndex)!=null) {
	                	  EventParticipants eventParticipants  =  uploadEventParticipantMap.get(rowIndex);
		                  ParticipantMaster participant =  eventParticipants.getEventParticipant();
		                  participant.setParticipantFileName(fileName);
		                  participant.setParticipantFolderName(folderPath);
		                  eventParticipants.setEventParticipant(participant);
		                  uploadEventParticipantMap.put(rowIndex, eventParticipants);
	                  }
	              }
	             
	              shapeCount++;
	          }
	        //finally Data insert begin 
	  	    for (Map.Entry<Integer, EventParticipants> entry : uploadEventParticipantMap.entrySet()) {
	  	    	EventParticipants eventParticipant = entry.getValue();
	  	    	ParticipantMaster participant =  eventParticipant.getEventParticipant();
	  	    	participantRepository.save(participant);
	  	    	eventParticipantRepository.save(eventParticipant);
	  	    }  
	          
	        //For Sheet 0 -- > Event Event Participant Ends  
  	          
  	          
  	          
  	    	
  	    	
  	    }catch (Exception e) {
  			e.printStackTrace();
  		}
  	    
  	    
  	}
	
	
	
}
