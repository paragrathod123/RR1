package com.iftas.eventportal.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iftas.eventportal.dao.EventSpeakerRepository;
import com.iftas.eventportal.entity.EventSpeakers;

@Service
@Transactional
public class EventSpeakerService {

	@Autowired
	private EventSpeakerRepository eventSpeakerRepository;

	public EventSpeakers getSpeakerListByEventId(Long id) {
		Optional<EventSpeakers> result =  eventSpeakerRepository.findByEventSpeakers(id);
		EventSpeakers speakerData = null;
		if(result.isPresent()) {
			speakerData = result.get();
		}
		return speakerData;
	}
	
	
}
	
	
	
	

