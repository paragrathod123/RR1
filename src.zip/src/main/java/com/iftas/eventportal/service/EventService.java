package com.iftas.eventportal.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.iftas.eventportal.dao.CentreRepository;
import com.iftas.eventportal.dao.DepartmentRepository;
import com.iftas.eventportal.dao.DesignationRepository;
import com.iftas.eventportal.dao.EventAdminRepository;
import com.iftas.eventportal.dao.EventConferenceInformationRepository;
import com.iftas.eventportal.dao.EventGalleryRepository;
import com.iftas.eventportal.dao.EventMasterRepository;
import com.iftas.eventportal.dao.EventParticipantRepository;
import com.iftas.eventportal.dao.EventRelavantReading;
import com.iftas.eventportal.dao.EventSessionRepository;
import com.iftas.eventportal.dao.EventSpeakerRepository;
import com.iftas.eventportal.dao.EventTransportaionRepository;
import com.iftas.eventportal.dao.MobileEventUserRepository;
import com.iftas.eventportal.dao.MobileUserRepository;
import com.iftas.eventportal.dao.OrganizationRepository;
import com.iftas.eventportal.dao.ParticipantRepository;
import com.iftas.eventportal.dao.ProductMasterRepository;
import com.iftas.eventportal.dao.SpeakersRepository;
import com.iftas.eventportal.dto.eventDTO;
import com.iftas.eventportal.entity.Department;
import com.iftas.eventportal.entity.Designation;
import com.iftas.eventportal.entity.EventAdmin;
import com.iftas.eventportal.entity.EventConferenceInformation;
import com.iftas.eventportal.entity.EventGallery;
import com.iftas.eventportal.entity.EventMaster;
import com.iftas.eventportal.entity.EventParticipants;
import com.iftas.eventportal.entity.EventSessionRef;
import com.iftas.eventportal.entity.EventSpeakers;
import com.iftas.eventportal.entity.EventTransportaion;
import com.iftas.eventportal.entity.MobileEventUsers;
import com.iftas.eventportal.entity.MobileUsers;
import com.iftas.eventportal.entity.ParticipantMaster;
import com.iftas.eventportal.entity.ProductMaster;
import com.iftas.eventportal.entity.RelavantReading;
import com.iftas.eventportal.entity.SpeakerMaster;
import com.iftas.eventportal.util.RandomUtil;
import com.iftas.eventportal.utils.DataRow;
import com.iftas.eventportal.utils.DataTable;
import com.iftas.eventportal.utils.ExcelTable;

import org.apache.poi.ss.usermodel.PictureData;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFPicture;
import org.apache.poi.xssf.usermodel.XSSFShape;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

@Service
@Transactional
public class EventService {

	@Autowired
	private DepartmentRepository depmartmentRepo;
	
	@Autowired
	private EventMasterRepository eventMasterRepository;
	
	@Autowired
	private EventConferenceInformationRepository eventConferenceInformationRepository;
	
	@Autowired
	private EventSpeakerRepository eventSpeakerRepository;
	
	@Autowired
	private  EventParticipantRepository eventParticipantRepository;
	
	@Autowired
	private ProductMasterRepository productRepo;
	
	@Autowired
	private EventAdminRepository eventAdminRepository;
	
	@Autowired
	private SpeakersRepository speakersRepository;
	
	@Autowired
	private ParticipantRepository participantRepository;
	
	@Autowired
	private EventSessionRepository eventSessionRepository;
	
	@Autowired
	private EventTransportaionRepository eventTransportaionRepository;
	
	@Autowired
	private EventRelavantReading eventRelavantReading;
	
	@Autowired
	private OrganizationRepository organizationRepository;
	
	@Autowired
	private CentreRepository centreRepository;
	
	@Autowired
	private EventGalleryRepository eventGalleryRepository;
	
	
	@Autowired
	private DesignationRepository designationRepository;
	
	@Autowired
	private MobileUserRepository mobileUserRepository;
	
	@Autowired
	private MobileEventUserRepository mobileEventUserRepository;
	
	
	public EventMaster addEventDetails(@Valid eventDTO theEventDetails, HttpServletRequest request) {
		System.out.println("In ADDEvent Service :: START");
		boolean eventDataStatus = false;
		EventMaster eventMaster = new EventMaster();
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		if(request != null && theEventDetails != null ) {
		
		
		//for department
		Optional<Department> departmentOpt=depmartmentRepo.findById(theEventDetails.getDepartmentId());
		if(departmentOpt.isPresent()) {
			Department department = departmentOpt.get();
			eventMaster.setEventDepartment(department);
		}
		
		
		//for event deails
		eventMaster.setEventName(theEventDetails.getEventName());
		eventMaster.setEventStartDate(theEventDetails.getEventStartDate());
		eventMaster.setEventEndDate(theEventDetails.getEventEndDate());
		eventMaster.setEventLocationPlaceName(theEventDetails.getEventPlaceName());
		eventMaster.setEventLocationInformation(theEventDetails.getEventInformation().toString());
		eventMaster.setEventVenueAddress(theEventDetails.getVenueAddress());
		eventMaster.setEventVenuePincode(theEventDetails.getVenuePinCode());
		eventMaster.setEventVenueLatittude(theEventDetails.getVenueLatitude());
		eventMaster.setEventVenueLongitude(theEventDetails.getVenueLongitude());
		
		//for product
		Optional<ProductMaster> productOpt = productRepo.findById(theEventDetails.getProductId());
		if(productOpt.isPresent()) {
			ProductMaster productMaster = productOpt.get();
			eventMaster.setEventProduct(productMaster);
		}
		
		//Below Code for Storing Session Image File Location
		MultipartFile eventLocImage  =  theEventDetails.getEventLocationImage();
		try {
			if(!eventLocImage.isEmpty()) {
	        	//final String fileName = UUID.randomUUID().toString() + ".jpg";
				final String fileName = eventLocImage.getOriginalFilename();
	        	final String folderPath =   "Session" +"/" +"event_location";
	            final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
	            byte[] bytes;
				try {
					 bytes = eventLocImage.getBytes();
					 FileOutputStream writer = new FileOutputStream(fileImagePath);
		              writer.write(bytes);
		              writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				eventMaster.setEventVenueFileName(fileName);
				eventMaster.setEventVenueFolderName(folderPath);
	        }else {
	        	//This for setting default Image 
	        	eventMaster.setEventVenueFileName("images.png");
	        	eventMaster.setEventVenueFolderName("default");
	        }
		}catch (Exception e) {
			e.printStackTrace();
		}
		eventMaster.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
		eventMaster.setCreatedDate(Instant.now());
		eventMasterRepository.save(eventMaster);
		
		//Below for Storing Transport Data 
		List<MultipartFile> transPortData = theEventDetails.getTransportFile();
		try {
			if(transPortData.size() >0) {
				int i ;
				for ( i = 0; i < transPortData.size(); i++) {
					
					MultipartFile transportFile  =  transPortData.get(i);
					if(!transportFile.isEmpty()) {
						EventTransportaion eventTransportaion = new EventTransportaion();
			        	String fileName = transportFile.getOriginalFilename();
			        	String folderPath =   "Session" +"/" +"event_transport";
			            String fileImagePath = filePath + folderPath +  "/" +  fileName ;
			            byte[] bytes;
						try {
							  bytes = transportFile.getBytes();
							  FileOutputStream writer = new FileOutputStream(fileImagePath);
				              writer.write(bytes);
				              writer.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						eventTransportaion.setTransportFileName(fileName);
						eventTransportaion.setTransportFolderName(folderPath);
						eventTransportaion.setTransportFileDescription(String.valueOf(i));
						eventTransportaion.setEventTransport(eventMaster);
						eventTransportaionRepository.save(eventTransportaion);
						
			        }
					
				}
			}
			
			
		} catch (Exception e) {
			
		}
		
		List<MultipartFile> eventGalleryData = theEventDetails.getEventImageGallery();
		System.out.println("size  "+ eventGalleryData.size());
		try {
			
			if(eventGalleryData.size() >0) {
				
				int i ;
				for ( i = 0; i < eventGalleryData.size(); i++) {
					
					MultipartFile eventGalleryFile  =  eventGalleryData.get(i);
					System.out.println("is Empty  "+ eventGalleryFile.isEmpty());
					if(!eventGalleryFile.isEmpty()) {
						
						EventGallery eventGallery = new EventGallery();
						
						String fileName = eventGalleryFile.getOriginalFilename();
			        	String folderPath =   "Session" +"/" +"event_gallery";
			            String fileImagePath = filePath + folderPath +  "/" +  fileName ;
			            byte[] bytes;
						try {
							  bytes = eventGalleryFile.getBytes();
							  FileOutputStream writer = new FileOutputStream(fileImagePath);
				              writer.write(bytes);
				              writer.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						eventGallery.setGalleryFileName(fileName);
						eventGallery.setGalleryFolderName(folderPath);
						eventGallery.setEventGallery(eventMaster);
						eventGalleryRepository.save(eventGallery);
						
					}
					
				}
				
				
				
				
			}
			
			
		}catch (Exception e) {
			System.out.println("Error occured while saving the Event Gallery "+e.getMessage());
		}
		
		 
		 eventDataStatus = true;
		}else {
			eventDataStatus = false;
		}
		
		return eventMaster;
	}

	public List<EventMaster> getEventList() {
	return eventMasterRepository.findAllByOrderByEventNameAsc();
	}
	

	public EventMaster getEventListbyId(Long id) {
		Optional<EventMaster> result =  eventMasterRepository.findById(id);
		EventMaster eventData = null;
		if(result.isPresent()) {
			eventData = result.get();
		}
		return eventData;
	}

	public boolean updateEventDetails(@Valid eventDTO theEventDetails, HttpServletRequest request) {
		System.out.println("In updateEventDetails Service :: START");
		boolean eventDataStatus = false;
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		if(request != null && theEventDetails != null ) {
		// EventMaster eventMaster = new EventMaster();
		 
		 System.out.println("event Id in Update Event "+theEventDetails.getEventId());
		 EventMaster eventMaster = getEventListbyId(theEventDetails.getEventId());
		
		//for department
		Optional<Department> departmentOpt=depmartmentRepo.findById(theEventDetails.getDepartmentId());
		if(departmentOpt.isPresent()) {
			Department department = departmentOpt.get();
			eventMaster.setEventDepartment(department);
		}
		
		
		
		//for event deails
		eventMaster.setEventName(theEventDetails.getEventName());
		eventMaster.setEventStartDate(theEventDetails.getEventStartDate());
		eventMaster.setEventEndDate(theEventDetails.getEventEndDate());
		eventMaster.setEventLocationPlaceName(theEventDetails.getEventPlaceName());
		eventMaster.setEventLocationInformation(theEventDetails.getEventInformation().toString());
		eventMaster.setEventVenueAddress(theEventDetails.getVenueAddress());
		eventMaster.setEventVenuePincode(theEventDetails.getVenuePinCode());
		eventMaster.setEventVenueLatittude(theEventDetails.getVenueLatitude());
		eventMaster.setEventVenueLongitude(theEventDetails.getVenueLongitude());
		
		//for product
		Optional<ProductMaster> productOpt = productRepo.findById(theEventDetails.getProductId());
		if(productOpt.isPresent()) {
			ProductMaster productMaster = productOpt.get();
			eventMaster.setEventProduct(productMaster);
		}
		
		//Below Code for Storing Session Image File Location
		MultipartFile eventLocImage  =  theEventDetails.getEventLocationImage();
		try {
			if(!eventLocImage.isEmpty()) {
	        	//final String fileName = UUID.randomUUID().toString() + ".jpg";
				final String fileName = eventLocImage.getOriginalFilename();
	        	final String folderPath =   "Session" +"/" +"event_location";
	            final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
	            byte[] bytes;
				try {
					 bytes = eventLocImage.getBytes();
					 FileOutputStream writer = new FileOutputStream(fileImagePath);
		              writer.write(bytes);
		              writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				eventMaster.setEventVenueFileName(fileName);
				eventMaster.setEventVenueFolderName(folderPath);
	        }else {
	        	//This for setting default Image 
	        	
	        	if(eventMaster.getEventVenueFileName()== "" || eventMaster.getEventVenueFileName() == null  ) {
	        		eventMaster.setEventVenueFileName("images.png");
	        	    eventMaster.setEventVenueFolderName("default");
	        	}
	        }
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		eventMaster.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
		eventMaster.setModifiedDate(Instant.now());
		eventMasterRepository.save(eventMaster);
		
		
		//Below for Storing Transport Data 
				List<EventTransportaion> eventTransport = eventTransportaionRepository.findAllByEventId(eventMaster.getEventId());				
				List<MultipartFile> transPortData = theEventDetails.getTransportFile();
				try {
					if(transPortData.size() >0) {
						int i ;
						for ( i = 0; i < transPortData.size(); i++) {
							
							MultipartFile transportFile  =  transPortData.get(i);
							if(!transportFile.isEmpty()) {
								EventTransportaion eventTransportaion = new EventTransportaion();
								if(!eventTransport.isEmpty()) {
									   eventTransportaion =  eventTransport.get(i);
								}
								
					        	String fileName = transportFile.getOriginalFilename();
					        	String folderPath =   "Session" +"/" +"event_transport";
					            String fileImagePath = filePath + folderPath +  "/" +  fileName ;
					            byte[] bytes;
								try {
									  bytes = transportFile.getBytes();
									  FileOutputStream writer = new FileOutputStream(fileImagePath);
						              writer.write(bytes);
						              writer.close();
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								eventTransportaion.setTransportFileName(fileName);
								eventTransportaion.setTransportFolderName(folderPath);
								eventTransportaion.setTransportFileDescription(String.valueOf(i));
								eventTransportaion.setEventTransport(eventMaster);
								eventTransportaionRepository.save(eventTransportaion);
								
								
								
					        }
							
						}
					}
					
					
					
					
					
					
					
					
				} catch (Exception e) {
					System.out.println("Error occured while saving the Trasnport files "+e.getMessage());
				}
				
				//Delete Existing Image 
				String deleteEventGalleryId =  request.getParameter("deleteEventGalleryId");
				if(deleteEventGalleryId!=null && !deleteEventGalleryId.equals("") && !deleteEventGalleryId.equals("null")) {
					
					String[] deleteEventGalleryIdArray =  deleteEventGalleryId.split(",");
					if(deleteEventGalleryIdArray.length > 0) {
						for (int j = 0; j < deleteEventGalleryIdArray.length; j++) {
							if(Integer.parseInt(deleteEventGalleryIdArray[j])!=0) {
								Optional<EventGallery> optionalEventGallery =  eventGalleryRepository.findById(Long.valueOf(deleteEventGalleryIdArray[j].trim()));
								if(optionalEventGallery.isPresent()) {
									eventGalleryRepository.deleteById(Long.valueOf(deleteEventGalleryIdArray[j].trim()));
								}
							}
						}
					}
					
				}
				
				List<MultipartFile> eventGalleryData = theEventDetails.getEventImageGallery();
				System.out.println("size  "+ eventGalleryData.size());
				try {
					
					if(eventGalleryData.size() >0) {
						
						int i ;
						for ( i = 0; i < eventGalleryData.size(); i++) {
							
							MultipartFile eventGalleryFile  =  eventGalleryData.get(i);
							System.out.println("is Empty  "+ eventGalleryFile.isEmpty());
							if(!eventGalleryFile.isEmpty()) {
								
								EventGallery eventGallery = new EventGallery();
								
								String fileName = eventGalleryFile.getOriginalFilename();
					        	String folderPath =   "Session" +"/" +"event_gallery";
					            String fileImagePath = filePath + folderPath +  "/" +  fileName ;
					            byte[] bytes;
								try {
									  bytes = eventGalleryFile.getBytes();
									  FileOutputStream writer = new FileOutputStream(fileImagePath);
						              writer.write(bytes);
						              writer.close();
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								eventGallery.setGalleryFileName(fileName);
								eventGallery.setGalleryFolderName(folderPath);
								eventGallery.setEventGallery(eventMaster);
								eventGalleryRepository.save(eventGallery);
								
							}
							
						}
						
						
						
						
					}
					
					
				}catch (Exception e) {
					System.out.println("Error occured while saving the Event Gallery "+e.getMessage());
				}
				
				
			eventDataStatus = true;
		}else {
			eventDataStatus = false;
		}
		return eventDataStatus;
	}
	
	public boolean updateConferenceEventDetails(eventDTO theEventDetails, HttpServletRequest request) {
		System.out.println("In updateEventDetails Service :: START");
		boolean eventDataStatus = false;
		
		System.out.println("dresscoed in service "+theEventDetails.getDressCode());
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		if(request != null && theEventDetails != null ) {
		
		 System.out.println("event Id in Update Event "+theEventDetails.getEventId());
		 EventMaster eventMaster = getEventListbyId(theEventDetails.getEventId());
		 
		 eventMaster.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
		 eventMaster.setModifiedDate(Instant.now());
		 eventMasterRepository.save(eventMaster);
		 
		//for update conference Information
		EventConferenceInformation eventConferenceInfo = new EventConferenceInformation();
	    eventConferenceInfo = getConferenceInfoByEventId(theEventDetails.getEventId());
		if(eventConferenceInfo != null) {
			eventConferenceInfo.setDressCode(theEventDetails.getDressCode());
			eventConferenceInfo.setRegisterationDetail(theEventDetails.getRegistrationDetail());
			eventConferenceInfo.setAttendenceTimeTable(theEventDetails.getAttendanceTimeTable());
			eventConferenceInfo.setPresentations(theEventDetails.getPresentations());
			eventConferenceInfo.setSpecialRequirements(theEventDetails.getSpecialRequirements());
			eventConferenceInfo.setTransportation(theEventDetails.getTransportation());
			eventConferenceInfo.setWelcomeMessage(theEventDetails.getWelcomeMsg());
			
			eventConferenceInfo.setEvenConferenceInfo(eventMaster);
			eventConferenceInformationRepository.save(eventConferenceInfo);
				
			
				eventDataStatus = true;
		}else {
		//for insert 	
			EventConferenceInformation eventConfData = new EventConferenceInformation();
			eventConfData.setDressCode(theEventDetails.getDressCode());
			eventConfData.setRegisterationDetail(theEventDetails.getRegistrationDetail());
			eventConfData.setAttendenceTimeTable(theEventDetails.getAttendanceTimeTable());
			eventConfData.setPresentations(theEventDetails.getPresentations());
			eventConfData.setSpecialRequirements(theEventDetails.getSpecialRequirements());
			eventConfData.setTransportation(theEventDetails.getTransportation());
			eventConfData.setWelcomeMessage(theEventDetails.getWelcomeMsg());
			eventConfData.setEvenConferenceInfo(eventMaster);
			eventConferenceInformationRepository.save(eventConfData);
			eventDataStatus = true;
			
		}
	    

		}else {
			eventDataStatus = false;
		}
		return eventDataStatus;
	}
	
	public boolean updateSessionEventDetails(@Valid eventDTO theEventDetails, HttpServletRequest request) {
		System.out.println("In updateEventDetails Service :: START");
		boolean eventDataStatus = false;
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		if(request != null && theEventDetails != null ) {
		
		 System.out.println("event Id in Update Event "+theEventDetails.getEventId());
		 EventMaster eventMaster = getEventListbyId(theEventDetails.getEventId());
		 
		 eventMaster.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
		 eventMaster.setModifiedDate(Instant.now());
		 eventMasterRepository.save(eventMaster);
		 
		 
		//Delete Existing Session 
			String deleteEventGalleryId =  request.getParameter("deleteSessionId");
			if(deleteEventGalleryId!=null && !deleteEventGalleryId.equals("") && !deleteEventGalleryId.equals("null")) {
				String[] deleteEventGalleryIdArray =  deleteEventGalleryId.split(",");
				if(deleteEventGalleryIdArray.length > 0) {
					for (int j = 0; j < deleteEventGalleryIdArray.length; j++) {
						if(Integer.parseInt(deleteEventGalleryIdArray[j])!=0) {
							Optional<EventSessionRef> optionSessionRef	=  eventSessionRepository.findById(Long.valueOf(deleteEventGalleryIdArray[j].trim()));
							if(optionSessionRef.isPresent()) {
								eventSessionRepository.deleteById(Long.valueOf(deleteEventGalleryIdArray[j].trim()));
							}
						}
					}
				}
			}
		//for session Update
			
		 int sessionCount =Integer.parseInt(request.getParameter("sessionCount"));
		 System.out.println("sessionCount   "+sessionCount);
		 List<MultipartFile> sessionReadingMaterials = theEventDetails.getReadingMaterialFile();
		 List<EventSessionRef> sessionList = new ArrayList<EventSessionRef>(); 
		 for(int i=0 ; i<=sessionCount ;i++) {
		  
		
		  System.out.println("sessionSpeakerId  "+request.getParameter("sessionSpeakerId"+i));
		  if(request.getParameter("sessionSpeakerId"+i)!=null && !request.getParameter("sessionSpeakerId"+i).equals("") && !request.getParameter("sessionSpeakerId"+i).equals("null")) {
		 
			  EventSessionRef sessionData = new EventSessionRef();
			  RelavantReading reading = new RelavantReading();
			  
			  System.out.println(request.getParameter("sessionId"+i) +" :: session Id");
			  //Below Code for Setting Update of existing record
			  if(request.getParameter("sessionId"+i)!=null 
					  && !request.getParameter("sessionId"+i).equals("")
					  				&& !request.getParameter("sessionId"+i).equals("null")) {
				  Optional<EventSessionRef> optionSessionRef	=  eventSessionRepository.findById(Long.valueOf(request.getParameter("sessionId"+i)));
				  if(optionSessionRef.isPresent()) {
					  sessionData =  optionSessionRef.get();
					  if(sessionData.getReadingMaterial()!=null) {
						  reading =  sessionData.getReadingMaterial();
					  }
					  
				  }
			  }
			  
			  Optional<SpeakerMaster> speakerOpt = speakersRepository.findById(Long.valueOf(request.getParameter("sessionSpeakerId"+i)));
				if(speakerOpt.isPresent()) {
					SpeakerMaster newSpeakerdata = new SpeakerMaster();
					newSpeakerdata = speakerOpt.get();
					sessionData.setSpeaker(newSpeakerdata);
				}
				
		  
		  try {
			  
			  if(sessionReadingMaterials.size() >0) {
				  
				  MultipartFile sessionReading  =  sessionReadingMaterials.get(i);
				  if(!sessionReading.isEmpty()) {
			        	String fileName = sessionReading.getOriginalFilename();
			        	String folderPath =   "Session" +"/" +"event_reading";
			            String fileImagePath = filePath + folderPath +  "/" +  fileName ;
			            byte[] bytes;
						try {
							 bytes = sessionReading.getBytes();
							 FileOutputStream writer = new FileOutputStream(fileImagePath);
				              writer.write(bytes);
				              writer.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						reading.setSpeakerFileName(fileName);
						reading.setSpeakerFolderName(folderPath);
						eventRelavantReading.save(reading);
						sessionData.setReadingMaterial(reading);
			        }
			  }
			
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error while Saving the File "+e.getMessage());
			}
		  
		  
		  
		  System.out.println("session name:: "+request.getParameter("sessionName"+i));
		  sessionData.setSessionName(request.getParameter("sessionName"+i));
		  sessionData.setSessionTopic(request.getParameter("sessionTopicName"+i));
		  sessionData.setSessionStartTime(request.getParameter("startTime"+i));
		  sessionData.setSessionEndTime(request.getParameter("endTime"+i));
		  sessionData.setEventDate(request.getParameter("eventDate"+i));
		  sessionData.setIsSession(request.getParameter("isSession"+i));
		  sessionData.setIsfeedback(request.getParameter("isFeedback"+i));
		  //sessionData.setReadingMaterialFile(request.getParameter( "readingMaterialFile"+i));
		  sessionData.setEventSessions(eventMaster);
		  eventSessionRepository.save(sessionData);
		  sessionList.add(sessionData);
		 
		  } 
		  }	
		 
			
		
			eventDataStatus = true;
		}else {
			eventDataStatus = false;
		}
		return eventDataStatus;
	}
	
	public boolean updateAdminEventDetails( @Valid EventAdmin eventAdmin, HttpServletRequest request) {
		System.out.println("In updateEventDetails Service :: START");
		boolean eventDataStatus = false;
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		if(request != null && eventAdmin != null ) {
		
		 //System.out.println("event Id in Update Event "+eventAdmin.getEventAdmin().getEventId()); eventId
			String eventId = request.getParameter("eventId");
			System.out.println("eventAdmin EventId "+eventId);
			
		 EventMaster eventMaster = getEventListbyId(Long.valueOf(eventId));
		 
		 eventMaster.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
		 eventMaster.setModifiedDate(Instant.now());
		 eventMasterRepository.save(eventMaster);
		 
		//Delete Existing Session 
			String deleteEventGalleryId =  request.getParameter("deleteAdminId");
			if(deleteEventGalleryId!=null && !deleteEventGalleryId.equals("") && !deleteEventGalleryId.equals("null")) {
				String[] deleteEventGalleryIdArray =  deleteEventGalleryId.split(",");
				if(deleteEventGalleryIdArray.length > 0) {
					for (int j = 0; j < deleteEventGalleryIdArray.length; j++) {
						if(Integer.parseInt(deleteEventGalleryIdArray[j])!=0) {
							Optional<EventAdmin> optionSessionRef	=  eventAdminRepository.findById(Long.valueOf(deleteEventGalleryIdArray[j].trim()));
							if(optionSessionRef.isPresent()) {
								if(optionSessionRef.get().getAdminEmailId()!=null &&  
										!optionSessionRef.get().getAdminEmailId().equals("") ) {
									 String EmailId =  optionSessionRef.get().getAdminEmailId();
									 String loginId="";
								     int index = EmailId.indexOf('@');
					            	 loginId = EmailId.substring(0,index);
					            	 MobileUsers mobileUser = new MobileUsers();
					            	 Optional<MobileUsers> optionalMobileUser = mobileUserRepository.findOneByUserIdIgnoreCase(loginId);
					                 if(optionalMobileUser.isPresent()) {
					               	    mobileUser = optionalMobileUser.get();
					               	    mobileUser.setActiveStatus(1);
					               	    mobileUserRepository.save(mobileUser);
					                 }
					                 MobileEventUsers mobileEventUsers = new MobileEventUsers();
					                 Optional<MobileEventUsers> optionalMobileEventUsers = mobileEventUserRepository.findByEventIdAndMobileUserId(eventMaster.getEventId(), mobileUser.getId());
					                 if(optionalMobileEventUsers.isPresent()) {
					               	     mobileEventUsers = optionalMobileEventUsers.get();
					               	     mobileEventUsers.setEventId(null);
					               	     mobileEventUserRepository.save(mobileEventUsers);
					                 }
								}
								eventAdminRepository.deleteById(Long.valueOf(deleteEventGalleryIdArray[j].trim()));
							}
						}
					}
				}
			}
			
		//for Admin Details
		 int adminCount = Integer.parseInt(request.getParameter("adminCount"));
		 System.out.println("adminCount   "+adminCount); 

			 List<EventAdmin> adminList =new ArrayList<EventAdmin>();
			  for(int i=0 ; i<=adminCount ; i++) {
				  
				  System.out.println("in foreach of admin");
				 if(request.getParameter("adminName"+i)!=null && !request.getParameter("adminName"+i).equals("") 
						 													&&!request.getParameter("adminName"+i).equals("null")) {
					  
					  EventAdmin adminData = new EventAdmin();
					  MobileUsers mobileUser = new MobileUsers();
					  System.out.println("adminId  "+request.getParameter("adminId"+i));
					  if(request.getParameter("adminId"+i)!=null && !request.getParameter("adminId"+i).equals("") 
							  														&& !request.getParameter("adminId"+i).equals("null")) {
						  
						  Optional<EventAdmin> optionalEventAdmin = eventAdminRepository.findById(Long.valueOf(request.getParameter("adminId"+i))) ;
						  if(optionalEventAdmin.isPresent()) {
							  adminData = optionalEventAdmin.get();
						  }
					  }
					  Optional<Designation> designationOpt = designationRepository.findById(Long.valueOf(request.getParameter("adminDesignationId"+i)));
						if(designationOpt.isPresent()) {
							Designation newDesignation = new Designation();
							newDesignation = designationOpt.get();
							adminData.setDesignation(newDesignation);
						}
					 adminData.setTitle(request.getParameter("adminTitle"+i));
					 adminData.setAdminFullName(request.getParameter("adminName"+i));
					 adminData.setAdminContactAddress(request.getParameter("adminContactNo"+i));
					 adminData.setAdminEmailId(request.getParameter("adminEmailId"+i));
					 adminData.setEventAdmin(eventMaster);
					 eventAdminRepository.save(adminData);
					 
					 //Below Code For adding Admin into Mobile User begins here 
					 if(request.getParameter("adminEmailId"+i)!=null 
							 				&& !request.getParameter("adminEmailId"+i).equals("")
							 							&& !request.getParameter("adminEmailId"+i).equals("null")) {
						 String EmailId =  request.getParameter("adminEmailId"+i);
						 if(RandomUtil.isEmailValid(EmailId)) {
							 
							     String loginId="";
							     int index = EmailId.indexOf('@');
				            	 loginId = EmailId.substring(0,index);
				            	 Optional<MobileUsers> optionalMobileUser = mobileUserRepository.findOneByUserIdIgnoreCase(loginId);
				                 if(optionalMobileUser.isPresent()) {
				               	  mobileUser = optionalMobileUser.get();
				                 }
				                 //Add Condition to check by User Id 
				                 if(request.getParameter("adminContactNo"+i) !=null) {
				               	  	mobileUser.setUserMobileNo("91"+request.getParameter("adminContactNo"+i));
				                 }
				                 mobileUser.setEmail_id(EmailId);
				                 mobileUser.setIsAdmin(1);
				                 mobileUser.setUserName(request.getParameter("adminName"+i));
				                 mobileUser.setActiveStatus(0);
				                 mobileUserRepository.save(mobileUser);
				                 mobileUser.setUserId(loginId);
				                 MobileEventUsers mobileEventUsers = new MobileEventUsers();
				                 Optional<MobileEventUsers> optionalMobileEventUsers = mobileEventUserRepository.findByEventIdAndMobileUserId(eventMaster.getEventId(), mobileUser.getId());
				                 if(optionalMobileEventUsers.isPresent()) {
				               	  mobileEventUsers = optionalMobileEventUsers.get();
				                 }
				                 mobileEventUsers.setEventId(eventMaster.getEventId());
				                 mobileEventUsers.setMobileUserId(mobileUser.getId());
				                 mobileEventUserRepository.save(mobileEventUsers);
				                 
				                 
						 }
						 
					 }
					 
					 adminList.add(adminData); 
				 } 
			  
			 }
		
		
			eventDataStatus = true;
		}else {
			eventDataStatus = false;
		}
		return eventDataStatus;
	}

	private EventConferenceInformation getConferenceInfoByEventId(Long eventId) {
		System.out.println("eventId "+eventId);
		Optional<EventConferenceInformation> result =  eventConferenceInformationRepository.evenConferenceInfobyEventId(eventId);

		EventConferenceInformation eventConferenceData = null;
		if(result.isPresent()) {
			eventConferenceData = result.get();
		}else {
			System.out.println("resilt not present");
		}
		//System.out.println(eventConferenceData.getEvenConferenceInfo().getEventId()+" eventConferenceData id "   );
		return eventConferenceData;
	}
	
	public void uploadEvents(
			MultipartFile reapExcelDataFile,
			HttpServletRequest request) throws IOException {
		
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		
		final String label = UUID.randomUUID().toString() + ".xlsx";
	    final String filepath1 = filePath+"temp/" + label;
	    byte[] bytes = reapExcelDataFile.getBytes();
	    File fh = new File(filePath+"temp/");
	    if(!fh.exists()){
	         fh.mkdir();
	    }
	    
	    try {
	    	
	    	
	    	  FileOutputStream writer = new FileOutputStream(filepath1);
	          writer.write(bytes);
	          writer.close();
	          FileInputStream inputStream = new FileInputStream(filepath1);
	          
	          //For Sheet 0 -- > Event Master Data Start
	          EventMaster eventMaster = new EventMaster();
	          
	          //Check If We have Event Id already exits
		      if(request.getParameter("eventId") !=null  && !request.getParameter("eventId").equals("")
		      		  && !request.getParameter("eventId").equals("null") && !request.getParameter("eventId").equals("0")) {
		      	  Optional<EventMaster> eventOptionalMaster = eventMasterRepository.findById(Long.valueOf(request.getParameter("eventId")));
		      	  if(eventOptionalMaster.isPresent()) {
		      		  eventMaster = eventOptionalMaster.get();
		      	  }
		      }
		      
		      //Delete Existing Record Try 
		      try {
		    	  
		    	  if(eventMaster.getEventId()!=null && eventMaster.getEventId()!=0 ) {
		    		  //1st event Conference 
		    		  eventConferenceInformationRepository.deleteFromEvenConferenceInfobyEventId(eventMaster.getEventId());
		    		  //2nd event Speaker
		    		  eventSpeakerRepository.deleteAllSpeakerByEventId(eventMaster.getEventId());
		    		  //3rd event Session 
		    		  eventSessionRepository.deleteAllByEventId(eventMaster.getEventId());
		    		  //4th event Participant 
		    		  eventParticipantRepository.deleteAllParticipantByEventId(eventMaster.getEventId());
		    		  //5th event Admin
		    		  eventAdminRepository.deleteAllByEventId(eventMaster.getEventId());
		    		  //6th event Mobile
		    		  mobileEventUserRepository.deleteByEventId(eventMaster.getEventId());
		    	  }
				
				} catch (Exception e) {
					e.printStackTrace();
				}
		      
		      
	          DataTable table = ExcelTable.load(() -> inputStream,0);
	          int rowCount = table.rowCount();
	          for(int i=0; i < rowCount; ++i) {
	             DataRow row = table.row(i);
	            
	             String eventType = row.cell("Event Type");
	             String eventName = row.cell("Event Name");
	             String eventPlaceName = row.cell("Event Place Name");
	             String eventStartDate = row.cell("Event Start Date");
	             String eventEndDate = row.cell("Event End Date");
	             String venueAddress = row.cell("Venue Address");
	             String venuePinCode = row.cell("Venue Pin Code");
	             String venueLatitude = row.cell("Venue Latitude");
	             String venueLongitude = row.cell("Venue Longitude");
	            
	             if(eventType!=null && !eventType.equals("")
	 						&& !eventType.equals("null")) {
					//for eventType
	            	Optional<ProductMaster> productOpt = productRepo.findByProductNameIgnoreCase(eventType);
	         		if(productOpt.isPresent()) {
	         			ProductMaster productMaster = productOpt.get();
	         			eventMaster.setEventProduct(productMaster);
	         		}
				  }
	             if(eventName!=null && !eventName.equals("")
	 												&& !eventName.equals("null")) {
	            	 eventMaster.setEventName(eventName);
	             }
	             if(eventPlaceName!=null && !eventPlaceName.equals("")
							&& !eventPlaceName.equals("null")) {
	            	 eventMaster.setEventLocationPlaceName(eventPlaceName);	
	             }
	             if(eventStartDate!=null && !eventStartDate.equals("")
							&& !eventStartDate.equals("null")) {
	            	 eventMaster.setEventStartDate(eventStartDate);
	             }
	             if(eventEndDate!=null && !eventEndDate.equals("")
							&& !eventEndDate.equals("null")) {
	            	 eventMaster.setEventEndDate(eventEndDate);
	             }
	             if(venueAddress!=null && !venueAddress.equals("")
							&& !venueAddress.equals("null")) {
	            	 eventMaster.setEventVenueAddress(venueAddress);
	             }
	             if(venuePinCode!=null && !venuePinCode.equals("")
							&& !venuePinCode.equals("null")) {
	            	 eventMaster.setEventVenuePincode(venuePinCode);
	             }
	             if(venueLatitude!=null && !venueLatitude.equals("")
							&& !venueLatitude.equals("null")) {
	            	 eventMaster.setEventVenueLatittude(venueLatitude);
	             }	
	             if(venueLongitude!=null && !venueLongitude.equals("")
							&& !venueLongitude.equals("null")) {
	            	 eventMaster.setEventVenueLongitude(venueLongitude);
	             }
	             
	             eventMasterRepository.save(eventMaster);
	          }
	          
	          
	          
	          //For Sheet 0 -- > Event Master Data End
	          //For Sheet 1 -- > Event Conference Information Start
	          EventConferenceInformation eventConferenceInformation = new EventConferenceInformation();
//	          if(eventMaster.getEventId()!=null && eventMaster.getEventId()!=0 ) {
//	        	  if(eventMaster.getEventConferenceInformation()!=null) {
//	        		  eventConferenceInformation =  eventMaster.getEventConferenceInformation();
//	        	  }
//	          }
	          FileInputStream inputStream1 = new FileInputStream(filepath1);
	          table = ExcelTable.load(() -> inputStream1,1);
	          rowCount = table.rowCount();
	          for(int i=0; i < rowCount; ++i) {
	             DataRow row = table.row(i);
	             
	             String dressCode = row.cell("Dress code");
	             String registrationDetail = row.cell("Registration Detail");
	             String specialRequirements = row.cell("Special Requirements");
	             String attendanceTimeTable = row.cell("Attendance Time Table");
	             String presentations = row.cell("Presentations");
	             String transportation = row.cell("Transportation");
	            
	             if(dressCode!=null && !dressCode.equals("")
	 												&& !dressCode.equals("null")) {
	            	 eventConferenceInformation.setDressCode(dressCode);
	             }
	             if(registrationDetail!=null && !registrationDetail.equals("")
							&& !registrationDetail.equals("null")) {
	            	 eventConferenceInformation.setRegisterationDetail(registrationDetail);
	             }
	             if(specialRequirements!=null && !specialRequirements.equals("")
							&& !specialRequirements.equals("null")) {
	            	 eventConferenceInformation.setSpecialRequirements(specialRequirements);
	             }
	             if(attendanceTimeTable!=null && !attendanceTimeTable.equals("")
							&& !attendanceTimeTable.equals("null")) {
	            	 eventConferenceInformation.setAttendenceTimeTable(attendanceTimeTable);
	             }
	             if(presentations!=null && !presentations.equals("")
							&& !presentations.equals("null")) {
	            	 eventConferenceInformation.setPresentations(presentations);
	             }
	             if(transportation!=null && !transportation.equals("")
							&& !transportation.equals("null")) {
	            	 eventConferenceInformation.setTransportation(transportation);
	             }
	             eventConferenceInformation.setEvenConferenceInfo(eventMaster);
	             eventConferenceInformationRepository.save(eventConferenceInformation);
	          }
	         
	         //For Sheet 1 -- > Event Conference Information Ends
	          //For Sheet 2 -- > Event Speaker Start
	          Map<Integer, EventSpeakers> uploadEventSpeakerMap =  new HashMap<Integer, EventSpeakers>();
	          FileInputStream inputStream2 = new FileInputStream(filepath1);
	          table = ExcelTable.load(() -> inputStream2,2);
	          rowCount = table.rowCount();
	          for(int i=0; i < rowCount; ++i) {
	        	 SpeakerMaster speakerMaster = new SpeakerMaster();
	        	 EventSpeakers eventSpeakers = new EventSpeakers();
	             DataRow row = table.row(i);
	             String Title = row.cell("Title");
	             String FirstName = row.cell("FirstName");
	             String LastName = row.cell("LastName");
	             String Organization = row.cell("Organization");
	             String Center = row.cell("Center");
	             String Department = row.cell("Department");
	             String Designation = row.cell("Designation");
	             String EmailId = row.cell("EmailId");
	             String speakerMobileNo = row.cell("MobileNo");
	             String roomNo = row.cell("Room no");
	             String emergencyContactNo = row.cell("Emergency Contact No");
	             String allergies = row.cell("Allergies");
	             String driverName = row.cell("Driver Name");
	             String driverContactNo = row.cell("Driver Contact No");
	             String driverCABNo = row.cell("Driver CAB No");
	             String speakerIsAdmin = row.cell("Speaker is Admin");
	             String loginId = "";
	             String loginMobileNo = "";
	             
	             if(EmailId!=null && !EmailId.equals("")
							&& !EmailId.equals("null")) {
	            	if(RandomUtil.isEmailValid(EmailId)) {
		            	Optional<SpeakerMaster> optionalSpeaker = speakersRepository.findOneBySpeakerEmailIdIgnoreCase(EmailId);
		            	if(optionalSpeaker.isPresent()) {
		            		speakerMaster =  optionalSpeaker.get();
		            		speakerMaster.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
		            		speakerMaster.setModifiedDate(Instant.now());
		            	}else {
		            		speakerMaster.setSpeakerEmailId(EmailId);
		            		speakerMaster.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
		   	                speakerMaster.setCreatedDate(Instant.now());
		            	}
		            	int index = EmailId.indexOf('@');
		            	loginId = EmailId.substring(0,index);
	            	}else {
	            		try {
		            		List<SpeakerMaster> optionalSpeaker = speakersRepository.findAllBySpeakerFirstName(FirstName);
		            		if(!optionalSpeaker.isEmpty()) {
		            			speakerMaster =  optionalSpeaker.get(0);
		            			speakerMaster.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
			            		speakerMaster.setModifiedDate(Instant.now());
		            		}
			            	else {
			            		speakerMaster.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
			   	                speakerMaster.setCreatedDate(Instant.now());
			            	}
	            		}catch(Exception e) {
	            			speakerMaster.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
		   	                speakerMaster.setCreatedDate(Instant.now());
	            		}
	            	}
	             }else {
	            	 continue;
	             }
	             
	             if(Title!=null && !Title.equals("")
							&& !Title.equals("null")) {
	            	 speakerMaster.setTitle(Title);
	             } 
	             if(FirstName!=null && !FirstName.equals("")
							&& !FirstName.equals("null")) {
	            	 speakerMaster.setSpeakerFirstName(FirstName);
	             } 
	             if(LastName!=null && !LastName.equals("")
							&& !LastName.equals("null")) {
	            	 speakerMaster.setSpeakerLastName(LastName);
	             }
	             if(Organization!=null && !Organization.equals("")
							&& !Organization.equals("null")) {
	            	 if(organizationRepository.findByOrganizationNameIgnoreCase(Organization).isPresent()) {
		            	 speakerMaster.setSpeakerOrganization(organizationRepository.findByOrganizationNameIgnoreCase(Organization).get());
		             }
	             }
	             if(Center!=null && !Center.equals("")
							&& !Center.equals("null")) {
	            	 if(centreRepository.findByCentreName(Center).isPresent()) {
		            	 speakerMaster.setSpeakerCenter(centreRepository.findByCentreName(Center).get());
		             }
	             }
	             if(Department!=null && !Department.equals("")
							&& !Department.equals("null")) {
	            	 if(depmartmentRepo.findByDepartmentNameIgnoreCase(Department).isPresent()) {
		            	 speakerMaster.setSpeakerDepartment(depmartmentRepo.findByDepartmentNameIgnoreCase(Department).get());
		             }
	             }
	             if(Designation!=null && !Designation.equals("")
							&& !Designation.equals("null")) {
	            	 if(designationRepository.findByDesignationNameIgnoreCase(Designation).isPresent()) {
		            	 speakerMaster.setSpeakerDesignation(designationRepository.findByDesignationNameIgnoreCase(Designation).get());
		             }
	             }
	             
	             if(speakerMobileNo!=null && !speakerMobileNo.equals("")
							&& !speakerMobileNo.equals("null")) {
	            	 if(RandomUtil.isMobileValid(speakerMobileNo))
	            	 {
	            		 speakerMaster.setSpeakerMobileNo(speakerMobileNo);
	            		 loginMobileNo =  "91"+speakerMobileNo;
	            	 }
	             }
	             
	             if(speakerMaster.getSpeakerId()!=null && speakerMaster.getSpeakerId()!=0) {
	            	 Optional<EventSpeakers> optionalEventSpeaker = eventSpeakerRepository.findBySpeakerAndEventId(eventMaster.getEventId(), speakerMaster.getSpeakerId());
		    	     if(optionalEventSpeaker.isPresent()) {
		    		     eventSpeakers = optionalEventSpeaker.get();
		    	     }
	             }
	             eventSpeakers.setEventSpeaker(speakerMaster);
	             eventSpeakers.setLoginId(loginId);
	             eventSpeakers.setLoginMobileNo(loginMobileNo);
	             if(speakerIsAdmin!=null && !speakerIsAdmin.equals("")
							&& !speakerIsAdmin.equals("null")) {
	            	 if(speakerIsAdmin.equalsIgnoreCase("y")) {
	            		 eventSpeakers.setIsAdmin(1);
	            	 }
	            	 if(speakerIsAdmin.equalsIgnoreCase("n")) {
	            		 eventSpeakers.setIsAdmin(0);
	            	 }
	             }
	             if(roomNo!=null && !roomNo.equals("")
							&& !roomNo.equals("null")) {
	            	 eventSpeakers.setRoomNo(roomNo);
	             }
	             if(emergencyContactNo!=null && !emergencyContactNo.equals("")
							&& !emergencyContactNo.equals("null")) {
	            	 eventSpeakers.setEmergencyContactNo(emergencyContactNo);
	             }
	             if(allergies!=null && !allergies.equals("")
							&& !allergies.equals("null")) {
	            	 eventSpeakers.setAllergies(allergies);
	             }
	             if(driverName!=null && !driverName.equals("")
							&& !driverName.equals("null")) {
	            	 eventSpeakers.setDriverName(driverName);
	             }
	             if(driverContactNo!=null && !driverContactNo.equals("")
							&& !driverContactNo.equals("null")) {
	            	 eventSpeakers.setDriverContactNo(driverContactNo);
	             }
	             if(driverCABNo!=null && !driverCABNo.equals("")
							&& !driverCABNo.equals("null")) {
	            	 eventSpeakers.setDriverCabNo(driverCABNo);
	             }
	             eventSpeakers.setEventSpeakers(eventMaster);
	             uploadEventSpeakerMap.put(i+1, eventSpeakers);
	          }
	          
	          //Below Part for Storing Image
	          //Below for getting image 
	          FileInputStream inputStream2_image = new FileInputStream(filepath1);
	          XSSFWorkbook  wb = new XSSFWorkbook(inputStream2_image);
	          XSSFSheet sheet = wb.getSheetAt(2);
	          XSSFDrawing xssDrawing = sheet.getDrawingPatriarch();
	          List<XSSFShape> shapes = xssDrawing.getShapes();
	          int shapeCount=0; //skiping first
	          for (XSSFShape shape : shapes) {
	              if (shape instanceof XSSFPicture) {
	                 
	                  XSSFPicture hssfPicture = (XSSFPicture) shape;
	                  int rowIndex = hssfPicture.getClientAnchor().getRow1();
	                  //Get Map Value 
	                  if(uploadEventSpeakerMap.get(rowIndex)!=null) {
	                  //For Filename get
	                  final String fileName = UUID.randomUUID().toString() +".jpg";
	                  //Set File Name & Folder Name
	                  final String folderPath =   "Speakers" +"/" +"profile_pic";
	                  final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
	                  System.out.println(fileName);
	                  System.out.println(folderPath);
	                  System.out.println(fileImagePath);
	                  System.out.println(rowIndex);
	                  PictureData data = hssfPicture.getPictureData();
	                  byte [] picData = data.getData();
	                  FileOutputStream fos = new FileOutputStream(new File(fileImagePath));
	                  fos.write(picData);
	                  fos.close();
	                  int colIndex = hssfPicture.getClientAnchor().getCol1();
	                  System.out.println("Picture  is located row: " + rowIndex+ ", col: " + colIndex);
	                  
	                	  EventSpeakers eventSpeaker =  uploadEventSpeakerMap.get(rowIndex);
		                  SpeakerMaster speaker =  eventSpeaker.getEventSpeaker();
		                  speaker.setSpeakerFileName(fileName);
		                  speaker.setSpeakerFolderName(folderPath);
		                  eventSpeaker.setEventSpeaker(speaker);
		                  uploadEventSpeakerMap.put(rowIndex, eventSpeaker);
	                  }
	              }
	             
	              shapeCount++;
	          }
	          //Finally Saving Parts Starts Here
	          //finally Data insert begin 
	  	      for (Map.Entry<Integer, EventSpeakers> entry : uploadEventSpeakerMap.entrySet()) {
	  	    	EventSpeakers eventSpeaker =  entry.getValue();
	  	    	SpeakerMaster speaker =  eventSpeaker.getEventSpeaker();
	  	    	EventAdmin eventAdmin = new EventAdmin();
	  	    	
	  	    	System.out.println("speaker.getSpeakerEmailId() -->"+speaker.getSpeakerEmailId());
	  	    	if(speaker.getSpeakerEmailId()!=null && !speaker.getSpeakerEmailId().equals("")) {
		  	    	//Re check if Same Speaker Already Exits
		  	    	Optional<SpeakerMaster> optionalSpeaker = speakersRepository.findOneBySpeakerEmailIdIgnoreCase(speaker.getSpeakerEmailId());
		  	    	if(optionalSpeaker.isPresent()) {
		  	    		Optional<EventSpeakers> optionalEventSpeaker = eventSpeakerRepository.findBySpeakerAndEventId(eventMaster.getEventId(), optionalSpeaker.get().getSpeakerId());
			  	  		if(optionalEventSpeaker.isPresent()) {
			  	  			continue;
			  	  		}
		  	    	}
	  	    	}
	  	    	
	  	    	speakersRepository.save(speaker);
	  	    	eventSpeakerRepository.save(eventSpeaker);
	  	    	if(speaker.getSpeakerEmailId()!=null && !speaker.getSpeakerEmailId().equals("")) {
	  	    	 //Below for Mobile User & Mobile User 
		  	     //Finally Enter Record Inside Mobile_User Table & Mobile User Event Table 
		  	      MobileUsers mobileUser = new MobileUsers();	
		  	      Optional<MobileUsers> optionalMobileUser = mobileUserRepository.findOneByEmailIdIgnoreCase(speaker.getSpeakerEmailId());
		  	      if(optionalMobileUser.isPresent()) {
		  	    	  mobileUser = optionalMobileUser.get();
		  	      }
		  	      mobileUser.setUserMobileNo(eventSpeaker.getLoginMobileNo());
		  	      mobileUser.setEmail_id(speaker.getSpeakerEmailId());
		  	      //mobileUser.setUserType(0);
		  	      //mobileUser.setUserTypeId(eventSpeaker.getEventSpeaker().getSpeakerId().intValue());
		  	      mobileUser.setIsAdmin(eventSpeaker.getIsAdmin());
		  	      mobileUser.setUserId(eventSpeaker.getLoginId());
		  	      mobileUser.setUserName(speaker.getSpeakerFirstName());
		  	      mobileUser.setActiveStatus(speaker.getActiveStatus());
		  	      mobileUserRepository.save(mobileUser);
		  	      MobileEventUsers mobileEventUsers = new MobileEventUsers();
		  	      Optional<MobileEventUsers> optionalMobileEventUsers = mobileEventUserRepository.findByEventIdAndMobileUserId(eventMaster.getEventId(), mobileUser.getId());
		  	      if(optionalMobileEventUsers.isPresent()) {
		  	    	  mobileEventUsers = optionalMobileEventUsers.get();
		  	      }
		  	      mobileEventUsers.setEventId(eventMaster.getEventId());
		  	      mobileEventUsers.setMobileUserId(mobileUser.getId());
		  	      mobileEventUserRepository.save(mobileEventUsers);
		  	      
		  	     Optional<EventAdmin> optionEventAdmin =  eventAdminRepository.findAllByEventIdAndMail(eventMaster.getEventId(), speaker.getSpeakerEmailId());
	           	 if(optionEventAdmin.isPresent()) {
	           		 eventAdmin =  optionEventAdmin.get();
	           	 }
		  	      if(eventSpeaker.getIsAdmin() ==  1) {
		            	 eventAdmin.setAdminEmailId(speaker.getSpeakerEmailId());
		            	 eventAdmin.setAdminContactAddress(speaker.getSpeakerMobileNo());
		            	 eventAdmin.setAdminFullName(speaker.getSpeakerFirstName() + " " + ((speaker.getSpeakerLastName()!=null && speaker.getSpeakerLastName()!="")?speaker.getSpeakerLastName():""));
		            	 eventAdmin.setEventAdmin(eventMaster);
		            	 eventAdminRepository.save(eventAdmin);
		  	      }
		  	      
	  	    	}
	  	      }
	          
	         //For Sheet 2 -- > Event Speaker Ends 
	         //For Sheet 3 -- > Event Session Ref Start
	          FileInputStream inputStream3 = new FileInputStream(filepath1);
	          table = ExcelTable.load(() -> inputStream3,3);
	          rowCount = table.rowCount();
	          for(int i=0; i < rowCount; ++i) {
	        	 EventSessionRef eventSessionRef = new EventSessionRef(); 
	             DataRow row = table.row(i);
	             
	             String eventDate = row.cell("Event Date");
	             String sessionName = row.cell("Session Name");
	             String sessionTopicName = row.cell("Session Topic Name");
	             String startTime = row.cell("Start Time");
	             String endTime = row.cell("End Time");
	             String speakerEmailId = row.cell("Speaker Email Id");
	             String isSession = row.cell("Is Session");
	             String isFeedback = row.cell("Is Feedback");
	             
	             if(eventDate!=null && !eventDate.equals("")
							&& !eventDate.equals("null")) {
	            	 eventSessionRef.setEventDate(eventDate);
	             }else {
	            	 continue;
	             }
	             
	             //Combination of eventDate / startTime  ?????
	             if(eventMaster.getEventId()!=null) {
	            	 if((eventDate!=null && !eventDate.equals("") && !eventDate.equals("null")) && (startTime!=null && !startTime.equals("") && !startTime.equals("null")) ) {
	            	 Optional<EventSessionRef> optionalEventSession =  eventSessionRepository.findByCombinationOfEventDateTimeAndEventId(eventMaster.getEventId(), eventDate, startTime);
	            	  if (optionalEventSession.isPresent()) {
	            		 eventSessionRef =  optionalEventSession.get();
					  }
	            	 }
	             }
	             
	            
	             if(speakerEmailId!=null && !speakerEmailId.equals("")
	 												&& !speakerEmailId.equals("null")) {
	            	 Optional<SpeakerMaster> optionalSpeaker = speakersRepository.findOneBySpeakerEmailIdIgnoreCase(speakerEmailId);
	            	 if(optionalSpeaker.isPresent()) {
	            		 eventSessionRef.setSpeaker(optionalSpeaker.get());
	            	 }
	             }
	             
	             if(sessionName!=null && !sessionName.equals("")
							&& !sessionName.equals("null")) {
	            	 eventSessionRef.setSessionName(sessionName);
	             }
	             if(sessionTopicName!=null && !sessionTopicName.equals("")
							&& !sessionTopicName.equals("null")) {
	            	 eventSessionRef.setSessionTopic(sessionTopicName);
	             }
	             if(startTime!=null && !startTime.equals("")
							&& !startTime.equals("null")) {
	            	 eventSessionRef.setSessionStartTime(startTime);
	             }
	             if(endTime!=null && !endTime.equals("")
							&& !endTime.equals("null")) {
	            	 eventSessionRef.setSessionEndTime(endTime);
	             }
	             if(isSession!=null && !isSession.equals("")
							&& !isSession.equals("null")) {
	            	 eventSessionRef.setIsSession(isSession);
	             }
	             if(isFeedback!=null && !isFeedback.equals("")
							&& !isFeedback.equals("null")) {
	            	 eventSessionRef.setIsfeedback(isFeedback);
	             }
	            
	             eventSessionRef.setEventSessions(eventMaster);
	             eventSessionRepository.save(eventSessionRef);
	          }
	          
	         //For Sheet 3 -- > Event Session Ends  
	         //For Sheet 4 -- > Event Event Participant Start 
	          Map<Integer, EventParticipants> uploadEventParticipantMap =  new HashMap<Integer, EventParticipants>();
	          FileInputStream inputStream4 = new FileInputStream(filepath1);
	          table = ExcelTable.load(() -> inputStream4,4);
	          rowCount = table.rowCount();
	          for(int i=0; i < rowCount; ++i) {
	        	  ParticipantMaster participantMaster = new ParticipantMaster();
	        	  EventParticipants eventParticipants = new EventParticipants(); 
	              DataRow row = table.row(i);
	             
	             String Title = row.cell("Title");
	             String FirstName = row.cell("FirstName");
	             String LastName = row.cell("LastName");
	             String Organization = row.cell("Organization");
	             String Center = row.cell("Center");
	             String Department = row.cell("Department");
	             String Designation = row.cell("Designation");
	             String EmailId = row.cell("EmailId");
	             String MobileNo = row.cell("MobileNo");
	             String roomNo = row.cell("Room no");
	             String emergencyContactNo = row.cell("Emergency Contact No");
	             String allergies = row.cell("Allergies");
	             String driverName = row.cell("Driver Name");
	             String driverContactNo = row.cell("Driver Contact No");
	             String driverCABNo = row.cell("Driver CAB No");
	             String participantIsAdmin = row.cell("Participant is Admin");
	             String loginId = "";
	             String loginMobileNo = "";
	           
	             if(EmailId!=null && !EmailId.equals("")
							&& !EmailId.equals("null")) {
	            	 
	            	 if(RandomUtil.isEmailValid(EmailId)) {
		            	 Optional<ParticipantMaster> optionParticipant = participantRepository.findOneByParticipantEmailIdIgnoreCase(EmailId);
		            	 if(optionParticipant.isPresent()) {
		            		 participantMaster =  optionParticipant.get();
		            		 participantMaster.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
				             participantMaster.setModifiedDate(Instant.now());
		            	 }else {
		            		 participantMaster.setParticipantEmailId(EmailId);
		            		 participantMaster.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
				             participantMaster.setCreatedDate(Instant.now());
		            	 }
		            	 int index = EmailId.indexOf('@');
			             loginId = EmailId.substring(0,index);
	            	 }else {
	            		 try {
		            		 List<ParticipantMaster> optionParticipant = participantRepository.findAllByParticipantFirstName(FirstName);
		            		 if(!optionParticipant.isEmpty()) {
		            			 participantMaster =  optionParticipant.get(0);
			            		 participantMaster.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
					             participantMaster.setModifiedDate(Instant.now());
		            		 }else {
			            		 participantMaster.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
					             participantMaster.setCreatedDate(Instant.now());
			            	 }
	            		 }catch (Exception e) {
	            			 e.printStackTrace();
	            			 participantMaster.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
				             participantMaster.setCreatedDate(Instant.now());
						}
	            		 
	            		 
	            	 }
	             }else {
	            	 continue;
	             }
	             
	             if(Title!=null && !Title.equals("")
							&& !Title.equals("null")) {
	            	 participantMaster.setTitle(Title);
		             
	             }
	             if(FirstName!=null && !FirstName.equals("")
							&& !FirstName.equals("null")) {
	            	 participantMaster.setParticipantFirstName(FirstName);
		            
	             }
	             if(LastName!=null && !LastName.equals("")
							&& !LastName.equals("null")) {
	            	 participantMaster.setParticipantLastName(LastName);
	             }
	             if(Organization!=null && !Organization.equals("")
							&& !Organization.equals("null")) {
	            	 if(organizationRepository.findByOrganizationNameIgnoreCase(Organization).isPresent()) {
		            	 participantMaster.setParticipantOrganization(organizationRepository.findByOrganizationNameIgnoreCase(Organization).get());
		             }
	             }
	             if(Center!=null && !Center.equals("")
							&& !Center.equals("null")) {
	            	 if(centreRepository.findByCentreName(Center).isPresent()) {
		            	 participantMaster.setParticipantCenter(centreRepository.findByCentreName(Center).get());
		             }
	             }
	             if(Department!=null && !Department.equals("")
							&& !Department.equals("null")) {
	            	 if(depmartmentRepo.findByDepartmentNameIgnoreCase(Department).isPresent()) {
		            	 participantMaster.setParticipantDepartment(depmartmentRepo.findByDepartmentNameIgnoreCase(Department).get());
		             }
	             }
	             if(Designation!=null && !Designation.equals("")
							&& !Designation.equals("null")) {
	            	 if(designationRepository.findByDesignationNameIgnoreCase(Designation).isPresent()) {
		            	 participantMaster.setParticipantDesignation(designationRepository.findByDesignationNameIgnoreCase(Designation).get());
		             }
	             }
	            
	             if(MobileNo!=null && !MobileNo.equals("")
							&& !MobileNo.equals("null")) {	            	 
	            	 if(RandomUtil.isMobileValid(MobileNo))
	            	 {
	            		 participantMaster.setParticipantMobileNo(MobileNo);
	            		 loginMobileNo =  "91"+MobileNo;
	            	 }	            	 
	             }
	             if(participantMaster.getParticipantId()!=null && participantMaster.getParticipantId()!=0) {
	            	 Optional<EventParticipants> optionalEventParticipant = eventParticipantRepository.findByParticipantAndEventId(eventMaster.getEventId(), participantMaster.getParticipantId());
		    	     if(optionalEventParticipant.isPresent()) {
		    	    	 eventParticipants = optionalEventParticipant.get();
		    	     }
	             }
	             eventParticipants.setLoginId(loginId);
	             eventParticipants.setLoginMobileNo(loginMobileNo);
	             if(participantIsAdmin!=null && !participantIsAdmin.equals("")
							&& !participantIsAdmin.equals("null")) {
	            	 if(participantIsAdmin.equalsIgnoreCase("y")) {
	            		 eventParticipants.setIsAdmin(1);
	            	 }
	            	 if(participantIsAdmin.equalsIgnoreCase("n")) {
	            		 eventParticipants.setIsAdmin(0);
	            	 }
	             }
	             eventParticipants.setEventParticipant(participantMaster);
	             
	             if(roomNo!=null && !roomNo.equals("")
							&& !roomNo.equals("null")) {
	            	 eventParticipants.setRoomNo(roomNo);
	             }
	             if(emergencyContactNo!=null && !emergencyContactNo.equals("")
							&& !emergencyContactNo.equals("null")) {
	            	 eventParticipants.setEmergencyContactNo(emergencyContactNo);
	             }
	             if(allergies!=null && !allergies.equals("")
							&& !allergies.equals("null")) {
	            	 eventParticipants.setAllergies(allergies);
	             }
	             if(driverName!=null && !driverName.equals("")
							&& !driverName.equals("null")) {
	            	 eventParticipants.setDriverName(driverName);
	             }
	             if(driverContactNo!=null && !driverContactNo.equals("")
							&& !driverContactNo.equals("null")) {
	            	 eventParticipants.setDriverContactNo(driverContactNo);
	             }
	             if(driverCABNo!=null && !driverCABNo.equals("")
							&& !driverCABNo.equals("null")) {
	            	 eventParticipants.setDriverCabNo(driverCABNo);
	             }
	             eventParticipants.setEventParticipants(eventMaster);
	             uploadEventParticipantMap.put(i+1, eventParticipants);
	             //eventParticipantRepository.save(eventParticipants);
	          } 
	         
	          //Below Part for Storing Image
	          //Below for getting image 
	          FileInputStream inputStream4_image = new FileInputStream(filepath1);
	          wb = new XSSFWorkbook(inputStream4_image);
	          sheet = wb.getSheetAt(4);
	          xssDrawing = sheet.getDrawingPatriarch();
	          shapes = xssDrawing.getShapes();
	          //int shapeCount=0; //skiping first
	          for (XSSFShape shape : shapes) {
	              if (shape instanceof XSSFPicture) {
	                  XSSFPicture hssfPicture = (XSSFPicture) shape;
	                  int rowIndex = hssfPicture.getClientAnchor().getRow1();
	                  //Get Map Value 
	                  if(uploadEventParticipantMap.get(rowIndex)!=null) {
	                  //For Filename get
	                  final String fileName = UUID.randomUUID().toString() +".jpg";
	                  //Set File Name & Folder Name
	                  final String folderPath =   "Participants" +"/" +"profile_pic";
	                  final String fileImagePath = filePath + folderPath +  "/" +  fileName ;
	                  System.out.println(fileName);
	                  System.out.println(folderPath);
	                  System.out.println(fileImagePath);
	                  System.out.println(rowIndex);
	                  PictureData data = hssfPicture.getPictureData();
	                  byte [] picData = data.getData();
	                  FileOutputStream fos = new FileOutputStream(new File(fileImagePath));
	                  fos.write(picData);
	                  fos.close();
	                  int colIndex = hssfPicture.getClientAnchor().getCol1();
	                  System.out.println("Picture  is located row: " + rowIndex+ ", col: " + colIndex);
	                  
	                	  EventParticipants eventParticipants  =  uploadEventParticipantMap.get(rowIndex);
		                  ParticipantMaster participant =  eventParticipants.getEventParticipant();
		                  participant.setParticipantFileName(fileName);
		                  participant.setParticipantFolderName(folderPath);
		                  eventParticipants.setEventParticipant(participant);
		                  uploadEventParticipantMap.put(rowIndex, eventParticipants);
	                  }
	              }
	             
	              shapeCount++;
	          }
	         
	        //finally Data insert begin 
	  	    for (Map.Entry<Integer, EventParticipants> entry : uploadEventParticipantMap.entrySet()) {
	  	    	EventAdmin eventAdmin = new EventAdmin();
	  	    	EventParticipants eventParticipant = entry.getValue();
	  	    	ParticipantMaster participant =  eventParticipant.getEventParticipant();
	  	    	
	  	    	if(participant.getParticipantEmailId()!=null && !participant.getParticipantEmailId().equals("")) {
	  	    	Optional<ParticipantMaster> optionParticipant = participantRepository.findOneByParticipantEmailIdIgnoreCase(participant.getParticipantEmailId());
	           	 if(optionParticipant.isPresent()) {
	           		Optional<EventParticipants> optionalEventParticipant = eventParticipantRepository.findByParticipantAndEventId(eventMaster.getEventId(), optionParticipant.get().getParticipantId());
	        		if(optionalEventParticipant.isPresent()) {
	        			continue;
	        		}
	           	 }
	  	    	}
	           	 
	  	    	participantRepository.save(participant);
	  	    	eventParticipantRepository.save(eventParticipant);
	  	    	if(participant.getParticipantEmailId()!=null && !participant.getParticipantEmailId().equals("")) {
	  	        //Below for Mobile User & Mobile User 
		  	    //Finally Enter Record Inside Mobile_User Table & Mobile User Event Table 
		  	      MobileUsers mobileUser = new MobileUsers();	
		  	      Optional<MobileUsers> optionalMobileUser = mobileUserRepository.findOneByEmailIdIgnoreCase(participant.getParticipantEmailId());
		  	      if(optionalMobileUser.isPresent()) {
		  	    	  mobileUser = optionalMobileUser.get();
		  	      }
		  	      
		  	      mobileUser.setUserMobileNo(eventParticipant.getLoginMobileNo());
		  	      mobileUser.setEmail_id(participant.getParticipantEmailId());
		  	      //mobileUser.setUserType(1);
		  	      //mobileUser.setUserTypeId(eventParticipant.getEventParticipant().getParticipantId().intValue());
		  	      mobileUser.setIsAdmin(eventParticipant.getIsAdmin());
		  	      mobileUser.setUserId(eventParticipant.getLoginId());
		  	      mobileUser.setUserName(participant.getParticipantFirstName());
		  	      mobileUser.setActiveStatus(participant.getActiveStatus());
		  	      mobileUserRepository.save(mobileUser);
		  	      MobileEventUsers mobileEventUsers = new MobileEventUsers();
		  	      Optional<MobileEventUsers> optionalMobileEventUsers = mobileEventUserRepository.findByEventIdAndMobileUserId(eventMaster.getEventId(), mobileUser.getId());
		  	      if(optionalMobileEventUsers.isPresent()) {
		  	    	  mobileEventUsers = optionalMobileEventUsers.get();
		  	      }
		  	      mobileEventUsers.setEventId(eventMaster.getEventId());
		  	      mobileEventUsers.setMobileUserId(mobileUser.getId());
		  	      mobileEventUserRepository.save(mobileEventUsers);
		  	      
		  	    if(eventParticipant.getIsAdmin() ==  1) {
	            	 Optional<EventAdmin> optionEventAdmin =  eventAdminRepository.findAllByEventIdAndMail(eventMaster.getEventId(), participant.getParticipantEmailId());
	            	 if(optionEventAdmin.isPresent()) {
	            		 eventAdmin =  optionEventAdmin.get();
	            	 }
	            	 eventAdmin.setAdminEmailId(participant.getParticipantEmailId());
	            	 eventAdmin.setAdminContactAddress(participant.getParticipantMobileNo());
	            	 eventAdmin.setAdminFullName(participant.getParticipantFirstName() + " " + ((participant.getParticipantLastName()!=null && participant.getParticipantLastName()!="")?participant.getParticipantLastName():""));
	            	 eventAdmin.setEventAdmin(eventMaster);
	            	 eventAdminRepository.save(eventAdmin);
	  	       }
	  	      }
	  	    }  
	          
	        //For Sheet 4 -- > Event Event Participant Ends  
	        //For Sheet 5 -- > Event Event Admin
	          FileInputStream inputStream5 = new FileInputStream(filepath1);
	          table = ExcelTable.load(() -> inputStream5,5);
	          rowCount = table.rowCount();
	          for(int i=0; i < rowCount; ++i) {
	        	  EventAdmin eventAdmin = new EventAdmin();
	              DataRow row = table.row(i);
	             
	             String adminFullName = row.cell("Admin Full Name");
	             String contactNo = row.cell("Contact No");
	             String adminEmailId = row.cell("Email Id");
	             String loginId = "";
	             String loginMobileNo = "";
	           
	             if(adminEmailId!=null && !adminEmailId.equals("")
							&& !adminEmailId.equals("null")) {
	            	 if(RandomUtil.isEmailValid(adminEmailId)) {
	            		 eventAdmin.setAdminEmailId(adminEmailId);
	            		 int index = adminEmailId.indexOf('@');
			             loginId = adminEmailId.substring(0,index);
	            	 }
	             }else {
	            	 continue;
	             }
	             
	             if(eventMaster.getEventId()!=null) {
	            	 Optional<EventAdmin> optionEventAdmin =  eventAdminRepository.findAllByEventIdAndMail(eventMaster.getEventId(), adminEmailId);
	            	 if(optionEventAdmin.isPresent()) {
	            		 eventAdmin =  optionEventAdmin.get();
	            	 }
	             }
	             if(adminFullName!=null && !adminFullName.equals("")
							&& !adminFullName.equals("null")) {
	            	 eventAdmin.setAdminFullName(adminFullName);
	             }
	             if(contactNo!=null && !contactNo.equals("")
							&& !contactNo.equals("null")) {
	            	 if(RandomUtil.isMobileValid(contactNo)) {
	            		 eventAdmin.setAdminContactAddress(contactNo);
	            		 loginMobileNo =  "91"+contactNo;
	            	 }
	             }
	             
	             eventAdmin.setEventAdmin(eventMaster);
	             eventAdminRepository.save(eventAdmin);
	             if(eventAdmin.getAdminEmailId()!=null && !eventAdmin.getAdminEmailId().equals("")) {
	 	  	        //Below for Mobile User & Mobile User 
	 		  	    //Finally Enter Record Inside Mobile_User Table & Mobile User Event Table 
	 		  	      MobileUsers mobileUser = new MobileUsers();	
	 		  	      Optional<MobileUsers> optionalMobileUser = mobileUserRepository.findOneByEmailIdIgnoreCase(eventAdmin.getAdminEmailId());
	 		  	      if(optionalMobileUser.isPresent()) {
	 		  	    	  mobileUser = optionalMobileUser.get();
	 		  	      }
	 		  	      mobileUser.setUserMobileNo(loginMobileNo);
	 		  	      mobileUser.setEmail_id(eventAdmin.getAdminEmailId());
	 		  	      mobileUser.setIsAdmin(1);
	 		  	      mobileUser.setUserId(loginId);
	 		  	      mobileUser.setUserName(eventAdmin.getAdminFullName());
	 		  	      mobileUser.setActiveStatus(0);
	 		  	      mobileUserRepository.save(mobileUser);
	 		  	      MobileEventUsers mobileEventUsers = new MobileEventUsers();
	 		  	      Optional<MobileEventUsers> optionalMobileEventUsers = mobileEventUserRepository.findByEventIdAndMobileUserId(eventMaster.getEventId(), mobileUser.getId());
	 		  	      if(optionalMobileEventUsers.isPresent()) {
	 		  	    	  mobileEventUsers = optionalMobileEventUsers.get();
	 		  	      }
	 		  	      mobileEventUsers.setEventId(eventMaster.getEventId());
	 		  	      mobileEventUsers.setMobileUserId(mobileUser.getId());
	 		  	      mobileEventUserRepository.save(mobileEventUsers); 
	          	}
	          } 
	         
	        //For Sheet 5 -- > Event Admin Ends   
	          
	          if(inputStream!=null) {
	        	  inputStream.close();
	          }

 if(inputStream1!=null) {
	        	  inputStream1.close();
	          }
if(inputStream2!=null) {
	        	  inputStream2.close();
	          }
 if(inputStream2_image!=null) {
	        	  inputStream2_image.close();
	          }
if(inputStream3!=null) {
	        	  inputStream3.close();
	          }
 if(inputStream4!=null) {
	        	  inputStream4.close();
	          }
 if(inputStream4_image!=null) {
	        	  inputStream4_image.close();
	          }
 if(inputStream5!=null) {
	        	  inputStream5.close();
	          } 
	         
	          
	    	
	    	
	    }catch (Exception e) {
			e.printStackTrace();
		}
	    
	    
    	
	}

}
