package com.iftas.eventportal.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iftas.eventportal.dao.ProductMasterRepository;
import com.iftas.eventportal.entity.ProductMaster;

@Service
@Transactional
public class ProductService {

	@Autowired
	private ProductMasterRepository productMasterRepository;
	
	public List<ProductMaster> getProductList() {
		return productMasterRepository.findAll();
	}

}
