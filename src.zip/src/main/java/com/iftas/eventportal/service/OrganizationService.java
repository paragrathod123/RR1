package com.iftas.eventportal.service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.iftas.eventportal.dao.OrganizationRepository;
import com.iftas.eventportal.entity.Organization;

@Service
@Transactional
public class OrganizationService {

	@Autowired
	private OrganizationRepository organizationdao;
	
	public List<Organization> getOrganizationList(){
		return organizationdao.findAll();
	}
	
	public Organization getOrganizatiobById(Long id) {
		return organizationdao.findById(id).get();
	}
	
	public Organization createOrganization(Organization theOrganization, HttpServletRequest request) {
		Organization organization = new Organization();
		HttpSession session =  request.getSession();
		organization.setOrganizationName(theOrganization.getOrganizationName());
		organization.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
		organization.setCreatedDate(Instant.now());
		organization.setModifiedBy(0);
		organization.setActiveStatus(theOrganization.getActiveStatus());
		organizationdao.save(organization);
		return organization;
	}
	
	public Organization updateOrganization(Organization theOrganization, HttpServletRequest request) {
		Optional<Organization>organizations = organizationdao.findById(theOrganization.getOrganizationId());
		Organization organization = new Organization();
		HttpSession session =  request.getSession();
		organization = organizations.get();
		organization.setOrganizationName(theOrganization.getOrganizationName());
		organization.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
		organization.setModifiedDate(Instant.now());
		organization.setActiveStatus(theOrganization.getActiveStatus());
		organizationdao.save(organization);
		return organization;
	}
}
