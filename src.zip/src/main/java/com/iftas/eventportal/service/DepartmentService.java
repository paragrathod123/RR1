package com.iftas.eventportal.service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iftas.eventportal.dao.DepartmentRepository;
import com.iftas.eventportal.entity.Department;


@Service
@Transactional
public class DepartmentService {

	@Autowired
	DepartmentRepository departmentRepository;
	
	public List<Department> getDepartmentListing(){
		return departmentRepository.findAll();
	}
	
	public List<Department> getDepartmentListingByActiveStatus(int activeStatus){
		return departmentRepository.findAllByActiveStatusOrderByDepartmentNameAsc(activeStatus);
	}
	
	public Department getDepartmentById(Long departmentId) {
		return departmentRepository.findById(departmentId).get();
	}
	
	public Department createDepartment(Department theDepartment, HttpServletRequest request) {
		Department department = new Department();
		HttpSession session =  request.getSession();
		department.setDepartmentCode(theDepartment.getDepartmentCode());
		department.setDepartmentName(theDepartment.getDepartmentName());
		department.setModifiedBy(0);
		department.setActiveStatus(theDepartment.getActiveStatus());
		department.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
		department.setCreatedDate(Instant.now());
		departmentRepository.save(department);
		return department;
	}
	
	
  public Department updateDepartment(Department theDepartment,  HttpServletRequest request) {
	        HttpSession session =  request.getSession();
			Optional<Department> departments = departmentRepository.findById(theDepartment.getDepartmentId());
			Department department =  departments.get();
			department.setDepartmentCode(theDepartment.getDepartmentCode());
			department.setDepartmentName(theDepartment.getDepartmentName());
			department.setActiveStatus(theDepartment.getActiveStatus());
			department.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
			department.setModifiedDate(Instant.now());
			departmentRepository.save(department);
			return department;
		
	}
	public void deleteDepartmentById(Long departmentId) {
			departmentRepository.deleteById(departmentId);
	}
}
