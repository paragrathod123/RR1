package com.iftas.eventportal.service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iftas.eventportal.dao.DesignationRepository;
import com.iftas.eventportal.entity.Designation;

@Service
@Transactional
public class DesignationService {

	@Autowired
	DesignationRepository designationRepository;
	
	public List<Designation> getDesignationListing(){
		return designationRepository.findAll();
	}
	
	public Designation getDesignationById(Long designationId) {
		return designationRepository.findById(designationId).get();
	}
	
	public Designation createDesignation(Designation theDesignation, HttpServletRequest request) {
		HttpSession session =  request.getSession();
		Designation designation = new Designation();
		designation.setDesignationName(theDesignation.getDesignationName());
		designation.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
		designation.setCreatedDate(Instant.now());
		designation.setModifiedBy(0);
		designation.setActiveStatus(theDesignation.getActiveStatus());
		designationRepository.save(designation);
		return designation;
	}
	
	
  public Designation updateDesignation(Designation theDesignation,  HttpServletRequest request) {
	  	    HttpSession session =  request.getSession();
			Optional<Designation> designations = designationRepository.findById(theDesignation.getDesignationId());
			Designation designation =  designations.get();
			designation.setDesignationName(theDesignation.getDesignationName());
			designation.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
			designation.setModifiedDate(Instant.now());
			designation.setActiveStatus(theDesignation.getActiveStatus());
			designationRepository.save(designation);
			return designation;
		
	}
	public void deleteDesignationById(Long designationId) {
		designationRepository.deleteById(designationId);
	}
}
