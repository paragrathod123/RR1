package com.iftas.eventportal.service;

import java.io.File;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iftas.eventportal.dao.MenuRepository;
import com.iftas.eventportal.dao.PageRepository;
import com.iftas.eventportal.dao.ProcessRepository;
import com.iftas.eventportal.dao.RoleRepository;
import com.iftas.eventportal.entity.MenuMaster;
import com.iftas.eventportal.entity.PageMst;
import com.iftas.eventportal.entity.Privileges;
import com.iftas.eventportal.entity.RoleMst;



@Service
@Transactional
public class RoleService {

	@Autowired
	private PageRepository pageRepository;
	
	@Autowired
	private ProcessRepository processRepository;
	
	@Autowired
	private EntityManager entityManager;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private MenuRepository menuRepository;
	
	public List<RoleMst> getRoleListing(){
		return roleRepository.findAll();
	}
	
	public RoleMst createRole(RoleMst theRole, HttpServletRequest request) {
		HttpSession session =  request.getSession();
        List<Privileges> privilegeList = new ArrayList<Privileges>();
		entityManager.createQuery("delete from Privileges pre where pre.role.roleId = :id")
		  .setParameter("id", theRole.getRoleId())
		  .executeUpdate();
		
		Privileges privilegesTemp = null;
		Map<Long, List<Integer>> pageAndPrivilgesMap =  new HashMap<Long, List<Integer>>();
		List<Integer> privilege = new ArrayList<Integer>();
		
		
		String[] values=request.getParameterValues("pageId");
		for(int i=0;i<values.length;i++)
	    {
			System.out.println("Page Values is "+values[i]);
			//Parsing Format 1_1 i.e pageId _privilegesType
			String[] pageAndPrivilegesType  =values[i].split("_");
			//Get First Param pageId
			Long pageId =  Long.parseLong(pageAndPrivilegesType[0]);
			//Get Second Param privilegesType
			int privilegetype =  Integer.parseInt(pageAndPrivilegesType[1]);
			System.out.println("pageId  "+pageId);
			System.out.println("privilegetype  "+privilegetype);
			privilege = new ArrayList<Integer>();
			//Fresh
			if(!pageAndPrivilgesMap.containsKey(pageId)) {
				
				privilege.add(privilegetype);
				pageAndPrivilgesMap.put(pageId, privilege);
				
			}else if(pageAndPrivilgesMap.containsKey(pageId)) {
				
				privilege =   pageAndPrivilgesMap.get(pageId);
				privilege.add(privilegetype);
				pageAndPrivilgesMap.put(pageId, privilege);
				
			}
			
	    }
		
		//Iterate Map
		for (Entry<Long, List<Integer>> entry : pageAndPrivilgesMap.entrySet()) {
		    
			privilegesTemp = new Privileges();
			privilegesTemp.setPagePrivilages(pageRepository.findById(entry.getKey()).get());
			privilegesTemp.setRole(theRole);
			privilege = new ArrayList<Integer>();
			System.out.println("entry.getValue()  "+entry.getValue());
			privilege =  entry.getValue();
			for (Integer temp : privilege) {
				if(temp == 1 ) {
					privilegesTemp.setReadPrivilage(1);
				}
				if(temp == 2) {
					privilegesTemp.setAddPrivilage(1);
				}
				if(temp == 4) {
					privilegesTemp.setExportPrivilage(1);
				}
				if(temp == 3) {
					privilegesTemp.setUpdatePrivilage(1);
				}
			}
			
			privilegeList.add(privilegesTemp);
		}
		
		if(privilegeList.size()>0) {
			theRole.setPrivileges(privilegeList);
		}

		theRole.setRoleName(theRole.getRoleName());
		theRole.setActiveStatus(theRole.getActiveStatus());
		theRole.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
		theRole.setCreatedDate(Instant.now());
		roleRepository.save(theRole);
		
		//Below Code for Saving Roles Data
		if(theRole.getRoleId() > 0L) {
			try {
				createOrUpdateRoleFile(theRole,(String)session.getAttribute("pathUrl"));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		return theRole;
	}
	
	public RoleMst getRoleDetail(Long Id) {
		return roleRepository.findById(Id).get();
	}
	
	public RoleMst updateRole(RoleMst theRole, HttpServletRequest request) {
		HttpSession session =  request.getSession();
        List<Privileges> privilegeList = new ArrayList<Privileges>();
		Optional<RoleMst> roles = roleRepository.findById(theRole.getRoleId());
		RoleMst role = roles.get();
		entityManager.createQuery("delete from Privileges pre where pre.role.roleId = :id")
		  .setParameter("id", theRole.getRoleId())
		  .executeUpdate();
		
		
		Privileges privilegesTemp = null;
		Map<Long, List<Integer>> pageAndPrivilgesMap =  new HashMap<Long, List<Integer>>();
		List<Integer> privilege = new ArrayList<Integer>();
		
		
		String[] values=request.getParameterValues("pageId");
		for(int i=0;i<values.length;i++)
	    {
			System.out.println("Page Values is "+values[i]);
			//Parsing Format 1_1 i.e pageId _privilegesType
			String[] pageAndPrivilegesType  =values[i].split("_");
			//Get First Param pageId
			Long pageId =  Long.parseLong(pageAndPrivilegesType[0]);
			//Get Second Param privilegesType
			int privilegetype =  Integer.parseInt(pageAndPrivilegesType[1]);
			System.out.println("pageId  "+pageId);
			System.out.println("privilegetype  "+privilegetype);
			privilege = new ArrayList<Integer>();
			//Fresh
			if(!pageAndPrivilgesMap.containsKey(pageId)) {
				
				privilege.add(privilegetype);
				pageAndPrivilgesMap.put(pageId, privilege);
				
			}else if(pageAndPrivilgesMap.containsKey(pageId)) {
				
				privilege =   pageAndPrivilgesMap.get(pageId);
				privilege.add(privilegetype);
				pageAndPrivilgesMap.put(pageId, privilege);
				
			}
			
	    }
		
		//Iterate Map
		for (Entry<Long, List<Integer>> entry : pageAndPrivilgesMap.entrySet()) {
		    
			privilegesTemp = new Privileges();
			privilegesTemp.setPagePrivilages(pageRepository.findById(entry.getKey()).get());
			privilegesTemp.setRole(role);
			privilege = new ArrayList<Integer>();
			System.out.println("entry.getValue()  "+entry.getValue());
			privilege =  entry.getValue();
			for (Integer temp : privilege) {
				if(temp == 1 ) {
					privilegesTemp.setReadPrivilage(1);
				}
				if(temp == 2) {
					privilegesTemp.setAddPrivilage(1);
				}
				if(temp == 4) {
					privilegesTemp.setExportPrivilage(1);
				}
				if(temp == 3) {
					privilegesTemp.setUpdatePrivilage(1);
				}
			}
			
			privilegeList.add(privilegesTemp);
		}
		
		if(privilegeList.size()>0) {
			role.setPrivileges(privilegeList);
		}

		role.setRoleName(theRole.getRoleName());
		role.setActiveStatus(theRole.getActiveStatus());
		role.setModifiedBy(((Long)session.getAttribute("userId")).intValue());
		role.setModifiedDate(Instant.now());
		roleRepository.save(role);
		
		//Below Code for Saving Roles Data
		if(theRole.getRoleId() > 0L) {
			try {
				createOrUpdateRoleFile(role,(String)session.getAttribute("pathUrl"));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return role;
	}
	
     public void createOrUpdateRoleFile(RoleMst theRole,String pathUrl) throws Exception {
		
		//Get Menu & Remove Duplicate
		
		List<MenuMaster> menuList = new ArrayList<MenuMaster>();
		List<PageMst> pageList = new ArrayList<PageMst>();
		//For Getting Menus 
		String strQuery ="Select distinct  menu.menuid from privileges priv,pagemst pages,menumst menu where priv.pageid=pages.pageid  and menu.menuid =  pages.menuid and  priv.roleid = "+theRole.getRoleId();
	    Query query = entityManager.createNativeQuery(strQuery);
	    List<Integer> menusList = query.getResultList();
		for (Integer menuId : menusList) {
				MenuMaster menus =  menuRepository.findByMenuId(Long.valueOf(menuId)).get();
				
				//For Getting Pages 
				pageList = new ArrayList<PageMst>();
				strQuery ="Select distinct  priv.pageid from privileges priv,pagemst pages,menumst menu where priv.pageid=pages.pageid  and menu.menuid =  pages.menuid and  priv.roleid = "+theRole.getRoleId() + " and  menu.menuid = "+menuId+" and priv.is_Read=1";
				Query query1 = entityManager.createNativeQuery(strQuery);
				List<Integer> pagesList = query1.getResultList();
				for (Integer pageId : pagesList) {
					PageMst page = pageRepository.findById(Long.valueOf(pageId)).get();
					pageList.add(page);
				}
				//Finally Add This Page List to Menu List
				menus.setPages(pageList);
				
				menuList.add(menus);
		}
		
		 
		
		
		
		
		
	    
		//Get File
		String filePath =pathUrl;
		try {
			ObjectMapper object =  new ObjectMapper();
			System.out.println(filePath.trim()+"/Roles/" +"/Role_"+theRole.getRoleId()+".json");
			File file = new File(filePath.trim()+"/Roles/" +"/Role_"+theRole.getRoleId()+".json");
			if(!file.exists()) {
				file.createNewFile();
			}
			object.writeValue(file, menuList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
}
}