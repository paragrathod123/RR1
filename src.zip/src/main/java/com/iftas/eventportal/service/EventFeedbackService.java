package com.iftas.eventportal.service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iftas.eventportal.dao.EventfeedbackRepository;
import com.iftas.eventportal.entity.EventFeedbackReport;
import com.iftas.eventportal.entity.EventSessionFeedback;
@Service
public class EventFeedbackService {

	@Autowired 
	private EventfeedbackRepository eventfeedbackRepo;
	
	
	public List<EventFeedbackReport> getFeedbackReport(EventSessionFeedback eventFeedback, HttpServletRequest request) {
		List<EventFeedbackReport> eventFeedbackReport = new ArrayList<EventFeedbackReport>();
		eventFeedbackReport = eventfeedbackRepo.getFeedbackReport(eventFeedback);
		return eventFeedbackReport;
	}

}
