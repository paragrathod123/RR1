package com.iftas.eventportal.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iftas.eventportal.entity.CommonSetup;

public interface CommonSetupRepository extends JpaRepository<CommonSetup, Long> {

	List<CommonSetup> findAllByActiveStatus(int activeStatus);
}
