package com.iftas.eventportal.dao;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.iftas.eventportal.dto.events;
import com.iftas.eventportal.entity.EventSessionRef;

public interface EventSessionRepository extends JpaRepository<EventSessionRef, Long>{

	
	@Query("SELECT eventSessionData FROM EventSessionRef eventSessionData  WHERE  (eventSessionData.eventSessions.eventId = ?1  OR ?1='')  ORDER BY eventSessionData.sessionId ")
	List<EventSessionRef> findAllByEventId(Long id);
	
	@Query("SELECT eventSessionData FROM EventSessionRef eventSessionData  WHERE  (eventSessionData.eventSessions.eventId = ?1  OR ?1='') and (eventSessionData.eventDate = ?2  OR ?2='') and (eventSessionData.sessionStartTime = ?3  OR ?3='')   ORDER BY eventSessionData.sessionId ")
	Optional<EventSessionRef> findByCombinationOfEventDateTimeAndEventId(Long id,String eventDate , String eventTime );

	
	@Query(nativeQuery = true)	
	List<events> getCalenderDashboardForGivenParameter(String id);
	
	@Transactional
	@Modifying
	@Query("DELETE FROM EventSessionRef eventSessionData  WHERE  (eventSessionData.eventSessions.eventId = ?1  OR ?1='') ")
	void deleteAllByEventId(Long id);
}
