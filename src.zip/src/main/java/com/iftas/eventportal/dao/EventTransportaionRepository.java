package com.iftas.eventportal.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.iftas.eventportal.entity.EventAdmin;
import com.iftas.eventportal.entity.EventTransportaion;

public interface EventTransportaionRepository extends JpaRepository<EventTransportaion, Long> {

	

	@Query("SELECT eventTransportDetail FROM EventTransportaion eventTransportDetail  WHERE  (eventTransportDetail.eventTransport.eventId = ?1  OR ?1='')  ORDER BY eventTransportDetail.id ")
	List<EventTransportaion> findAllByEventId(Long id);
	
}
