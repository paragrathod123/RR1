package com.iftas.eventportal.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iftas.eventportal.entity.ProcessMst;
@Repository
public interface ProcessRepository extends JpaRepository<ProcessMst, Long> {

}
