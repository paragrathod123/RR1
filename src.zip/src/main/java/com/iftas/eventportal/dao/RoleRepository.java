package com.iftas.eventportal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.iftas.eventportal.entity.RoleMst;
@Repository
public interface RoleRepository extends JpaRepository<RoleMst, Long> {

	List<RoleMst> findAllByActiveStatus(int activeStatus);
	
	Optional<RoleMst> findByRoleName(String roleName);
	
	@Query("SELECT role FROM RoleMst role  WHERE (role.activeStatus = ?1  OR ?1='')  and role.roleId=1 ORDER BY role.roleId ")
	List<RoleMst> findAllMasterRole(int activeStatus);
	
	
	@Query("SELECT role FROM RoleMst role  WHERE (role.activeStatus = ?1  OR ?1='')  and role.roleId!=1 ORDER BY role.roleId ")
	List<RoleMst> findAllAdminRole(int activeStatus);
	
	
	
}
