package com.iftas.eventportal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iftas.eventportal.entity.Centres;
import com.iftas.eventportal.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long>{

	Optional<Department> findByDepartmentCode(String departmentCode);
	
	Optional<Department> findByDepartmentName(String departmentName);
	
	Optional<Department> findByDepartmentNameIgnoreCase(String departmentName);
	
	List<Department> findAllByActiveStatusOrderByDepartmentNameAsc(int activeStatus);
	
 }
