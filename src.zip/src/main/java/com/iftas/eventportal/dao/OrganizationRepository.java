package com.iftas.eventportal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.iftas.eventportal.entity.Organization;

public interface OrganizationRepository extends JpaRepository<Organization, Long>{
	
	Optional<Organization> findByOrganizationNameIgnoreCase(String organizationName);
	
	List<Organization> findAllByActiveStatus(int activeStatus);
	
	List<Organization> findAllByActiveStatusOrderByOrganizationNameAsc(int activeStatus);

}
