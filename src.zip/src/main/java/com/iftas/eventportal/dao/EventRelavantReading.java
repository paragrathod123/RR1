package com.iftas.eventportal.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iftas.eventportal.entity.RelavantReading;

public interface EventRelavantReading extends JpaRepository<RelavantReading, Long> {

}
