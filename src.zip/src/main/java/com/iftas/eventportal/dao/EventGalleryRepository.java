package com.iftas.eventportal.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.iftas.eventportal.entity.EventGallery;

public interface EventGalleryRepository extends JpaRepository<EventGallery, Long> {

	
	@Query("SELECT event FROM EventGallery event  WHERE  (event.eventGallery.eventId = ?1  OR ?1='')  ORDER BY event.id ")
	List<EventGallery> findAllByEventId(Long id);
	
}
