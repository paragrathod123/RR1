package com.iftas.eventportal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iftas.eventportal.entity.Department;
import com.iftas.eventportal.entity.ParticipantMaster;
import com.iftas.eventportal.entity.SpeakerMaster;

public interface SpeakersRepository extends JpaRepository<SpeakerMaster, Long> {
	
	Optional<SpeakerMaster> findOneBySpeakerEmailIdIgnoreCase(String email);
	
	List<SpeakerMaster> findAllByActiveStatusOrderBySpeakerFirstNameAsc(int activeStatus);
	
	List<SpeakerMaster> findAllByOrderBySpeakerFirstNameAsc();

	//List<SpeakerMaster> findByNameOrderByNameAsc(String name);
	
	List<SpeakerMaster> findAllBySpeakerFirstName(String speakerFirstName);
	
}
