package com.iftas.eventportal.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iftas.eventportal.entity.ContactUsSetup;

public interface ContactUsSetupRepository extends JpaRepository<ContactUsSetup, Long>{

	List<ContactUsSetup> findAllByActiveStatus(int activeStatus);
}
