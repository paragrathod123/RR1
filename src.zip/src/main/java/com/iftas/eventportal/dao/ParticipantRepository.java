package com.iftas.eventportal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iftas.eventportal.entity.ParticipantMaster;
import com.iftas.eventportal.entity.SpeakerMaster;

public interface ParticipantRepository extends JpaRepository<ParticipantMaster, Long>{

	
	Optional<ParticipantMaster> findOneByParticipantEmailIdIgnoreCase(String email);
	
	List<ParticipantMaster> findAllByActiveStatus(int activeStatus);
	
	List<ParticipantMaster> findAllByOrderByParticipantFirstNameAsc();
	
	List<ParticipantMaster> findAllByParticipantFirstName(String participantFirstName);
	
}
