package com.iftas.eventportal.dao;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.iftas.eventportal.entity.EventAdmin;

public interface EventAdminRepository extends JpaRepository<EventAdmin, Long>{

	
	@Query("SELECT eventAdminDetail FROM EventAdmin eventAdminDetail  WHERE  (eventAdminDetail.eventAdmin.eventId = ?1  OR ?1='')  ORDER BY eventAdminDetail.id ")
	List<EventAdmin> findAllByEventId(Long id);

	@Query("SELECT eventAdminDetail FROM EventAdmin eventAdminDetail  WHERE  (eventAdminDetail.eventAdmin.eventId = ?1  OR ?1='') and (eventAdminDetail.adminEmailId = ?2  OR ?2='')  ORDER BY eventAdminDetail.id ")
	Optional<EventAdmin> findAllByEventIdAndMail(Long id,String emailId);
	
	@Transactional
	@Modifying
	@Query("Delete FROM EventAdmin eventAdminDetail  WHERE  (eventAdminDetail.eventAdmin.eventId = ?1  OR ?1='') ")
	void deleteAllByEventId(Long id);
}
