package com.iftas.eventportal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.iftas.eventportal.entity.Centres;


public interface CentreRepository extends JpaRepository<Centres, Long> {
	
	
	Optional<Centres> findByCentreName(String centerName);

	List<Centres> findAllByActiveStatusOrderByCentreNameAsc(int activeStatus);
}
