package com.iftas.eventportal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iftas.eventportal.entity.Centres;
import com.iftas.eventportal.entity.Designation;

public interface DesignationRepository extends JpaRepository<Designation, Long> {
	
	Optional<Designation> findByDesignationNameIgnoreCase(String designationName);
	
	List<Designation> findAllByActiveStatus(int activeStatus);
	
	List<Designation> findAllByActiveStatusOrderByDesignationNameAsc(int activeStatus);
}
