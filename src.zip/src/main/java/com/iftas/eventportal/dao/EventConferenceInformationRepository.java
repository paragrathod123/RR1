package com.iftas.eventportal.dao;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.iftas.eventportal.entity.EventConferenceInformation;
import com.iftas.eventportal.entity.EventMaster;

public interface EventConferenceInformationRepository extends JpaRepository<EventConferenceInformation, Long> {

	//@Query("SELECT eventConfDetail FROM EventConferenceInformation eventConfDetail  WHERE  (eventConfDetail.evenConferenceInfo.eventId = ?1  OR ?1='') ")
	@Query("SELECT ef FROM EventConferenceInformation ef WHERE ef.evenConferenceInfo.eventId = ?1")
	Optional<EventConferenceInformation> evenConferenceInfobyEventId(Long eventId);
	
	@Transactional
	@Modifying
	@Query("DELETE FROM EventConferenceInformation ef WHERE ef.evenConferenceInfo.eventId = ?1")
	void deleteFromEvenConferenceInfobyEventId(Long eventId);

}
