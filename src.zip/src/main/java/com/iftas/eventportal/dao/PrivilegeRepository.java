package com.iftas.eventportal.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iftas.eventportal.entity.Privileges;

public interface PrivilegeRepository extends JpaRepository<Privileges, Long> {

}
