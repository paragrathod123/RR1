package com.iftas.eventportal.dao;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.iftas.eventportal.entity.EventParticipants;
import com.iftas.eventportal.entity.EventSpeakers;
import com.iftas.eventportal.entity.ParticipantMaster;


public interface EventParticipantRepository extends JpaRepository<EventParticipants, Long>{
	
	
	//List<EventParticipants> findByEventParticipantsByEventParticipantId(EventMaster eventId);
	@Query("SELECT eventParticipant FROM EventParticipants eventParticipant  WHERE  (eventParticipant.eventParticipants.eventId = ?1  OR ?1='')  ORDER BY eventParticipant.eventParticipantId ")
	List<EventParticipants> findAllByEventId(Long paramString2);

	@Query("SELECT event.eventParticipant FROM EventParticipants event  WHERE  (event.eventParticipants.eventId = ?1  OR ?1='')  ORDER BY event.eventParticipantId ")
	List<ParticipantMaster> findAllParticipantByEventId(Long id);
	
	@Query("SELECT event FROM EventParticipants event  WHERE  (event.eventParticipants.eventId = ?1  OR ?1='') and (event.eventParticipant.participantId = ?2  OR ?2='')  ORDER BY event.eventParticipantId ")
	Optional<EventParticipants> findByParticipantAndEventId(Long eventId , Long participant);
	
	@Transactional
	@Modifying
	@Query("DELETE FROM EventParticipants event  WHERE  (event.eventParticipants.eventId = ?1  OR ?1='') ")
	void deleteAllParticipantByEventId(Long id);
	
	
}
