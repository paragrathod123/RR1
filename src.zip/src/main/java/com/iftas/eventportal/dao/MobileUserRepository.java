package com.iftas.eventportal.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.iftas.eventportal.entity.MobileUsers;
import com.iftas.eventportal.entity.SpeakerMaster;

public interface MobileUserRepository extends JpaRepository<MobileUsers, Long>{
	
	
	@Query("SELECT mobileUsers FROM MobileUsers mobileUsers  WHERE  (mobileUsers.userType = ?1  OR ?1='') and (mobileUsers.userTypeId = ?2  OR ?2='')  ORDER BY mobileUsers.id ")
	Optional<MobileUsers> findByTypeAndTypeId(Integer userType , Integer userTypeId);
	
	
	Optional<MobileUsers> findOneByUserIdIgnoreCase(String userId);
	
	
	Optional<MobileUsers> findOneByEmailIdIgnoreCase(String email);
	
}
