package com.iftas.eventportal.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iftas.eventportal.entity.MenuMaster;

@Repository
public interface MenuRepository extends JpaRepository<MenuMaster, Long>{
	Optional<MenuMaster> findByMenuId(Long Id);
}
