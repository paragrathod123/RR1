package com.iftas.eventportal.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.iftas.eventportal.entity.EventFeedbackReport;
import com.iftas.eventportal.entity.EventSessionFeedback;

@Repository

/*
 * @SqlResultSetMapping(name="eventFeedbackList", entities={
 * 
 * @EntityResult(entityClass=EventFeedbackReport.class, fields={
 * 
 * @FieldResult(name="departmentName", column="department_name"),
 * 
 * @FieldResult(name="eventName", column="event_name"),
 * 
 * @FieldResult(name="SessionName", column="session_name"),
 * 
 * @FieldResult(name="speakerName", column="speaker_name"),
 * 
 * @FieldResult(name="RatingName", column="rating_name"),
 * 
 * @FieldResult(name="eventDate", column="event_date"),
 * 
 * @FieldResult(name="userName", column="user_name")})
 * 
 * 
 * })
 */

public class EventfeedbackRepository {

	@Autowired
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<EventFeedbackReport> getFeedbackReport(EventSessionFeedback eventFeedback) {
		// TODO Auto-generated method stub
		
		System.out.println("-->"+eventFeedback.getDepartmentId());
		System.out.println(eventFeedback.getEventId());
		System.out.println(eventFeedback.getRatingName());
		System.out.println(eventFeedback.getSpeakerId());
		//System.out.println(eventFeedback.getEventId());
		
		List<EventFeedbackReport> eventFeedbackReportList = new ArrayList<EventFeedbackReport>();
		 String queryString = "call event_Feedback_list_SP(?,?,?,?)";
	     
	     //this.entityManager.createNativeQuery(queryString ,"TestQueryResultMapping").getResultList();
		 
		 javax.persistence.Query query = this.entityManager.createNativeQuery(queryString ,"eventFeedbackList")
				 						.setParameter(1, eventFeedback.getDepartmentId())
				 						.setParameter(2, eventFeedback.getEventId())
				 						.setParameter(3, eventFeedback.getRatingName())
				 						.setParameter(4, eventFeedback.getSpeakerId())
				 ;
		 //Query query = entityManager.createNativeQuery("{call event_Feedback_list_SP(?,?)}",
             //    EmployeeDetails.class)           
              //   .setParameter(1, employeeId)
               //  .setParameter(2, companyId);

		 eventFeedbackReportList = query.getResultList();
		 System.out.println(eventFeedbackReportList.size());
		 
		 return eventFeedbackReportList;
		 
	}

}
