package com.iftas.eventportal.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iftas.eventportal.entity.UserLoggedActivity;

public interface UserLoggedActivityRepository extends JpaRepository<UserLoggedActivity, Long> {
	
	List<UserLoggedActivity> findByUserIdOrderByUserLoginDetailsIdDesc(Integer userId);
 
}
