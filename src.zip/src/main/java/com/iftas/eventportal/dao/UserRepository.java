package com.iftas.eventportal.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iftas.eventportal.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	
	
	Optional<User> findOneByEmailIgnoreCase(String email);

    Optional<User> findOneByLogin(String login);
    
    Optional<User> findOneByResetKey(String resetKey);


    
    

}
