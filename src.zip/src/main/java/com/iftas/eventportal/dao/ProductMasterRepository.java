package com.iftas.eventportal.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iftas.eventportal.entity.ProductMaster;

public interface ProductMasterRepository extends JpaRepository<ProductMaster, Long> {

	Optional<ProductMaster> findByProductNameIgnoreCase(String eventType);

}
