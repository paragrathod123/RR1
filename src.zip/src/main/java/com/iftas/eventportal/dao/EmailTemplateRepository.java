package com.iftas.eventportal.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.iftas.eventportal.entity.EmailTemplate;

public interface EmailTemplateRepository extends JpaRepository<EmailTemplate, Long> {

	List<EmailTemplate> findAllByActiveStatus(int activeStatus);
}
