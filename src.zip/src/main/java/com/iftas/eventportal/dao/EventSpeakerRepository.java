package com.iftas.eventportal.dao;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.iftas.eventportal.entity.EventSpeakers;
import com.iftas.eventportal.entity.SpeakerMaster;

public interface EventSpeakerRepository extends JpaRepository<EventSpeakers, Long> {

	Optional<EventSpeakers> findByEventSpeakers(Long eventId);

	@Query("SELECT eventSpeakerData FROM EventSpeakers eventSpeakerData  WHERE  (eventSpeakerData.eventSpeakers.eventId = ?1  OR ?1='')  ORDER BY eventSpeakerData.eventSpeakerId ")
	List<EventSpeakers> findAllByEventId(Long id);
	
	@Query("SELECT eventSpeakerData.eventSpeaker FROM EventSpeakers eventSpeakerData  WHERE  (eventSpeakerData.eventSpeakers.eventId = ?1  OR ?1='')  ORDER BY eventSpeakerData.eventSpeaker.speakerFirstName ")
	List<SpeakerMaster> findAllSpeakerByEventId(Long id);
	
	@Query("SELECT eventSpeakerData FROM EventSpeakers eventSpeakerData  WHERE  (eventSpeakerData.eventSpeakers.eventId = ?1  OR ?1='') and (eventSpeakerData.eventSpeaker.speakerId = ?2  OR ?2='')  ORDER BY eventSpeakerData.eventSpeakerId ")
	Optional<EventSpeakers> findBySpeakerAndEventId(Long eventId , Long speakerId);
	
	@Transactional
	@Modifying
	@Query("DELETE  FROM EventSpeakers eventSpeakerData  WHERE  (eventSpeakerData.eventSpeakers.eventId = ?1  OR ?1='')")
	void deleteAllSpeakerByEventId(Long id);
}
