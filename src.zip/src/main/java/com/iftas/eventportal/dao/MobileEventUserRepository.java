package com.iftas.eventportal.dao;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.iftas.eventportal.entity.MobileEventUsers;
import com.iftas.eventportal.entity.MobileUsers;

public interface MobileEventUserRepository extends JpaRepository<MobileEventUsers, Long> {

	@Query("SELECT mobileEventUsers FROM MobileEventUsers mobileEventUsers  WHERE  (mobileEventUsers.eventId = ?1  OR ?1='') and (mobileEventUsers.mobileUserId = ?2  OR ?2='')  ORDER BY mobileEventUsers.id ")
	Optional<MobileEventUsers> findByEventIdAndMobileUserId(Long eventId , Long mobileUserId);
	
	@Query("SELECT mobileEventUsers FROM MobileEventUsers mobileEventUsers  WHERE  (mobileEventUsers.eventId = ?1  OR ?1='') ORDER BY mobileEventUsers.id ")
	List<MobileEventUsers> findByEventId(Long eventId);
	
	@Transactional
	@Modifying
	@Query("DELETE FROM MobileEventUsers mobileEventUsers  WHERE  (mobileEventUsers.eventId = ?1  OR ?1='')  ")
	void deleteByEventId(Long eventId);
	
	
	
}
