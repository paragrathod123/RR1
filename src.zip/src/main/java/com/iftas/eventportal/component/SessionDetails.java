package com.iftas.eventportal.component;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

@Component
@Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SessionDetails {

	private Long userId;
	private String userName;
	private String firstName;
	private String lastName;
	private int failure;
	private int enabled;
	private int anotherSession;
	
	
	
	private int markerType;
	private String markerTypeString;
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getFailure() {
		return failure;
	}
	public void setFailure(int failure) {
		this.failure = failure;
	}
	public int getEnabled() {
		return enabled;
	}
	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}
	public int getAnotherSession() {
		return anotherSession;
	}
	public void setAnotherSession(int anotherSession) {
		this.anotherSession = anotherSession;
	}
	public int getMarkerType() {
		return markerType;
	}
	public void setMarkerType(int markerType) {
		this.markerType = markerType;
	}
	public String getMarkerTypeString() {
		return markerTypeString;
	}
	public void setMarkerTypeString(String markerTypeString) {
		this.markerTypeString = markerTypeString;
	}
	
	
}
