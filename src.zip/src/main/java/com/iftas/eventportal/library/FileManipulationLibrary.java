package com.iftas.eventportal.library;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class FileManipulationLibrary {
	public static Properties readPropertyFile(String path) throws IOException {
	    Properties returnValue = new Properties();
	    System.out.println("path "+path);
	    FileInputStream file = new FileInputStream(path);
	    
	    returnValue.load(file);
	    file.close();
	    
	    return returnValue;
	  }
	  
	  public static void checkAndCreateDirectory(String directoryLocation) {
	    File directory = new File(directoryLocation);
	    if (!directory.exists()) {
	      directory.mkdir();
	    }
	  }

	  
	  public static void writeFile(String location, String content) throws IOException {
	    @SuppressWarnings("resource")
		FileWriter file = new FileWriter(location, true);
	    file.write(content);
	    file.flush();
	  }
	  
	  public static String readFile(String location) {
	    Path path = Paths.get(location, new String[0]);
	    List<String> fileContent = new ArrayList<String>();    
	    try {
	      fileContent = Files.readAllLines(path);
	    } catch (IOException iOException) {}

	    return fileContent.toString();
	  }
}
