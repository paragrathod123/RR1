package com.iftas.eventportal;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.iftas.eventportal.entity.MenuMaster;
import com.iftas.eventportal.entity.PageMst;



public class JsonDemo {

	public static void main(String[] args) throws JsonGenerationException, JsonMappingException, FileNotFoundException, IOException  {
		// TODO Auto-generated method stub
ObjectMapper object =  new ObjectMapper();
		
		
		
		
		//read json file data to String
		byte[] jsonData = Files.readAllBytes(Paths.get("D:\\DevelopmentEvent\\UploadFiles\\Roles\\Role_2.json"));
		
		//create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();
		
		//convert json string to object
		List<MenuMaster> emp = object.reader()
				.forType(new TypeReference<List<MenuMaster>>() {})
				.readValue(jsonData);
				
				
		System.out.println("Employee Object\n"+emp.get(0).getName());

	}
public static MenuMaster getMenuMaster() {
		
		MenuMaster menu = new MenuMaster();
		List<PageMst> pd = new ArrayList<PageMst>();
		
		PageMst page = new PageMst();
		page.setPageId(1L);
		page.setActiveStatus(0);
		page.setName("Role Rights");
		page.setPageUrl("/systemAdmin/roles");
		page.setPageTagName("roles");
		
		pd.add(page);
		
		page = new PageMst();
		page.setPageId(2L);
		page.setActiveStatus(0);
		page.setName("User Registration");
		page.setPageUrl("/systemAdmin/users");
		page.setPageTagName("users");
		
        pd.add(page);
		
		page = new PageMst();
		page.setPageId(3L);
		page.setActiveStatus(0);
		page.setName("Common Setup");
		page.setPageUrl("/systemAdmin/commonsetup");
		page.setPageTagName("commonsetup");
		
		pd.add(page);
		
		
		menu.setMenuId(1L);
		menu.setName("System Admin");
		menu.setActiveStatus(0);
		menu.setMenuTagName("systemAdmin");
		menu.setPages(pd);
		
		return menu;
		
		
	}
	
}
