package com.iftas.eventportal.dto;

import java.io.File;
import java.util.List;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.web.multipart.MultipartFile;






public class eventDTO {

	private Long eventId;
	private Long departmentId;
	private String departmentName;
	
	private Long productId;
	private String productName;
	
	private String eventName;
	private String eventPlaceName;
	private String eventStartDate;
	private String eventEndDate;
	private String venueAddress;
	
	
	private String venuePinCode;
	private String venueLatitude;
	private String venueLongitude;
	private String eventInformation ;
	private String eventLocUrl;
	private String eventLocImageName;
	
	private String transportToVenueFolder;
	private String transportToVenueFile;
	private String transportFromVenueFolder;
	private String transportFromVenueFile;
	private String flightToFolder;
	private String flightToFile;
	private String flightFromVenueFolder;
	private String flightFromFile;
	
	private MultipartFile eventLocationImage;
	
	private List<MultipartFile> eventImageGallery;
	
	private String dressCode ;
	private String registrationDetail ;
	private String specialRequirements ;
	private String attendanceTimeTable;
	private String presentations;
	private String transportation;
	private String welcomeMsg ;
	public List<SpeakerDto> speaker ;
	public List<SessionDto> session ;
	public List<ParticipantDto> participant ;
	private List<AdminDto> admin;
	
	private List<MultipartFile> readingMaterialFile;
	
	private List<MultipartFile> transportFile;
	
	public List<MultipartFile> getEventImageGallery() {
		return eventImageGallery;
	}










	public void setEventImageGallery(List<MultipartFile> eventImageGallery) {
		this.eventImageGallery = eventImageGallery;
	}










	public List<MultipartFile> getTransportFile() {
		return transportFile;
	}










	public String getTransportToVenueFolder() {
		return transportToVenueFolder;
	}










	public void setTransportToVenueFolder(String transportToVenueFolder) {
		this.transportToVenueFolder = transportToVenueFolder;
	}










	public String getTransportToVenueFile() {
		return transportToVenueFile;
	}










	public void setTransportToVenueFile(String transportToVenueFile) {
		this.transportToVenueFile = transportToVenueFile;
	}










	public String getTransportFromVenueFolder() {
		return transportFromVenueFolder;
	}










	public void setTransportFromVenueFolder(String transportFromVenueFolder) {
		this.transportFromVenueFolder = transportFromVenueFolder;
	}










	public String getTransportFromVenueFile() {
		return transportFromVenueFile;
	}










	public void setTransportFromVenueFile(String transportFromVenueFile) {
		this.transportFromVenueFile = transportFromVenueFile;
	}










	public String getFlightToFolder() {
		return flightToFolder;
	}










	public void setFlightToFolder(String flightToFolder) {
		this.flightToFolder = flightToFolder;
	}










	public String getFlightToFile() {
		return flightToFile;
	}










	public void setFlightToFile(String flightToFile) {
		this.flightToFile = flightToFile;
	}










	public String getFlightFromVenueFolder() {
		return flightFromVenueFolder;
	}










	public void setFlightFromVenueFolder(String flightFromVenueFolder) {
		this.flightFromVenueFolder = flightFromVenueFolder;
	}










	public String getFlightFromFile() {
		return flightFromFile;
	}










	public void setFlightFromFile(String flightFromFile) {
		this.flightFromFile = flightFromFile;
	}










	public String getEventLocImageName() {
		return eventLocImageName;
	}



	public void setEventLocImageName(String eventLocImageName) {
		this.eventLocImageName = eventLocImageName;
	}




	public String getEventLocUrl() {
		return eventLocUrl;
	}



	public void setEventLocUrl(String eventLocUrl) {
		this.eventLocUrl = eventLocUrl;
	}

	public void setTransportFile(List<MultipartFile> transportFile) {
		this.transportFile = transportFile;
	}



	public eventDTO() {
		
	}

	public String getDepartmentName() {
		return departmentName;
	}



	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}



	public String getProductName() {
		return productName;
	}



	public void setProductName(String productName) {
		this.productName = productName;
	}



	public Long getEventId() {
		return eventId;
	}

	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}

	public Long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventPlaceName() {
		return eventPlaceName;
	}

	public void setEventPlaceName(String eventPlaceName) {
		this.eventPlaceName = eventPlaceName;
	}

	public String getEventStartDate() {
		return eventStartDate;
	}

	public void setEventStartDate(String eventStartDate) {
		this.eventStartDate = eventStartDate;
	}

	public String getEventEndDate() {
		return eventEndDate;
	}

	public void setEventEndDate(String eventEndDate) {
		this.eventEndDate = eventEndDate;
	}

	public String getVenueAddress() {
		return venueAddress;
	}

	public void setVenueAddress(String venueAddress) {
		this.venueAddress = venueAddress;
	}

	public String getVenuePinCode() {
		return venuePinCode;
	}

	public void setVenuePinCode(String venuePinCode) {
		this.venuePinCode = venuePinCode;
	}

	public String getVenueLatitude() {
		return venueLatitude;
	}

	public void setVenueLatitude(String venueLatitude) {
		this.venueLatitude = venueLatitude;
	}

	public String getVenueLongitude() {
		return venueLongitude;
	}

	public void setVenueLongitude(String venueLongitude) {
		this.venueLongitude = venueLongitude;
	}

	
	public MultipartFile getEventLocationImage() {
		return eventLocationImage;
	}

	public void setEventLocationImage(MultipartFile eventLocationImage) {
		this.eventLocationImage = eventLocationImage;
	}



	public List<MultipartFile> getReadingMaterialFile() {
		return readingMaterialFile;
	}


























	public void setReadingMaterialFile(List<MultipartFile> readingMaterialFile) {
		this.readingMaterialFile = readingMaterialFile;
	}


























	public String getEventInformation() {
		return eventInformation;
	}



	public void setEventInformation(String eventInformation) {
		this.eventInformation = eventInformation;
	}



	public String getDressCode() {
		return dressCode;
	}



	public void setDressCode(String dressCode) {
		this.dressCode = dressCode;
	}



	public String getRegistrationDetail() {
		return registrationDetail;
	}



	public void setRegistrationDetail(String registrationDetail) {
		this.registrationDetail = registrationDetail;
	}



	public String getSpecialRequirements() {
		return specialRequirements;
	}



	public void setSpecialRequirements(String specialRequirements) {
		this.specialRequirements = specialRequirements;
	}



	public String getAttendanceTimeTable() {
		return attendanceTimeTable;
	}



	public void setAttendanceTimeTable(String attendanceTimeTable) {
		this.attendanceTimeTable = attendanceTimeTable;
	}



	public String getPresentations() {
		return presentations;
	}



	public void setPresentations(String presentations) {
		this.presentations = presentations;
	}



	public String getTransportation() {
		return transportation;
	}



	public void setTransportation(String transportation) {
		this.transportation = transportation;
	}



	public String getWelcomeMsg() {
		return welcomeMsg;
	}



	public void setWelcomeMsg(String welcomeMsg) {
		this.welcomeMsg = welcomeMsg;
	}



	public List<SpeakerDto> getSpeaker() {
		return speaker;
	}

	public void setSpeaker(List<SpeakerDto> speaker) {
		this.speaker = speaker;
	}

	public List<SessionDto> getSession() {
		return session;
	}

	public void setSession(List<SessionDto> session) {
		this.session = session;
	}

	public List<ParticipantDto> getParticipant() {
		return participant;
	}

	public void setParticipant(List<ParticipantDto> participant) {
		this.participant = participant;
	}

	public List<AdminDto> getAdmin() {
		return admin;
	}

	public void setAdmin(List<AdminDto> admin) {
		this.admin = admin;
	}










	@Override
	public String toString() {
		return "eventDTO [eventId=" + eventId + ", departmentId=" + departmentId + ", departmentName=" + departmentName
				+ ", productId=" + productId + ", productName=" + productName + ", eventName=" + eventName
				+ ", eventPlaceName=" + eventPlaceName + ", eventStartDate=" + eventStartDate + ", eventEndDate="
				+ eventEndDate + ", venueAddress=" + venueAddress + ", venuePinCode=" + venuePinCode
				+ ", venueLatitude=" + venueLatitude + ", venueLongitude=" + venueLongitude + ", eventInformation="
				+ eventInformation + ", eventLocUrl=" + eventLocUrl + ", eventLocImageName=" + eventLocImageName
				+ ", transportToVenueFolder=" + transportToVenueFolder + ", transportToVenueFile="
				+ transportToVenueFile + ", transportFromVenueFolder=" + transportFromVenueFolder
				+ ", transportFromVenueFile=" + transportFromVenueFile + ", flightToFolder=" + flightToFolder
				+ ", flightToFile=" + flightToFile + ", flightFromVenueFolder=" + flightFromVenueFolder
				+ ", flightFromFile=" + flightFromFile + ", eventLocationImage=" + eventLocationImage + ", dressCode="
				+ dressCode + ", registrationDetail=" + registrationDetail + ", specialRequirements="
				+ specialRequirements + ", attendanceTimeTable=" + attendanceTimeTable + ", presentations="
				+ presentations + ", transportation=" + transportation + ", welcomeMsg=" + welcomeMsg + ", speaker="
				+ speaker + ", session=" + session + ", participant=" + participant + ", admin=" + admin
				+ ", readingMaterialFile=" + readingMaterialFile + ", transportFile=" + transportFile + "]";
	}



	
	
}
