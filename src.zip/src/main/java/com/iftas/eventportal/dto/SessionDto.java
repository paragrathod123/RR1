package com.iftas.eventportal.dto;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class SessionDto {

	private String eventDate;
	private String sessionName;
	private String sessionTopicName;
	private String startTime;
	private String endTime;
	private Long sessionSpeakerId;
	private List<MultipartFile> readingMaterialFile;
	private String isSession;
	private String isFeedback;
	
	public SessionDto() {
		
	}

	public String getEventDate() {
		return eventDate;
	}

	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}

	public String getSessionName() {
		return sessionName;
	}

	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}

	public String getSessionTopicName() {
		return sessionTopicName;
	}

	public void setSessionTopicName(String sessionTopicName) {
		this.sessionTopicName = sessionTopicName;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}



	public Long getSessionSpeakerId() {
		return sessionSpeakerId;
	}

	public void setSessionSpeakerId(Long sessionSpeakerId) {
		this.sessionSpeakerId = sessionSpeakerId;
	}

	public List<MultipartFile> getReadingMaterialFile() {
		return readingMaterialFile;
	}

	public void setReadingMaterialFile(List<MultipartFile> readingMaterialFile) {
		this.readingMaterialFile = readingMaterialFile;
	}

	public String getIsSession() {
		return isSession;
	}

	public void setIsSession(String isSession) {
		this.isSession = isSession;
	}

	public String getIsFeedback() {
		return isFeedback;
	}

	public void setIsFeedback(String isFeedback) {
		this.isFeedback = isFeedback;
	}

	@Override
	public String toString() {
		return "SessionDto [eventDate=" + eventDate + ", sessionName=" + sessionName + ", sessionTopicName="
				+ sessionTopicName + ", startTime=" + startTime + ", endTime=" + endTime + ", sessionSpeakerId=" + sessionSpeakerId
				+ ", readingMaterialFile=" + readingMaterialFile + ", isSession=" + isSession + ", isFeedback="
				+ isFeedback + "]";
	}
	
	
	
}
