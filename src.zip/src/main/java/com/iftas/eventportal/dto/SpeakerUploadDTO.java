package com.iftas.eventportal.dto;

import java.util.List;
import java.util.Map;

public class SpeakerUploadDTO {

	private Integer totalCount ;
	
	private Integer successCount ;
	
	private Integer failedCount ;
	
	private Map<String, List<SpeakerDto>> uploadMap  ;

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	public Integer getSuccessCount() {
		return successCount;
	}

	public void setSuccessCount(Integer successCount) {
		this.successCount = successCount;
	}

	public Integer getFailedCount() {
		return failedCount;
	}

	public void setFailedCount(Integer failedCount) {
		this.failedCount = failedCount;
	}

	public Map<String, List<SpeakerDto>> getUploadMap() {
		return uploadMap;
	}

	public void setUploadMap(Map<String, List<SpeakerDto>> uploadMap) {
		this.uploadMap = uploadMap;
	}
	
	
	
	
	
}
