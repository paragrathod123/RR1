package com.iftas.eventportal.dto;

import com.iftas.eventportal.entity.Centres;
import com.iftas.eventportal.entity.Department;
import com.iftas.eventportal.entity.Designation;
import com.iftas.eventportal.entity.Organization;

public class SpeakerDto {

	private Long speakerId;
	private String speakerRoomNo;
	private String speakerEmergencyContactNo;
	private String speakerAllergies;
	
	
	
	private String speakerFirstName;
	private String speakerLastName;
	private String speakerOrganization;
	private String speakerCenter;
	private String speakerDepartment;
	private String speakerDesignation;
	private String speakerProfile;
	private String speakerMobileNo;
	private String speakerEmailId;
	private String speakerFolderName ;
	private String speakerFileName ;
	
	
	
	
	
	public SpeakerDto() {
		
	}



	public Long getSpeakerId() {
		return speakerId;
	}



	public void setSpeakerId(Long speakerId) {
		this.speakerId = speakerId;
	}



	public String getSpeakerRoomNo() {
		return speakerRoomNo;
	}

	public void setSpeakerRoomNo(String speakerRoomNo) {
		this.speakerRoomNo = speakerRoomNo;
	}

	public String getSpeakerEmergencyContactNo() {
		return speakerEmergencyContactNo;
	}

	public void setSpeakerEmergencyContactNo(String speakerEmergencyContactNo) {
		this.speakerEmergencyContactNo = speakerEmergencyContactNo;
	}

	public String getSpeakerAllergies() {
		return speakerAllergies;
	}

	public void setSpeakerAllergies(String speakerAllergies) {
		this.speakerAllergies = speakerAllergies;
	}

	public String getSpeakerFirstName() {
		return speakerFirstName;
	}



	public void setSpeakerFirstName(String speakerFirstName) {
		this.speakerFirstName = speakerFirstName;
	}



	public String getSpeakerLastName() {
		return speakerLastName;
	}



	public void setSpeakerLastName(String speakerLastName) {
		this.speakerLastName = speakerLastName;
	}



	public String getSpeakerOrganization() {
		return speakerOrganization;
	}



	public void setSpeakerOrganization(String speakerOrganization) {
		this.speakerOrganization = speakerOrganization;
	}



	public String getSpeakerCenter() {
		return speakerCenter;
	}



	public void setSpeakerCenter(String speakerCenter) {
		this.speakerCenter = speakerCenter;
	}



	public String getSpeakerDepartment() {
		return speakerDepartment;
	}



	public void setSpeakerDepartment(String speakerDepartment) {
		this.speakerDepartment = speakerDepartment;
	}



	public String getSpeakerDesignation() {
		return speakerDesignation;
	}



	public void setSpeakerDesignation(String speakerDesignation) {
		this.speakerDesignation = speakerDesignation;
	}



	public String getSpeakerProfile() {
		return speakerProfile;
	}



	public void setSpeakerProfile(String speakerProfile) {
		this.speakerProfile = speakerProfile;
	}



	public String getSpeakerMobileNo() {
		return speakerMobileNo;
	}



	public void setSpeakerMobileNo(String speakerMobileNo) {
		this.speakerMobileNo = speakerMobileNo;
	}



	public String getSpeakerEmailId() {
		return speakerEmailId;
	}



	public void setSpeakerEmailId(String speakerEmailId) {
		this.speakerEmailId = speakerEmailId;
	}



	public String getSpeakerFolderName() {
		return speakerFolderName;
	}



	public void setSpeakerFolderName(String speakerFolderName) {
		this.speakerFolderName = speakerFolderName;
	}



	public String getSpeakerFileName() {
		return speakerFileName;
	}



	public void setSpeakerFileName(String speakerFileName) {
		this.speakerFileName = speakerFileName;
	}



	@Override
	public String toString() {
		return "SpeakerDto [speakerId=" + speakerId + ", speakerRoomNo=" + speakerRoomNo
				+ ", speakerEmergencyContactNo=" + speakerEmergencyContactNo + ", speakerAllergies=" + speakerAllergies
				+ "]";
	}
	
	
	
}
