package com.iftas.eventportal.dto;

public class ParticipantDto {

	private Long participantId;
	private String participantRoomNo;
	private String particpantEmergencyContactNo;
	private String participantAllergies;
	
	public ParticipantDto() {
		
	}



	public Long getParticipantId() {
		return participantId;
	}



	public void setParticipantId(Long participantId) {
		this.participantId = participantId;
	}



	public String getParticipantRoomNo() {
		return participantRoomNo;
	}

	public void setParticipantRoomNo(String participantRoomNo) {
		this.participantRoomNo = participantRoomNo;
	}

	public String getParticpantEmergencyContactNo() {
		return particpantEmergencyContactNo;
	}

	public void setParticpantEmergencyContactNo(String particpantEmergencyContactNo) {
		this.particpantEmergencyContactNo = particpantEmergencyContactNo;
	}

	public String getParticipantAllergies() {
		return participantAllergies;
	}

	public void setParticipantAllergies(String participantAllergies) {
		this.participantAllergies = participantAllergies;
	}

	@Override
	public String toString() {
		return "ParticipantDto [participantId=" + participantId + ", participantRoomNo=" + participantRoomNo
				+ ", particpantEmergencyContactNo=" + particpantEmergencyContactNo + ", participantAllergies="
				+ participantAllergies + "]";
	}
	
	
	
}
