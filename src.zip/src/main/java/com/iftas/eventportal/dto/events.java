package com.iftas.eventportal.dto;

public class events {
	
	
	String id;
	
	String start;
	
	String end;
	
	String title;
	
	boolean allDay;
	
	String className;
	

	

	public events(String id, String start, String end, String title, boolean allDay, String className) {
		super();
		this.id = id;
		this.start = start;
		this.end = end;
		this.title = title;
		this.allDay = allDay;
		this.className = className;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}

	public boolean isAllDay() {
		return allDay;
	}

	public void setAllDay(boolean allDay) {
		this.allDay = allDay;
	}

	public String getClassName() {
		return className;
	}

	
	

}
