package com.iftas.eventportal.security;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.access.expression.DefaultWebSecurityExpressionHandler;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.rememberme.JdbcTokenRepositoryImpl;
import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;
import org.zalando.problem.spring.web.advice.security.SecurityProblemSupport;


@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Autowired
    private UserDetailsService userDetailsService;	
	
	@Autowired
    private DataSource dataSource;
	
	@Autowired
	UserPermissionEvaluator userPermission;
	
	@Bean
    public AuthenticationSuccessHandler myAuthenticationSuccessHandler(){
        return new CustomAuthenticationSuccessHandler();
    }
	
	@Bean
    public AuthenticationFailureHandler myAuthenticationFailureHandler(){
        return new CustomAuthenticationFailureHandler();
    }
	
	
	//@Autowired
	//private  CorsFilter corsFilter;
	
	@Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
	
	@Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
 
        // Setting Service to find User in the database.
        // And Setting PassswordEncoder
        auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
        
        
        
 
    }
	
	@Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring()
            .antMatchers(HttpMethod.OPTIONS, "/**")
            .antMatchers("/app/**/*.{js,html}")
            .antMatchers("/i18n/**")
            .antMatchers("/appprop/**")
            .antMatchers("/content/**")
            .antMatchers("/swagger-ui/index.html")
            .antMatchers("/test/**")
            .antMatchers("/resources/**")
            .antMatchers("/js/**")
            .antMatchers("/static/**")
            .antMatchers("/dist/**")
            .antMatchers("/css/**")
            .antMatchers("/img/**")
            .antMatchers("/plugins/**")
            .antMatchers("/src/**")
            .antMatchers("/scss/**")
            .antMatchers("/vendor/**")
            .antMatchers("/webjars/**")
            .antMatchers("/login/**")
            ;
        
        DefaultWebSecurityExpressionHandler handler 
    	= new DefaultWebSecurityExpressionHandler();
        handler.setPermissionEvaluator(userPermission);
        		
         web.expressionHandler(handler);
    }
	
	
	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		
		http.csrf().disable();
		
		 
		 
        // The pages does not require login
        http.authorizeRequests().antMatchers("/", "/login","/forgotPassword", "/logout","/api/**").permitAll();
        
       
        
        // When the user has logged in as XX.
        // But access a page that requires role YY,
        // AccessDeniedException will be thrown.
        http.authorizeRequests().and().exceptionHandling().accessDeniedPage("/403");
 
        // Config for Login Form
        http.authorizeRequests().and().formLogin()//
                // Submit URL of login page.
                .loginProcessingUrl("/j_spring_security_check") // Submit URL
                .loginPage("/login")//
                .defaultSuccessUrl("/home")//
                .failureUrl("/login?error=true")//
                .usernameParameter("username")//
                .passwordParameter("password")
                .successHandler(myAuthenticationSuccessHandler())
                .failureHandler(myAuthenticationFailureHandler())
                // Config for Logout Page
                .and().logout().logoutUrl("/logout").logoutSuccessUrl("/");
		
        // Conf Remenber Me
        http.rememberMe()
        	.rememberMeParameter("customCheck")
        	.tokenRepository(this.persistentTokenRepository())
        	.tokenValiditySeconds(86400);
        	
		
        //Authenticate that Starts with URL /SA
        http.authorizeRequests().antMatchers("/SA/**").authenticated();
        
        //Authenticate that Reset Password 
        http.authorizeRequests().antMatchers("/resetPassword/**").authenticated();
        
        http.authorizeRequests().anyRequest().authenticated();
	}
	
	
	@Bean
    public PersistentTokenRepository persistentTokenRepository() {
        JdbcTokenRepositoryImpl db = new JdbcTokenRepositoryImpl();
        db.setDataSource(dataSource);
        return db;
    }
	
	
}
