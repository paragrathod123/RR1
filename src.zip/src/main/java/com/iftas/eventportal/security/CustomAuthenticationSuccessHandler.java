package com.iftas.eventportal.security;

import java.io.IOException;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.CredentialsExpiredException;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.iftas.eventportal.dao.CommonSetupRepository;
import com.iftas.eventportal.dao.UserLoggedActivityRepository;
import com.iftas.eventportal.dao.UserRepository;
import com.iftas.eventportal.entity.CommonSetup;
import com.iftas.eventportal.entity.User;
import com.iftas.eventportal.entity.UserLoggedActivity;
import com.iftas.eventportal.helper.GlobalMenus;


public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

	private final Logger log = LoggerFactory.getLogger(AuthenticationSuccessHandler.class);
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private UserLoggedActivityRepository userLoggedActivityRepository;
	
	
	@Autowired
	private CommonSetupRepository commonSetupRepository;
	
	private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();
	
	@Value("${PROTAL_PATH}")
	private String pathUrl;
	
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		
		log.debug("Inside CustomAuthenticationSuccessHandler.onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,\r\n" + 
				"Authentication authentication)");
		
		System.out.println("PROTAL_PATH   "+pathUrl);
		GlobalMenus globalMenu =  new GlobalMenus();
		Optional<String> loginNames  =  SecurityUtils.getCurrentUserLogin();
		String loginUser =  loginNames.get();
		//Fetch User Details & Set that into new session detail Class for further usages
		Optional<User> users =  userRepository.findOneByLogin(loginUser);
		User user =  users.get();
		System.out.println("loginUser  "+loginUser);
		if(user!=null) {
			
			
			Integer sessionTimeOut =  10;
			Optional<CommonSetup> optionalComSetup = commonSetupRepository.findById(Long.valueOf(1));
			if(optionalComSetup.isPresent()) {
				sessionTimeOut = optionalComSetup.get().getSessionTimeOut() ;
			}
			
			
			user.setFailedCount(0);
			userRepository.save(user);
			HttpSession session = request.getSession();
			session.setAttribute("userId", user.getUserId());
			session.setAttribute("userName", user.getLogin());
			session.setAttribute("firstName", user.getUserName());
			session.setAttribute("lastName", user.getLastName());
			session.setAttribute("enabled", "1");
			session.setAttribute("roleId", user.getRole().getRoleId());
			session.setAttribute("roleName", user.getRole().getRoleName());
			session.setAttribute("pathUrl", pathUrl);
			session.setAttribute("userFolderName", user.getUserFolderName());
			session.setAttribute("userFileName", user.getUserFileName());
			session.setAttribute("departmentid", String.valueOf(user.getUserDepartment().getDepartmentId()));
			System.out.println("loginUser  "+user.getEventId());
			session.setAttribute("eventid", String.valueOf(user.getEventId()));
			//session.setAttribute("isSuperAdmin", user.getMarkerType());
			//Set Session Time Out
			session.setMaxInactiveInterval(10*60);
			String makerTypeStr = "";
			if(user.getMarkerType() == 0) {
				makerTypeStr = "Maker";
			}else {
				makerTypeStr = "Checker";
			}
			session.setAttribute("markerType", String.valueOf(user.getMarkerType()));
			session.setAttribute("markerTypeStr",makerTypeStr);
			
			
			//if(GlobalMenus.siteMenus == null) {
				//Below for Loading Site Menu 
				//GlobalMenus.siteMenus = new ArrayList<MenuMaster>();
				globalMenu.loadSiteMenu(user.getRole().getRoleId(),request);
			//}
			
			
			
			UserLoggedActivity userActivity = new UserLoggedActivity();
			List<UserLoggedActivity> userLoggedActivity = new ArrayList<UserLoggedActivity>();
			userLoggedActivity =  userLoggedActivityRepository.findByUserIdOrderByUserLoginDetailsIdDesc(user.getUserId().intValue());
			if(!userLoggedActivity.isEmpty()) {
				userActivity = userLoggedActivity.get(0);
				user.setIpAdress(userActivity.getIpAddress());
				user.setLoggedInTime(userActivity.getLoginTimeDate());
				session.setAttribute("lastLoginInTime",userActivity.getLoginTimeDate());
				session.setAttribute("lastLoginIp",userActivity.getIpAddress());
				userRepository.save(user);
			}
			
			//Adding Data to userLoggedActivity
			userActivity = new UserLoggedActivity();
			userActivity.setUserId(user.getUserId().intValue());
			userActivity.setUserType(0);
			userActivity.setLoginTimeDate(ZonedDateTime.now().toInstant());
			userActivity.setCreatedDate(Instant.now());
			userActivity.setIpAddress(request.getRemoteAddr());
			userLoggedActivityRepository.save(userActivity);
			
			
			
			session.setMaxInactiveInterval(sessionTimeOut*60);
			
			
		}
		
		//set our response to OK status
		response.setStatus(HttpServletResponse.SC_OK);
		
        //since we have created our custom success handler, its up to us to where
        //we will redirect the user after successfully login
		redirectStrategy.sendRedirect(request, response, "/home");
		log.debug("Exit CustomAuthenticationSuccessHandler.onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,\r\n" + 
				"Authentication authentication)");

	}

}
