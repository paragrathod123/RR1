package com.iftas.eventportal.security;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import com.iftas.eventportal.entity.Privileges;
import com.iftas.eventportal.entity.RoleMst;
import com.iftas.eventportal.service.UserService;




@Component
public class UserPermissionEvaluator implements PermissionEvaluator {

	private final UserService roleRepository;
	
	@Autowired
	public UserPermissionEvaluator(UserService roleRepository) {
		this.roleRepository = roleRepository;
	}
	
	
	@Override
    public boolean hasPermission(
      Authentication auth, Object targetDomainObject, Object permission) {
        if ((auth == null) || (targetDomainObject == null) || !(permission instanceof String)){
            return false;
        }
        String targetType = targetDomainObject.getClass().getSimpleName().toUpperCase();
         
        return hasPrivilege(auth, targetType, permission.toString().toUpperCase());
    }
 
    @Override
    public boolean hasPermission(
      Authentication auth, Serializable targetId, String targetType, Object permission) {
        if ((auth == null) || (targetType == null) || !(permission instanceof String)) {
            return false;
        }
        return hasPrivilege(auth, targetType.toUpperCase(), 
          permission.toString().toUpperCase());
    }
    
    
    public boolean isRequestValid(RoleMst role,String pageTagName,String privilegesName) {
    	boolean isValid =  false;
//    	System.out.println("role name "+role.getRoleName());
//    	System.out.println("pageTagName "+pageTagName);
//    	System.out.println("privilegesName "+privilegesName);
//    	System.out.println("Size "+role.getPrivileges().size());
    	for(Privileges privileges : role.getPrivileges()) {
    		if((privileges.getPage().getPageTagName().toUpperCase().equals(pageTagName))) {
    			
    			if(privilegesName.toUpperCase().equals("READ_PRIVILEGE")) {
    				if(privileges.isReadPrivilage() !=null && !privileges.isReadPrivilage().equals("")) {
	    				if(privileges.isReadPrivilage() == 1 ) {
	    					isValid =  true;
	    	    			break;
	    				}
    				}
    			}else if(privilegesName.toUpperCase().equals("ADD_PRIVILEGE")) {
    				if(privileges.isAddPrivilage() !=null && !privileges.isAddPrivilage().equals("")) {
	    				if(privileges.isAddPrivilage() == 1 ) {
	    					isValid =  true;
	    	    			break;
	    				}
    				}
    			}else if(privilegesName.toUpperCase().equals("EXPORT_PRIVILEGE")) {
    				if(privileges.isExportPrivilage() !=null && !privileges.isExportPrivilage().equals("")) {
	    				if(privileges.isExportPrivilage() == 1 ) {
	    					isValid =  true;
	    	    			break;
	    				}
    				}
    			}else if(privilegesName.toUpperCase().equals("EDIT_PRIVILEGE")) {
    				if(privileges.isUpdatePrivilage() !=null && !privileges.isUpdatePrivilage().equals("")) {
	    				if(privileges.isUpdatePrivilage() == 1 ) {
	    					isValid =  true;
	    	    			break;
	    				}
    				}
    			}
    		}
    		
    	}
    	//System.out.println("isValid "+isValid);
    	return isValid;
    }
    
    
    
    
    private boolean hasPrivilege(Authentication auth, String targetType, String permission) {
    	
    	RoleMst role = null;
    	for (GrantedAuthority grantedAuth : auth.getAuthorities()) {
    		//System.out.println("  grantedAuth.getAuthority() " +grantedAuth.getAuthority());
    		role =  roleRepository.getRole(grantedAuth.getAuthority());
        }
    	
    	return isRequestValid(role,targetType,permission);
    	
    	
    	//return true;
    	
    	/*
    	
        for (GrantedAuthority grantedAuth : auth.getAuthorities()) {
            if (grantedAuth.getAuthority().startsWith(targetType)) {
                if (grantedAuth.getAuthority().contains(permission)) {
                    return true;
                }
            }
        }
        return false;
        */
    }
	
}
