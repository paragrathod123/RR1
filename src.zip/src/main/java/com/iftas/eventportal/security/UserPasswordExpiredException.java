package com.iftas.eventportal.security;

import javax.security.auth.login.CredentialExpiredException;

public class UserPasswordExpiredException extends CredentialExpiredException {

	
	private static final long serialVersionUID = 1L;

    public UserPasswordExpiredException(String message) {
        super(message);
    }

}
