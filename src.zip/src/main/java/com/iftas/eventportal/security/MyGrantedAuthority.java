package com.iftas.eventportal.security;

import org.springframework.security.core.GrantedAuthority;

public class MyGrantedAuthority implements GrantedAuthority {

private static final long serialVersionUID = 1L;
	
	String pageId;
	String pageUrl;
	String privilegeName;
	
	public String getPageId() {
		return pageId;
	}




	public void setPageId(String pageId) {
		this.pageId = pageId;
	}




	public String getPageUrl() {
		return pageUrl;
	}




	public void setPageUrl(String pageUrl) {
		this.pageUrl = pageUrl;
	}




	public String getPrivilegeName() {
		return privilegeName;
	}




	public void setPrivilegeName(String privilegeName) {
		this.privilegeName = privilegeName;
	}




	public MyGrantedAuthority(String pageId, String pageUrl, String privilegeName) {
		super();
		this.pageId = pageId;
		this.pageUrl = pageUrl;
		this.privilegeName = privilegeName;
	}




	@Override
	public String getAuthority() {
		// TODO Auto-generated method stub
		return this.pageId + ";" + this.pageUrl + ";" +this.privilegeName;
	}
}
