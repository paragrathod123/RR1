package com.iftas.eventportal.security;


import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collectors;

import org.hibernate.validator.internal.constraintvalidators.hv.EmailValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.CredentialsExpiredException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.iftas.eventportal.dao.CommonSetupRepository;
import com.iftas.eventportal.dao.UserRepository;
import com.iftas.eventportal.entity.User;
import com.iftas.eventportal.entity.CommonSetup;
import com.iftas.eventportal.entity.RoleMst;

/**
 * Authenticate a user from the database.
 */
@Component("userDetailsService")

public class DomainUserDetailsService implements UserDetailsService {

	private final Logger log = LoggerFactory.getLogger(DomainUserDetailsService.class);
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private CommonSetupRepository commonSetupRepository;
	
	
	@Override
	@Transactional
	public UserDetails loadUserByUsername(String login){
		log.debug("Authenticating {}", login);
		
		if (new EmailValidator().isValid(login, null)) {
            return userRepository.findOneByEmailIgnoreCase(login)
                .map(user -> createSpringSecurityUser(login, user))
                .orElseThrow(() -> new UsernameNotFoundException("User with email " + login + " was not found in the database"));
        }
		
		String lowercaseLogin = login.toLowerCase(Locale.ENGLISH);
        return userRepository.findOneByLogin(lowercaseLogin)
            .map(user -> createSpringSecurityUser(lowercaseLogin, user))
            .orElseThrow(() -> new UsernameNotFoundException("User " + lowercaseLogin + " was not found in the database"));
		
		
	}
	
	
	
	
	private org.springframework.security.core.userdetails.User createSpringSecurityUser(String lowercaseLogin, User user)  {
		if (user.getActiveStatus() == 1) {
            throw new UserNotActivatedException("User " + lowercaseLogin + " was not activated");
        }
		
		boolean isActive =  true;
		if(user.getActiveStatus() == 1) {
			isActive =  false;
		}
		if(user.getLastResetDate() == null ) {
			isActive =  false;
		}
		boolean isLocked =  true;
		if(user.getLocked() ==1) {
			isLocked = false;
		}
		
		if(user.getLastResetDate() != null ) {
			Integer passwordExpiryDays =  30;
			Optional<CommonSetup> optionalComSetup = commonSetupRepository.findById(Long.valueOf(1));
			if(optionalComSetup.isPresent()) {
				passwordExpiryDays = optionalComSetup.get().getPasswordExpiryAfterNoOfDays();
			}
			
			Instant getCurrentDate =  Instant.now();
			System.out.println("Current Date "+getCurrentDate);
			Instant getLastResetDate =  null;
			if(user.getLastResetDate() !=null) {
				getLastResetDate =  user.getLastResetDate();
			}
			System.out.println("Last Reset Date "+getLastResetDate);
			getLastResetDate  = getLastResetDate.plus(passwordExpiryDays,ChronoUnit.DAYS);
			System.out.println("Last Reset Date+Expiry Days  "+getLastResetDate);
			int compare =getLastResetDate.compareTo(getCurrentDate);  
			if(compare<0) {
				throw new CredentialsExpiredException("Password is expired.");
			}
		}
		
//		 List<GrantedAuthority> grantedAuthorities = user.getAuthorities().stream()
//		            .map(authority -> new SimpleGrantedAuthority(authority.getName()))
//		            .collect(Collectors.toList());
		 
//		 return new org.springframework.security.core.userdetails.User(user.getLogin(),
//		            user.getPasswordHash(),
//		            isActive,true,true,isLocked,
//		            grantedAuthorities);
		        
		 return new org.springframework.security.core.userdetails.User(user.getLogin()
					, user.getPasswordHash(),isActive,true,true,isLocked, getGrantedAuthorities(user.getRole()) );       
		
	}
	
	
	private List<GrantedAuthority> getGrantedAuthorities(RoleMst roles) {
        List<GrantedAuthority> authorities = new ArrayList<>();
        {
            authorities.add(new SimpleGrantedAuthority(roles.getRoleName()));
        }
        return authorities;
	}
	

}
