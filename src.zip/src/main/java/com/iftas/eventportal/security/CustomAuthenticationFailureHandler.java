package com.iftas.eventportal.security;

import java.io.IOException;
import java.time.Instant;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.iftas.eventportal.dao.CommonSetupRepository;
import com.iftas.eventportal.dao.UserRepository;
import com.iftas.eventportal.entity.CommonSetup;
import com.iftas.eventportal.entity.User;
import com.iftas.eventportal.service.MailService;
import com.iftas.eventportal.util.RandomUtil;

public class CustomAuthenticationFailureHandler implements AuthenticationFailureHandler {

	private final Logger log = LoggerFactory.getLogger(CustomAuthenticationFailureHandler.class);
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private MailService mailService;
	
	@Autowired
	private CommonSetupRepository commonSetupRepository;
	
	private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();
	
	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException exception) throws IOException, ServletException {
		log.debug("Inside CustomAuthenticationFailureHandler.onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,\r\n" + 
				"			AuthenticationException exception)");
		
			//if Exception is of type Bad
			if(exception instanceof BadCredentialsException) {
					String login =  request.getParameter("username");
					lockUser(login);
			}
			request.getSession().setAttribute("SPRING_SECURITY_LAST_EXCEPTION", exception);
			redirectStrategy.sendRedirect(request, response, "/login?error=true");
			
			log.debug("Exiting CustomAuthenticationFailureHandler.onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,\r\n" + 
					"			AuthenticationException exception)");	
	}
	
	
	private void lockUser(String login) {
		
		log.debug("Inside lockUser(String login)");
		
		Optional<User> users =  userRepository.findOneByLogin(login);
		if(users.isPresent()) {
			
			User user = users.get();
			Integer maxLoginAttempts =  4;
			Optional<CommonSetup> optionalComSetup = commonSetupRepository.findById(Long.valueOf(1));
			if(optionalComSetup.isPresent()) {
				maxLoginAttempts = optionalComSetup.get().getMaxLoginAttempts() ;
			}
			
			int failedCount = user.getFailedCount() + 1;
			user.setFailedCount(failedCount);

			if (failedCount > maxLoginAttempts) {
				user.setLocked(1);
				user.setResetKey(RandomUtil.generateResetKey());
	            user.setResetDate(Instant.now());
			}
            userRepository.save(user);
            if (failedCount > maxLoginAttempts) {
	            try {
	                  mailService.sendPasswordResetMail(user);
	            }catch (Exception e) {
					e.printStackTrace();
				}
            }
		}
		log.debug("Exit lockUser(String login)");
		
	}

}
