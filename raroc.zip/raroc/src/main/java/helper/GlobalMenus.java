package helper;

import java.io.File;
import java.nio.file.Files;
import java.util.List;


import org.springframework.util.ResourceUtils;

import com.ey.raroc.Entity.MenuMaster;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

public class GlobalMenus {

public static List<MenuMaster> siteMenus ;
	
	public void loadSiteMenu(Long long1,HttpServletRequest httpRequest) {
		
		try {			
			HttpSession session =  httpRequest.getSession();
			String pathUrl =  (String)session.getAttribute("pathUrl");
			ObjectMapper object =  new ObjectMapper();
			File file = ResourceUtils.getFile(pathUrl.trim()+"/Roles/" +"/Role_"+long1+".json");
			byte[] jsonData =  Files.readAllBytes(file.toPath());
			GlobalMenus.siteMenus =  object.reader()
					.forType(new TypeReference<List<MenuMaster>>() {})
					.readValue(jsonData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
