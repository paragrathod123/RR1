package com.ey.raroc.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ey.raroc.Entity.SegmentMst;

public interface SegmentRepository extends JpaRepository<SegmentMst, Long> {

	List<SegmentMst> findAllByActiveStatusOrderBySegmentNameAsc(int activeStatus);
}
