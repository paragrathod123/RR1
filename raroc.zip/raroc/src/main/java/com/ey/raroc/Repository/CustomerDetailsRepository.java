package com.ey.raroc.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ey.raroc.Entity.CustomerDetails;

public interface CustomerDetailsRepository extends JpaRepository<CustomerDetails, Long> {

}
