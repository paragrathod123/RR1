package com.ey.raroc.Service;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ey.raroc.Entity.Role;
import com.ey.raroc.Entity.User;
import com.ey.raroc.Repository.UserRepository;
import com.ey.raroc.Utils.DataRow;
import com.ey.raroc.Utils.DataTable;
import com.ey.raroc.Utils.ExcelTable;
import com.ey.raroc.Utils.RandomUtil;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.*;



@Service
@Transactional
public class UserService {

	@Autowired
	private UserRepository userRepo;
	

	
	private PasswordEncoder passwordEncoder =  new BCryptPasswordEncoder();
	
	public User getUserById(Long id) {
		return userRepo.findById(id).get();
	}
	
	public List<User> getUsers(){
		return userRepo.findAll();
	}
	
	public User getByEmail(String email) {
		return userRepo.findByEmail(email);
	}
	
	public void updateuser(String name, String designationName,int status, Long userId) {
		System.out.println(status);
		userRepo.setUserInfoById(name, designationName, status, userId);
	}
	
	
	public List<User> getAllByName(String name) {
		return userRepo.findAllUserByName(name);
	}
	
	public void createUser(User user) {
		String passwordTemp = "123456";
		String encryptedPassword = passwordEncoder.encode(passwordTemp);
		user.setResetKey(RandomUtil.generateResetKey());
		user.setResetDate(Instant.now());
		user.setPassword(encryptedPassword);
		
		userRepo.save(user);
	}
	
	
	 public Optional<User> requestPasswordReset(String mail) {
	        return userRepo.findOneByEmailIgnoreCase(mail)
	         //   .filter(User::getActivated)
	            .map(user -> {
	                user.setResetKey(RandomUtil.generateResetKey());
	                user.setResetDate(Instant.now());
	                userRepo.save(user);
	                return user;
	            });
	    }
	 
	 
	 public Optional<User> completePasswordReset(String newPassword, String key) {
	        return userRepo.findOneByResetKey(key)
	            //.filter(user -> user.getResetDate().isAfter(Instant.now().minusSeconds(86400)))
	            .map(user -> {
	                user.setPassword(passwordEncoder.encode(newPassword));
	                user.setResetKey(null);
	                user.setResetDate(null);
	                //user.setLocked(0);
	                user.setLastResetDate(Instant.now());
	                userRepo.save(user);
	                return user;
	            });
	  }
	
	
	public void saveUser(User user) {
		userRepo.save(user);
	}
	
	public void updateStatus(int status, Long id) {
		userRepo.updateActvieStatus(status, id);
	}
	
	public void uploadUsers(MultipartFile reapExcelDataFile, HttpServletRequest request) throws IOException{
		String filePath = "C:\\Users\\PS568BX\\OneDrive - EY\\Desktop\\DevelopmentPortal\\Templates";
		Role role=new Role();
		final String label = "User" + UUID.randomUUID().toString() + ".xlsx";
		final String filepath1 = filePath + "temp/" + label;
		byte[] bytes = reapExcelDataFile.getBytes();
		File fh = new File(filePath + "temp/");
		if (!fh.exists()) {
			fh.mkdir();
		}
		try {
			FileOutputStream writer = new FileOutputStream(filepath1);
			writer.write(bytes);
			writer.close();
			FileInputStream inputStream = new FileInputStream(filepath1);
			DataTable table = ExcelTable.load(() -> inputStream, 0);
			int rowCount = table.rowCount();
			for (int i = 0; i < rowCount; i++) {
				User userData = new User();
				User user= new User();
				DataRow row = table.row(i);
				
				String userEmail=row.cell("Email");
				String name = row.cell("Name");
				String desigantion = row.cell("Designation");
				if (userEmail != null && !userEmail.equals("") && !userEmail.equals("null")) {
					user.setEmail(userEmail);
				if (name != null && !name.equals("") && !name.equals("null")) {
					user.setName(name);
				if (desigantion != null && !desigantion.equals("") && !desigantion.equals("null")) {
					user.setDesignationName(desigantion);
				}
				}
				userData = userRepo.findByEmail(userEmail);
				if(userData!=null) {
					
					userRepo.setUserInfoById(name, desigantion,1, userData.getId());
				}
				
				else {
				user.setActive(1);
				role.setRoleId(Long.valueOf(1));
				role.setRole("User");
				user.setRoles(role);
				user.setCreatedDate(Instant.now());
				if (inputStream != null) {
					inputStream.close();
				}
				userRepo.save(user);
				}
				}
				
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
			
		}
	}
}
