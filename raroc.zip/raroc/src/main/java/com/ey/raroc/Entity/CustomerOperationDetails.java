package com.ey.raroc.Entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "customer_operation_details")
public class CustomerOperationDetails {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "customer_operation_id")
	private Long CustomerOperationDetailId;
	
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "customerdetailsid")
	private CustomerDetails customerOpDetails;
	
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "leadid")
	private LeadMst lead;
	
	@Column(name = "loan_processing_cost")
	Double loanProcessingCost;
	
	@Column(name = "variable_cost")
	Double variableCost;
	
	@Column(name = "loan_servicing_cost")
	Double loanServicingCost;
	
	@Column(name = "monitoring_cost")
	Double monitoringCost;
	
	@Column(name = "total_operation_cost")
	Double totalOperationCost;

	public Long getCustomerOperationDetailId() {
		return CustomerOperationDetailId;
	}

	public void setCustomerOperationDetailId(Long customerOperationDetailId) {
		CustomerOperationDetailId = customerOperationDetailId;
	}

	public CustomerDetails getCustomerOpDetails() {
		return customerOpDetails;
	}

	public void setCustomerOpDetails(CustomerDetails customerOpDetails) {
		this.customerOpDetails = customerOpDetails;
	}

	public LeadMst getLead() {
		return lead;
	}

	public void setLead(LeadMst lead) {
		this.lead = lead;
	}

	public Double getLoanProcessingCost() {
		return loanProcessingCost;
	}

	public void setLoanProcessingCost(Double loanProcessingCost) {
		this.loanProcessingCost = loanProcessingCost;
	}

	public Double getVariableCost() {
		return variableCost;
	}

	public void setVariableCost(Double variableCost) {
		this.variableCost = variableCost;
	}

	public Double getLoanServicingCost() {
		return loanServicingCost;
	}

	public void setLoanServicingCost(Double loanServicingCost) {
		this.loanServicingCost = loanServicingCost;
	}

	public Double getMonitoringCost() {
		return monitoringCost;
	}

	public void setMonitoringCost(Double monitoringCost) {
		this.monitoringCost = monitoringCost;
	}

	public Double getTotalOperationCost() {
		return totalOperationCost;
	}

	public void setTotalOperationCost(Double totalOperationCost) {
		this.totalOperationCost = totalOperationCost;
	}
	
	

}
