package com.ey.raroc.Utils;


import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import com.ey.raroc.Entity.User;
import com.ey.raroc.Entity.LeadMst;
import com.ey.raroc.Entity.ProductClassMst;
import com.ey.raroc.Entity.Role;
import com.ey.raroc.Entity.SegmentMst;
import com.ey.raroc.Repository.LeadRepository;
import com.ey.raroc.Repository.ProductClassRepository;
import com.ey.raroc.Repository.RoleRepository;
import com.ey.raroc.Repository.SegmentRepository;
import com.ey.raroc.Repository.UserRepository;

public class Miscellaneous implements GetUserName{
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private SegmentRepository segmentRepository;
	
	@Autowired
	private ProductClassRepository productClassRepository;
	
	@Autowired
	private LeadRepository leadRepository;
	
	@Override
	public String getUserName(int id) {
		String userName = "" ; 
		Optional<User> users =  userRepository.findById(Long.valueOf(id));
		if(users.isPresent()) {
			User user =  users.get();
			userName = user.getEmail();
		}
		return userName;
	}
	
	@Override
	public String getName(int id) {
		String name = "" ; 
		Optional<User> users =  userRepository.findById(Long.valueOf(id));
		if(users.isPresent()) {
			User user =  users.get();
			name = user.getName();
		}
		return name;
	}

	@Override
	public String getNameByUserName(String userId) {
		String name = "" ; 
		User users =  userRepository.findByEmail(userId);
	
			name = users.getName();
		
		return name;
	}

	@Override
	public List<Role> getAllRoles() {
		// TODO Auto-generated method stub
		return roleRepository.findAll();
	}

	@Override
	public List<SegmentMst> getAllActiveSegment(int activeStatus) {
		return segmentRepository.findAllByActiveStatusOrderBySegmentNameAsc(activeStatus);
	}

	@Override
	public List<ProductClassMst> getAllActiveProductClass(int activeStatus) {
		return productClassRepository.findAllByActiveStatusOrderByProductClassNameAsc(activeStatus);
	}

	@Override
	public List<LeadMst> getAllLeads() {
		return leadRepository.findAll();
	}

}
