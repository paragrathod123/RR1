package com.ey.raroc.DTO;

public class AjaxResponseLeadBody {
	
	String msg;
	LeadDTO result;
	
	
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public LeadDTO getResult() {
		return result;
	}
	public void setResult(LeadDTO result) {
		this.result = result;
	}
	
	
	
	

}
