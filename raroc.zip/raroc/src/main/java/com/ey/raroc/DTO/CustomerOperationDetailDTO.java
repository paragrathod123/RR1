package com.ey.raroc.DTO;

public class CustomerOperationDetailDTO {
	
	Long leadId;
	Double loanProcessingCost;
	Double variableCost;
	Double loanServicingCost;
	Double monitoringCost;
	Double totalOperationCost;
	
	public Long getLeadId() {
		return leadId;
	}
	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	public Double getLoanProcessingCost() {
		return loanProcessingCost;
	}
	public void setLoanProcessingCost(Double loanProcessingCost) {
		this.loanProcessingCost = loanProcessingCost;
	}
	public Double getVariableCost() {
		return variableCost;
	}
	public void setVariableCost(Double variableCost) {
		this.variableCost = variableCost;
	}
	public Double getLoanServicingCost() {
		return loanServicingCost;
	}
	public void setLoanServicingCost(Double loanServicingCost) {
		this.loanServicingCost = loanServicingCost;
	}
	public Double getMonitoringCost() {
		return monitoringCost;
	}
	public void setMonitoringCost(Double monitoringCost) {
		this.monitoringCost = monitoringCost;
	}
	public Double getTotalOperationCost() {
		return totalOperationCost;
	}
	public void setTotalOperationCost(Double totalOperationCost) {
		this.totalOperationCost = totalOperationCost;
	}
	
	

}
