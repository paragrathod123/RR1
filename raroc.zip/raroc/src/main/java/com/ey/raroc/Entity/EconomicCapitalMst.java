package com.ey.raroc.Entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "economic_capital_mst")
public class EconomicCapitalMst {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "economic_capital_id")
	private Long economicCapitalId;

	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "segment_id")
	private SegmentMst segmentMst;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "producclasstid")
	private ProductClassMst productClassMst;
	
	@Column(name = "economic_rate")
	private Double economicRate;
	
	@Column(name = "active_flag")
	private Integer activeStatus ;

	public Long getEconomicCapitalId() {
		return economicCapitalId;
	}

	public void setEconomicCapitalId(Long economicCapitalId) {
		this.economicCapitalId = economicCapitalId;
	}

	public SegmentMst getSegmentMst() {
		return segmentMst;
	}

	public void setSegmentMst(SegmentMst segmentMst) {
		this.segmentMst = segmentMst;
	}

	public ProductClassMst getProductClassMst() {
		return productClassMst;
	}

	public void setProductClassMst(ProductClassMst productClassMst) {
		this.productClassMst = productClassMst;
	}

	public Double getEconomicRate() {
		return economicRate;
	}

	public void setEconomicRate(Double economicRate) {
		this.economicRate = economicRate;
	}

	public Integer getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(Integer activeStatus) {
		this.activeStatus = activeStatus;
	}

	@Override
	public String toString() {
		return "EconomicCapitalMst [economicCapitalId=" + economicCapitalId + ", segmentMst=" + segmentMst
				+ ", productClassMst=" + productClassMst + ", economicRate=" + economicRate + ", activeStatus="
				+ activeStatus + "]";
	}
	
	
	
	
}
