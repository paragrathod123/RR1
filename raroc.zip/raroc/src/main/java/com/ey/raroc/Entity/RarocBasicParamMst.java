package com.ey.raroc.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "raroc_baiscparam_mst")
public class RarocBasicParamMst {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "raroc_baiscparam_id")
	private Long rarocBasicParamId;
	
	@Column(name = "loan_processing_cost_value")
	private Double loanProcessingCost;
	
	@Column(name = "variable_cost_value")
	private Double variableCost;
	
	@Column(name = "loan_servicing_cost_value")
	private Double loanServicingCost;
	
	@Column(name = "monitoring_cost_value")
	private Double monitoringCostValue;
	
	@Column(name = "risk_free_rate")
	private Double riskFreeRate;
	
	@Column(name = "industry_default_rate")
	private Double industryDefaultRate;
	
	@Column(name = "economic_capital_rate")
	private Double economicCapitalRate;
	
	@Column(name = "return_on_capital_rate")
	private Double returnOnCapitalRate;

	public Long getRarocBasicParamId() {
		return rarocBasicParamId;
	}

	public void setRarocBasicParamId(Long rarocBasicParamId) {
		this.rarocBasicParamId = rarocBasicParamId;
	}

	public Double getLoanProcessingCost() {
		return loanProcessingCost;
	}

	public void setLoanProcessingCost(Double loanProcessingCost) {
		this.loanProcessingCost = loanProcessingCost;
	}

	public Double getVariableCost() {
		return variableCost;
	}

	public void setVariableCost(Double variableCost) {
		this.variableCost = variableCost;
	}

	public Double getLoanServicingCost() {
		return loanServicingCost;
	}

	public void setLoanServicingCost(Double loanServicingCost) {
		this.loanServicingCost = loanServicingCost;
	}

	public Double getMonitoringCostValue() {
		return monitoringCostValue;
	}

	public void setMonitoringCostValue(Double monitoringCostValue) {
		this.monitoringCostValue = monitoringCostValue;
	}

	public Double getRiskFreeRate() {
		return riskFreeRate;
	}

	public void setRiskFreeRate(Double riskFreeRate) {
		this.riskFreeRate = riskFreeRate;
	}

	public Double getIndustryDefaultRate() {
		return industryDefaultRate;
	}

	public void setIndustryDefaultRate(Double industryDefaultRate) {
		this.industryDefaultRate = industryDefaultRate;
	}

	public Double getEconomicCapitalRate() {
		return economicCapitalRate;
	}

	public void setEconomicCapitalRate(Double economicCapitalRate) {
		this.economicCapitalRate = economicCapitalRate;
	}

	public Double getReturnOnCapitalRate() {
		return returnOnCapitalRate;
	}

	public void setReturnOnCapitalRate(Double returnOnCapitalRate) {
		this.returnOnCapitalRate = returnOnCapitalRate;
	}

	@Override
	public String toString() {
		return "RarocBasicParamMst [rarocBasicParamId=" + rarocBasicParamId + ", loanProcessingCost="
				+ loanProcessingCost + ", variableCost=" + variableCost + ", loanServicingCost=" + loanServicingCost
				+ ", monitoringCostValue=" + monitoringCostValue + ", riskFreeRate=" + riskFreeRate
				+ ", industryDefaultRate=" + industryDefaultRate + ", economicCapitalRate=" + economicCapitalRate
				+ ", returnOnCapitalRate=" + returnOnCapitalRate + "]";
	}
	
	
	
	

}
