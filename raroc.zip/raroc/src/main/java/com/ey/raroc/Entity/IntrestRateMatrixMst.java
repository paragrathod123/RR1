package com.ey.raroc.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "intrest_rate_matrix_mst")
public class IntrestRateMatrixMst {
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "intrest_rate_matrix_id")
	private Long intrestRateMatrixId;
	
	@Column(name = "credit_from")
	private Integer creditFrom;
	
	@Column(name = "credit_to")
	private Integer creditTo;
	
	@Column(name = "loan_amt_from")
	private Double loanAmountFrom;
	
	@Column(name = "loan_amt_to")
	private Double loanAmountTo;
	
	@Column(name = "intrest_rate_value")
	private Double intrestRate;
	
	@Column(name = "active_flag")
	private Integer activeStatus;

	public Long getIntrestRateMatrixId() {
		return intrestRateMatrixId;
	}

	public void setIntrestRateMatrixId(Long intrestRateMatrixId) {
		this.intrestRateMatrixId = intrestRateMatrixId;
	}

	public Integer getCreditFrom() {
		return creditFrom;
	}

	public void setCreditFrom(Integer creditFrom) {
		this.creditFrom = creditFrom;
	}

	public Integer getCreditTo() {
		return creditTo;
	}

	public void setCreditTo(Integer creditTo) {
		this.creditTo = creditTo;
	}

	public Double getLoanAmountFrom() {
		return loanAmountFrom;
	}

	public void setLoanAmountFrom(Double loanAmountFrom) {
		this.loanAmountFrom = loanAmountFrom;
	}

	public Double getLoanAmountTo() {
		return loanAmountTo;
	}

	public void setLoanAmountTo(Double loanAmountTo) {
		this.loanAmountTo = loanAmountTo;
	}

	public Double getIntrestRate() {
		return intrestRate;
	}

	public void setIntrestRate(Double intrestRate) {
		this.intrestRate = intrestRate;
	}

	public Integer getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(Integer activeStatus) {
		this.activeStatus = activeStatus;
	}

	@Override
	public String toString() {
		return "IntrestRateMatrixMst [intrestRateMatrixId=" + intrestRateMatrixId + ", creditFrom=" + creditFrom
				+ ", creditTo=" + creditTo + ", loanAmountFrom=" + loanAmountFrom + ", loanAmountTo=" + loanAmountTo
				+ ", intrestRate=" + intrestRate + ", activeStatus=" + activeStatus + "]";
	}
	
	
	

}
