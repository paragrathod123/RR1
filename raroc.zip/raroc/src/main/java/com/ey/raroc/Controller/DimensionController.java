package com.ey.raroc.Controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ey.raroc.Entity.CustomerDetails;

@RequestMapping("/dimensions")
@Controller
public class DimensionController {
	
	
	@GetMapping("/listDimensions")
	public String listDimensions(Model model) {
		//List<CustomerDetails> listCustomerDetails =  customerDetailsService.getAllCustomerDetails();
		model.addAttribute("dummydata", "");
		return "dimensions/listDimensions";
	}
	
	@GetMapping("/addDimensionDetails")
	public String addDimensionDetails(Model model) {
		//CustomerDetails customerDetails = new CustomerDetails();
		model.addAttribute("dummydata", "");
	    return "dimensions/addDimension";
	}

}
