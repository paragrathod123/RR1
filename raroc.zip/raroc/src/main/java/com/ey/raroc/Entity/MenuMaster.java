package com.ey.raroc.Entity;

import java.util.List;


import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "menumst")
public class MenuMaster {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="menuid")
	private Long menuId;
	
	@Column(name="name")
	private String name;
	
	@Column(name="active_status")
	private int activeStatus;
	
	@Column(name="menu_tag_name")
	private String menuTagName; 
	
	@JsonManagedReference
	@OneToMany(mappedBy="menu")
	//@Where(clause = "active_status = '0'")
	private List<PageMst> pages; 

	
	public String getMenuTagName() {
		return menuTagName;
	}

	public void setMenuTagName(String menuTagName) {
		this.menuTagName = menuTagName;
	}

	public Long getMenuId() {
		return menuId;
	}

	public void setMenuId(Long menuId) {
		this.menuId = menuId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(int activeStatus) {
		this.activeStatus = activeStatus;
	}

	public List<PageMst> getPages() {
		return pages;
	}

	public void setPages(List<PageMst> pages) {
		this.pages = pages;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((menuId == null) ? 0 : menuId.hashCode());
		result = prime * result + ((pages == null) ? 0 : pages.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MenuMaster other = (MenuMaster) obj;
		if (menuId == null) {
			if (other.menuId != null)
				return false;
		} else if (!menuId.equals(other.menuId))
			return false;
		if (pages == null) {
			if (other.pages != null)
				return false;
		} else if (!pages.equals(other.pages))
			return false;
		return true;
	}
	
}
