package com.ey.raroc.DTO;

public class LeadDTO {

	
	Long leadId;
	String leadNo;
	String leadDescription ;
	String rmName;
	Long rmUserId;
	Long segmentId;
	Long productClassId;
	public Long getLeadId() {
		return leadId;
	}
	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	public String getLeadNo() {
		return leadNo;
	}
	public void setLeadNo(String leadNo) {
		this.leadNo = leadNo;
	}
	public String getLeadDescription() {
		return leadDescription;
	}
	public void setLeadDescription(String leadDescription) {
		this.leadDescription = leadDescription;
	}
	public String getRmName() {
		return rmName;
	}
	public void setRmName(String rmName) {
		this.rmName = rmName;
	}
	public Long getRmUserId() {
		return rmUserId;
	}
	public void setRmUserId(Long rmUserId) {
		this.rmUserId = rmUserId;
	}
	public Long getSegmentId() {
		return segmentId;
	}
	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}
	public Long getProductClassId() {
		return productClassId;
	}
	public void setProductClassId(Long productClassId) {
		this.productClassId = productClassId;
	}
	
	
	
	
}
