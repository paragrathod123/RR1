package com.ey.raroc.Entity;

import java.time.Instant;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "leadmst")
public class LeadMst {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "lead_id")
	private Long leadId;
	
	@Column(name = "lead_no")
	private String leadNo;
	
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "segment_id")
	private SegmentMst segmentMst;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "producclasstid")
	private ProductClassMst productClassMst;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id")
	private User user;
	
	@Column(name = "account_no")
	private String accountNo;
	
	@Column(name = "lead_description")
	private String leadDescription;
	
	@Column(name = "created_by")
	private Integer createdBy;
	
	@Column(name = "created_date")
	private Instant createdDate ;
	
	@Column(name = "updated_by")
	private Integer updatedBy;
	
	@Column(name = "updated_date")
	private Instant updatedDate;

	public Long getLeadId() {
		return leadId;
	}

	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}

	public String getLeadNo() {
		return leadNo;
	}

	public void setLeadNo(String leadNo) {
		this.leadNo = leadNo;
	}

	public SegmentMst getSegmentMst() {
		return segmentMst;
	}

	public void setSegmentMst(SegmentMst segmentMst) {
		this.segmentMst = segmentMst;
	}

	public ProductClassMst getProductClassMst() {
		return productClassMst;
	}

	public void setProductClassMst(ProductClassMst productClassMst) {
		this.productClassMst = productClassMst;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getLeadDescription() {
		return leadDescription;
	}

	public void setLeadDescription(String leadDescription) {
		this.leadDescription = leadDescription;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Instant getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Instant updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public String toString() {
		return "LeadMst [leadId=" + leadId + ", leadNo=" + leadNo + ", segmentMst=" + segmentMst + ", productClassMst="
				+ productClassMst + ", user=" + user + ", accountNo=" + accountNo + ", leadDescription="
				+ leadDescription + ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", updatedBy="
				+ updatedBy + ", updatedDate=" + updatedDate + "]";
	}
	
	
	

}
