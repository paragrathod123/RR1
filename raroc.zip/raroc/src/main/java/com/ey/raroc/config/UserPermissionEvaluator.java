package com.ey.raroc.config;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import com.ey.raroc.Entity.Privileges;
import com.ey.raroc.Entity.Role;
import com.ey.raroc.Entity.User;
import com.ey.raroc.Service.UserService;

@Component
public class UserPermissionEvaluator implements PermissionEvaluator {

	private final UserService roleRepository;

	@Autowired
	public UserPermissionEvaluator(UserService roleRepository) {
		this.roleRepository = roleRepository;
	}

	@Override
	public boolean hasPermission(Authentication authentication, Object targetDomainObject, Object permission) {
		if ((authentication == null) || (targetDomainObject == null) || !(permission instanceof String)) {
			return false;
		}
		String targetType = targetDomainObject.getClass().getSimpleName().toUpperCase();

		return hasPrivilege(authentication, targetType, permission.toString().toUpperCase());
	}

	@Override
	public boolean hasPermission(Authentication authentication, Serializable targetId, String targetType,
			Object permission) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isRequestValid(Role role, String pageTagName, String privilegesName) {

		boolean isValid = false;
		for (Privileges privileges : role.getPrivileges()) {
			if ((privileges.getPage().getPageTagName().toUpperCase().equals(pageTagName))) {
				if (privilegesName.toUpperCase().equals("READ_PRIVILEGE")) {
					if (privileges.isReadPrivilage() == 1) {
						isValid = true;
						break;
					}
				} else if (privilegesName.toUpperCase().equals("ADD_PRIVILEGE")) {
					if (privileges.isAddPrivilage() == 1) {
						isValid = true;
						break;
					}
				} else if (privilegesName.toUpperCase().equals("EXPORT_PRIVILEGE")) {
					if (privileges.isExportPrivilage() == 1) {
						isValid = true;
						break;
					}
				} else if (privilegesName.toUpperCase().equals("EDIT_PRIVILEGE")) {
					if (privileges.isUpdatePrivilage() == 1) {
						isValid = true;
						break;
					}
				}
			}

		}
		return isValid;
	}

	private boolean hasPrivilege(Authentication auth, String targetType, String permission) {

		Role role = null;
		for (GrantedAuthority grantedAuth : auth.getAuthorities()) {
			System.out.println(grantedAuth);
			// role = roleRepository.getRole(grantedAuth.getAuthority());
		}

		return isRequestValid(role, targetType, permission);

	}
}
