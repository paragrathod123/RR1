package com.ey.raroc.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ey.raroc.DTO.KeyAndPassword;
import com.ey.raroc.Entity.User;
import com.ey.raroc.Repository.UserRepository;
import com.ey.raroc.Service.MailService;
import com.ey.raroc.Service.UserService;
import com.ey.raroc.config.SecurityUtils;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;



@Controller
public class LoginController {
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private MailService mailService;
	
	@GetMapping("/home")
	   public String login(Model theModel,HttpServletRequest request, HttpSession session) { 
		return "home"; 
	   } 

	@GetMapping("/login")
	String login() {
		return "login";
	}
	
	@GetMapping("/")
	public String redirectLogin() {
		return "redirect:login";
	}
	
	@GetMapping("/forgotPassword")
	public String forgotPassword(){
		return "forgotPassword";
	}
	
	@PostMapping("/recoverPassword")
	public String requestPasswordReset(RedirectAttributes redirectAttributes
			,HttpServletRequest request) {
		System.out.println("Forgot Password");
		String email =request.getParameter("email");
		User userWithEmail = userRepo.findByEmail(email);
		
		//mailService.sendCreationEmail(userWithEmail);
		System.out.println(email);
		if(userWithEmail ==null) {
			redirectAttributes.addFlashAttribute("message","No Email Id Found ");
			redirectAttributes.addFlashAttribute("alertClass", "failure");
			return "redirect:forgotPassword";
		}
		mailService.sendPasswordResetMail(userService.requestPasswordReset(email).get());
		redirectAttributes.addFlashAttribute("successMsg","Password reset mail send on registered Email Address ");
		redirectAttributes.addFlashAttribute("alertClass", "Done");
		return "redirect:forgotPassword";
	}
	
	@GetMapping("/reset/finish")
	public String getRestPasswordForm(@RequestParam String key
										,Model theModel
										,RedirectAttributes redirectAttributes) {
		//log.debug("Request to Rest Password");
		
		//Check if Reset Key is Present
		Optional<User> userWithResetKey =  userRepo.findOneByResetKey(key);
		if(!userWithResetKey.isPresent()) {
			redirectAttributes.addFlashAttribute("message","No Reset Key Found");
			//redirectAttributes.addFlashAttribute("alertClass", Constants.FAILEDALERTCLASS);
			return "redirect:/login";
		}
		// create model attribute to bind form data
		KeyAndPassword reset = new KeyAndPassword();
		reset.setKey(key);
		theModel.addAttribute("reset", reset);
		return "front/reset";
	}
	
	@PostMapping("/reset/finish/final")
	public String finishPasswordReset(
			@ModelAttribute("reset") @Valid KeyAndPassword theKeyPassword,
			BindingResult bindingResult,
			RedirectAttributes redirectAttributes
			,HttpServletRequest request
			,Model theModel
			) {
		System.out.println("Hello");
		//log.debug("Request to Update Reset Password");
		String message = "";
		boolean isPresent = true;
		if (bindingResult.hasErrors()) {
			redirectAttributes.addFlashAttribute("message","Password size must be between 4 and 100 ");
			//redirectAttributes.addFlashAttribute("alertClass", Constants.FAILEDALERTCLASS);
			return "redirect:/api/reset/finish?key="+theKeyPassword.getKey();
		}
		else {
			
			//Check if Reset Key is Present
			Optional<User> userWithResetKey =  userRepo.findOneByResetKey(theKeyPassword.getKey());
			if(!userWithResetKey.isPresent()) {
				message = "No Reset Key Found";
				isPresent = false;
			}
			
			if(isPresent) {
				userWithResetKey =  userService.completePasswordReset(theKeyPassword.getPassword(), theKeyPassword.getKey());
				//message=Constants.PASSWORD_RESET_SUCCESSFULLY;
			}
			
		}
		redirectAttributes.addFlashAttribute("message",message);
		//redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
		return "redirect:/login";
		
	}
	
	
}
