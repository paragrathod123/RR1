package com.ey.raroc.Service;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.ey.raroc.DTO.*;
import com.ey.raroc.Entity.CustomerDetails;
import com.ey.raroc.Entity.CustomerOperationDetails;
import com.ey.raroc.Entity.CustomerRarocDetails;
import com.ey.raroc.Entity.LeadMst;
import com.ey.raroc.Entity.RarocBasicParamMst;
import com.ey.raroc.Repository.CustomerDetailsRepository;
import com.ey.raroc.Repository.CustomerOperationDetailsRepository;
import com.ey.raroc.Repository.CustomerRarocDetailsRepository;
import com.ey.raroc.Repository.RarocBasicParameterRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class CustomerDetailsService {
	
	@PersistenceContext
    private EntityManager entityManager;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private LeadService leadService;
	
	@Autowired
	private RarocBasicParameterRepository rarocBasicParameterRepository;
	
	@Autowired
	private CustomerDetailsRepository customerDetailsRepository;
	
	@Autowired
	private CustomerOperationDetailsRepository customerOperationDetailsRepository;
	
	@Autowired
	private CustomerRarocDetailsRepository customerRarocDetailsRepository;
	
	public List<CustomerDetails> getAllCustomerDetails(){
		return customerDetailsRepository.findAll();
	}
	
	public CustomerDetails findCustomerDetailById(Long id) {
		return customerDetailsRepository.findById(id).get();
	}
	
	
	public CustomerDetails createCustomerDetails(CustomerDetails theCustomer , HttpServletRequest request) {
		
		HttpSession session =  request.getSession();
		
		CustomerDetails customerDetails =  new CustomerDetails();
		
		Long leadId  = this.getLongValue(request.getParameter("leadId"));
		
		LeadMst lead =  leadService.findLeadById(leadId);
		
		Double loanAmount  =  this.getDoubleValue(request.getParameter("loanAmount"));
		Integer tenure =  this.getIntegerValue(request.getParameter("tenure"));
		Integer cibilScore =  this.getIntegerValue(request.getParameter("cibilScore"));
		Double preApprovedIntrestRate =  this.getDoubleValue(request.getParameter("preApprovedIntrestRate"));
		Double changeIntrestRate =  this.getDoubleValue(request.getParameter("changeIntrestRate"));
		Double adjustedIntrestRate =  this.getDoubleValue(request.getParameter("adjustedIntrestRate"));
		Double pdRate =  this.getDoubleValue(request.getParameter("pdRate"));
		Double thresholdRarocRate=  this.getDoubleValue(request.getParameter("thresholdRarocRate")); 
		Double deviationValue =  this.getDoubleValue(request.getParameter("deviationValue"));
		Integer isApprovalNeeded =  this.getIntegerValue(request.getParameter("isApprovalNeeded"));
		Double expectedRaroc=  this.getDoubleValue(request.getParameter("expectedRaroc"));
		
		customerDetails.setLead(lead);
		customerDetails.setLoanAmount(loanAmount);
		customerDetails.setTenure(tenure);
		customerDetails.setCibilScore(cibilScore);
		customerDetails.setPreApprovedIntrestRate(preApprovedIntrestRate);
		customerDetails.setChangeIntrestRate(changeIntrestRate);
		customerDetails.setAdjustedIntrestRate(adjustedIntrestRate);
		customerDetails.setPdRate(pdRate);
		customerDetails.setThresholdRarocRate(thresholdRarocRate);
		customerDetails.setExpectedRaroc(expectedRaroc);
		customerDetails.setDeviationValue(deviationValue);
		customerDetails.setApprovedFlag(2);
		customerDetails.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
		customerDetails.setCreatedDate(Instant.now());
		customerDetails.setIsApprovalNeeded(isApprovalNeeded);
		customerDetailsRepository.save(customerDetails);


		CustomerOperationDetails customerOperationDetails = new CustomerOperationDetails();
		Double loanProcessingCost =  this.getDoubleValue(request.getParameter("loanProcessingCost"));
		Double variableCost =  this.getDoubleValue(request.getParameter("variableCost"));
		Double loanServicingCost =  this.getDoubleValue(request.getParameter("loanServicingCost"));
		Double monitoringCost =  this.getDoubleValue(request.getParameter("monitoringCost"));
		Double totalOperationCost =  this.getDoubleValue(request.getParameter("totalOperationCost"));
		
		customerOperationDetails.setLead(lead);
		customerOperationDetails.setCustomerOpDetails(customerDetails);
		customerOperationDetails.setLoanProcessingCost(loanProcessingCost);
		customerOperationDetails.setVariableCost(variableCost);
		customerOperationDetails.setLoanServicingCost(loanServicingCost);
		customerOperationDetails.setMonitoringCost(monitoringCost);
		customerOperationDetails.setTotalOperationCost(totalOperationCost);
		
		customerOperationDetailsRepository.save(customerOperationDetails);
		
		
		CustomerRarocDetails customerRarocDetails = new CustomerRarocDetails();
		Double loanBalance =  this.getDoubleValue(request.getParameter("loanAmount"));
		Double interestRate =  this.getDoubleValue(request.getParameter("interestRate"));
		Double interestIncome =  this.getDoubleValue(request.getParameter("interestIncome"));
		Double operatingExpense =  this.getDoubleValue(request.getParameter("operatingExpense"));
		Double expectedLosses =  this.getDoubleValue(request.getParameter("expectedLosses"));
		Double expectedLossRate =  this.getDoubleValue(request.getParameter("expectedLossRate"));
		Double interestExpenses =  this.getDoubleValue(request.getParameter("interestExpenses"));
		Double otherIncome =  this.getDoubleValue(request.getParameter("otherIncome"));
		Double netInterestIncome =  this.getDoubleValue(request.getParameter("netInterestIncome"));
		Double netProfit =  this.getDoubleValue(request.getParameter("netProfit"));
		Double economicCapital=  this.getDoubleValue(request.getParameter("economicCapital")); 
		Double returnOnEconomiccapital =  this.getDoubleValue(request.getParameter("returnOnEconomiccapital"));
		
		customerRarocDetails.setLead(lead);
		customerRarocDetails.setCustomerRaDetails(customerDetails);
		customerRarocDetails.setLoanBalance(loanBalance);
		customerRarocDetails.setInterestRate(interestRate);
		customerRarocDetails.setInterestIncome(interestIncome);
		customerRarocDetails.setOperatingExpense(operatingExpense);
		customerRarocDetails.setExpectedLosses(expectedLosses);
		customerRarocDetails.setExpectedLossRate(expectedLossRate);
		customerRarocDetails.setInterestExpenses(interestExpenses);
		customerRarocDetails.setOtherIncome(otherIncome);
		customerRarocDetails.setNetInterestIncome(netInterestIncome);
		customerRarocDetails.setNetProfit(netProfit);
		customerRarocDetails.setEconomicCapital(economicCapital);
		customerRarocDetails.setReturnOnEconomiccapital(returnOnEconomiccapital);
		customerRarocDetails.setExpectedRaroc(expectedRaroc);
		
		customerRarocDetailsRepository.save(customerRarocDetails);
		
		
		return theCustomer;
	}
	
	
    public String getStringValue(String a_strParam)
    {
        if ((a_strParam != null) && !a_strParam.trim().equals(""))
        {
            a_strParam = a_strParam.trim();
                    // added to support UTF characters
                    try
                    {
                      a_strParam = new String(a_strParam.getBytes("ISO8859_1"), "UTF-8");
                    }
                    catch (UnsupportedEncodingException uee)
                    {
                           System.out.println("******Error in Action.java,getStringValue()******"+uee);
                    }

        }
        else
        {
            a_strParam = null;
        }

        return a_strParam;
    }

    

    public Short getShortValue(String a_strParam)
    {
        if ((a_strParam != null) && !a_strParam.trim().equals(""))
        {
            return new Short(a_strParam.trim());
        }

        return null;
    }

   
    public Long getLongValue(String a_strParam)
    {
        if ((a_strParam != null) && !a_strParam.trim().equals(""))
        {
            return new Long(a_strParam.replaceAll(",","").trim());
        }

        return null;
    }

    
    public Double getDoubleValue(String a_strParam)
    {
        if ((a_strParam != null) && !a_strParam.trim().equals(""))
        {
            return new Double(a_strParam.replaceAll(",","").trim());
        }

        return null;
    }

    
    public Integer getIntegerValue(String a_strParam)
    {
        if ((a_strParam != null) && !a_strParam.trim().equals(""))
        {
            return new Integer(a_strParam.replaceAll(",","").trim());
        }

        return null;
    }

    
    public Timestamp getTimestampValue(String a_strParam)
    {
        if ((a_strParam != null) && !a_strParam.trim().equals(""))
        {
            return Timestamp.valueOf(a_strParam.trim());
        }

        return null;
    }


	
	//Below Mathod for Ajax Call Return 
	public CustomerDetailDTO getCalculatedRaroc(SearchCriteria searchCriteria) {
		
		System.out.println("searchCriteria.getLeadId()  "+ searchCriteria.getLeadId());
		
		CustomerDetailDTO customerDetailDTO = new CustomerDetailDTO();
		
		Long leadId = searchCriteria.getLeadId();
		
		LeadDTO leadDto =  leadService.getLeadResult(leadId);
		
		Double preApprovedIntrestRate = 0d;
		Double changeIntrestRate = 0d;
		Double adjustedIntrestRate = 0d;
		Double pdRate = 0d;
		Double thresholdRarocRate = 0d;
		Double expectedRarocMaster = 0d;
		Double deviationValue = 0d;
		Integer isApprovalNeeded = 0;
		
		//Getting Basic Parame 
		 RarocBasicParamMst masterData =  rarocBasicParameterRepository.findAll().get(0);
		
		//Below Code Starts for Customer Details 
		
			//Start Getting Pre approved interest rate 
				preApprovedIntrestRate = this.jdbcTemplate.queryForObject(
		        "SELECT intrest_rate_value FROM intrest_rate_matrix_mst  Where (? Between credit_from AND credit_to) "
		        + " AND  (? between loan_amt_from and loan_amt_to) ", 
		        new Object[]{searchCriteria.getCibilScore(),searchCriteria.getLoanAmount()}, Double.class);
				System.out.println("preApprovedIntrestRate   "+preApprovedIntrestRate);
				
			
			//Start Getting PD RATE 
				pdRate = this.jdbcTemplate.queryForObject(
				        "Select pd_rate from pdmst Where (? Between credit_from AND credit_to) ", 
				        new Object[]{searchCriteria.getCibilScore()}, Double.class);
						System.out.println("pdRate   "+pdRate);
				
			
			//Start Getting threshold
			   thresholdRarocRate	=	this.jdbcTemplate.queryForObject(
						        "Select raroc_threshold_value from raroc_threshold_mst where segment_id = ? and producclasstid = ? ", 
						        new Object[]{leadDto.getSegmentId(),leadDto.getProductClassId()}, Double.class);
								System.out.println("thresholdRarocRate   "+thresholdRarocRate);
						
			// Start for adjustedIntrestRate
			   adjustedIntrestRate =  	searchCriteria.getChangeInterestRate() +  	preApprovedIntrestRate;
			   
			   customerDetailDTO.setPreApprovedIntrestRate(preApprovedIntrestRate);
			   customerDetailDTO.setPdRate(pdRate);
			   customerDetailDTO.setThresholdRarocRate(thresholdRarocRate);
			   customerDetailDTO.setLeadId(searchCriteria.getLeadId());
			   customerDetailDTO.setChangeIntrestRate(searchCriteria.getChangeInterestRate());
			   customerDetailDTO.setAdjustedIntrestRate(adjustedIntrestRate);
								
		//Ends for Customer Details 
			   
		//Start for Operating cost cal	
			   CustomerOperationDetailDTO customerOperationDetailDTO =  new CustomerOperationDetailDTO();
			    Double loanProcessingCost =  0d;
				Double variableCost =  0d;
				Double loanServicingCost =  0d;
				Double monitoringCost =  0d;
				Double totalOperationCost =  0d;
			   
			   
			     loanProcessingCost = masterData.getLoanProcessingCost();
			     
			     variableCost =  searchCriteria.getLoanAmount() * (masterData.getVariableCost() / 100);
			     
			     loanServicingCost =  searchCriteria.getTenure() * masterData.getLoanServicingCost();
			     
			     monitoringCost =  searchCriteria.getTenure() * masterData.getMonitoringCostValue();
			     
			     totalOperationCost = (loanProcessingCost + variableCost +  loanServicingCost +  monitoringCost );
			     
			     customerOperationDetailDTO.setLeadId(leadId);
			     customerOperationDetailDTO.setLoanProcessingCost(loanProcessingCost);
			     customerOperationDetailDTO.setVariableCost(variableCost);
			     customerOperationDetailDTO.setLoanServicingCost(loanServicingCost);
			     customerOperationDetailDTO.setMonitoringCost(monitoringCost);
			     customerOperationDetailDTO.setTotalOperationCost(totalOperationCost);
			     
			     customerDetailDTO.setCustomerOperationDetailDTO(customerOperationDetailDTO);
			     
		//End for Operating cost cal
			     
		//Start for RAROC CAL
			    CustomerRarocDetailDTO customerRarocDetailDTO =  new CustomerRarocDetailDTO(); 
			    Double loanBalance =  searchCriteria.getLoanAmount();
			 	Double interestRate = adjustedIntrestRate ;
			 	Double interestIncome =  0d;
			 	Integer tenure = searchCriteria.getTenure();
			 	Double operatingExpense =  totalOperationCost;
			 	Double expectedLosses =  0d;
			 	Double expectedLossRate =  0d;
			 	Double interestExpenses =  0d;
			 	Double otherIncome=  0d;
			 	Double netInterestIncome=  0d;
			 	Double netProfit=  0d;
			 	Double economicCapital=  0d;
			 	Double returnOnEconomiccapital=  0d;
			 	Double expectedRaroc=  0d;
			 	
			 	
			 	
			 	
			 	interestIncome = (interestRate * (loanBalance / 100));
			 	
			 	System.out.println("interestIncome  "+ interestIncome);
			 	
			 	customerRarocDetailDTO.setInterestIncome(interestIncome);
			 	
			 	expectedLossRate =  (pdRate / 100) * (masterData.getIndustryDefaultRate() /100 );
			 	
			 	expectedLosses =  (loanBalance * expectedLossRate);
			 	
			 	interestExpenses = (loanBalance * (masterData.getRiskFreeRate() / 100));
			 	
			 	customerRarocDetailDTO.setInterestExpenses(interestExpenses);
			 	
			 	netInterestIncome = (interestIncome - interestExpenses);
			 	
			 	netProfit = (netInterestIncome - expectedLosses - operatingExpense);
			 	
			 	economicCapital =  (loanBalance * (masterData.getEconomicCapitalRate() / 100));
			 	
			 	returnOnEconomiccapital =  (economicCapital * (masterData.getReturnOnCapitalRate() / 100));
			 	
			 	
			 	expectedRaroc =  (( returnOnEconomiccapital + netProfit  ) / economicCapital ) * 100;
			 	
			 	customerRarocDetailDTO.setLeadId(leadId);
			 	customerRarocDetailDTO.setLoanBalance(loanBalance);
			 	customerRarocDetailDTO.setInterestRate(interestRate);
			 	
			 	customerRarocDetailDTO.setTenure(tenure);
			 	customerRarocDetailDTO.setOperatingExpense(operatingExpense);
			 	customerRarocDetailDTO.setExpectedLosses(expectedLosses);
			 	customerRarocDetailDTO.setExpectedLossRate(expectedLossRate);
			 	customerRarocDetailDTO.setOtherIncome(otherIncome);
			 	customerRarocDetailDTO.setNetInterestIncome(netInterestIncome);
			 	customerRarocDetailDTO.setNetProfit(netProfit);
			 	customerRarocDetailDTO.setEconomicCapital(economicCapital);
			 	customerRarocDetailDTO.setReturnOnEconomiccapital(returnOnEconomiccapital);
			 	customerRarocDetailDTO.setExpectedRaroc(expectedRaroc);
			 	
			 	customerDetailDTO.setCustomerRarocDetailDTO(customerRarocDetailDTO);
		//End for RAROC CAL	     
		
		//Set deviation start 
			    expectedRarocMaster = expectedRaroc;
				deviationValue = (expectedRaroc - thresholdRarocRate);
				
				if(deviationValue >= 0d) {
					isApprovalNeeded = 0;
				}else if(deviationValue < 0d) {
					isApprovalNeeded = 1;
				}
				
				customerDetailDTO.setExpectedRaroc(expectedRarocMaster);
				customerDetailDTO.setDeviationValue(deviationValue);
				customerDetailDTO.setIsApprovalNeeded(isApprovalNeeded);
		//Set deviation ends
				
		return customerDetailDTO;
	}

}
