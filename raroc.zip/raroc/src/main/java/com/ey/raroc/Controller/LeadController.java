package com.ey.raroc.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ey.raroc.Entity.LeadMst;
import com.ey.raroc.Entity.User;
import com.ey.raroc.Repository.LeadRepository;
import com.ey.raroc.Service.LeadService;
import com.ey.raroc.helper.Constants;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;


@RequestMapping("/lead")
@Controller
public class LeadController {
	
	@Autowired
	private LeadService leadService;
	
	@Autowired
	private LeadRepository leadRepository;

	@GetMapping("/listleads")
	public String listLeads(Model model) {
	    List<LeadMst> listLeads = leadRepository.findAll();
	    model.addAttribute("listLeads", listLeads);
	     
	    return "lead/listLead";
	}
	
	@GetMapping("/addLead")
	public String addLead(Model model) {
		LeadMst lead = new LeadMst();
		model.addAttribute("lead", lead);
	    return "lead/addLead";
	}
	
	@PostMapping("/createLead")
	public String createLead(@ModelAttribute("lead") @jakarta.validation.Valid LeadMst theLead
			,BindingResult bindingResult
			,@RequestParam(required=false, value="addbutn") String addFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request){
		System.out.println("Request to Add new Lead" + theLead);
		String succesMessage=""; String errorMessage="";
		if(bindingResult.hasErrors()) {
			return "/lead/addLead";
		}
		else {
			
			if(leadRepository.findOneByLeadNoIgnoreCase(theLead.getLeadNo()).isPresent()) {
				errorMessage = "Lead No is already in use!";
				System.out.println("I am here ");
				redirectAttributes.addFlashAttribute("errorMsg",errorMessage);
			}else {
				succesMessage = Constants.ADD_SUCCESSFULLY;
				LeadMst L =  leadService.createLead(theLead, request);
				redirectAttributes.addFlashAttribute("succesMessage", succesMessage);
			}
			//Step 3 use a redirect to prevent duplicate submissions & Add Messages
			redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
			return "redirect:/lead/listleads";
				
		}
   }
	
	@GetMapping("/editLead")
	public String showFormForUpdate(@RequestParam("leadId") Long id,Model theModel,HttpServletRequest request) {
		System.out.println("In Edit lead  ");
		LeadMst lead = new LeadMst();
		lead =  leadService.findLeadById(id);
		theModel.addAttribute("lead",lead);
		return "/lead/editLead";
	}
	
	@PostMapping("/updateLead")
	public String updateLead(@ModelAttribute("lead") @jakarta.validation.Valid LeadMst theLead
			,BindingResult bindingResult
			,@RequestParam(required=false, value="addbutn") String addFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request){
		System.out.println("Request to Edit Lead" + theLead);
		String succesMessage=""; String errorMessage="";
		if(bindingResult.hasErrors()) {
			return "/lead/editLead";
		}
		else {
			Optional<LeadMst> optionalLeadMst =  leadRepository.findOneByLeadNoIgnoreCase(theLead.getLeadNo());
			if(optionalLeadMst.isPresent() && (!theLead.getLeadId().equals(optionalLeadMst.get().getLeadId()))) {
				errorMessage = "Lead No is already in use!";
				System.out.println("I am here ");
				redirectAttributes.addFlashAttribute("errorMsg",errorMessage);
			}else {
				succesMessage = Constants.UPDATE_SUCCESSFULLY;
				LeadMst L =  leadService.updateLead(theLead, request);
				redirectAttributes.addFlashAttribute("succesMessage", succesMessage);
			}
			//Step 3 use a redirect to prevent duplicate submissions & Add Messages
			redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
			return "redirect:/lead/listleads";
				
		}
   }
}
