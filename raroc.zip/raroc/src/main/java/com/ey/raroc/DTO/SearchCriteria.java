package com.ey.raroc.DTO;

public class SearchCriteria {
	
	
	Long leadId;
	Double loanAmount;
	Integer tenure;
	Integer cibilScore;
	Double changeInterestRate;
	Double otherIncome;
	
	
	public Long getLeadId() {
		return leadId;
	}
	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	public Double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(Double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public Integer getTenure() {
		return tenure;
	}
	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}
	public Integer getCibilScore() {
		return cibilScore;
	}
	public void setCibilScore(Integer cibilScore) {
		this.cibilScore = cibilScore;
	}
	public Double getChangeInterestRate() {
		return changeInterestRate;
	}
	public void setChangeInterestRate(Double changeInterestRate) {
		this.changeInterestRate = changeInterestRate;
	}
	public Double getOtherIncome() {
		return otherIncome;
	}
	public void setOtherIncome(Double otherIncome) {
		this.otherIncome = otherIncome;
	}
	
	
	

}
