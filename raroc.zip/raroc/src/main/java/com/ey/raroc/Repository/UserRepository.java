package com.ey.raroc.Repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ey.raroc.Entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long>{
	
	   public User findByEmail( String email);

	   public List<User> findAll();
	   
	   Optional<User> findOneByResetKey(String key);
	   
	   @Modifying
	   @Query("update User u set u.name = ?1, u.designationName = ?2, u.active = ?3 where u.id = ?4")
	   void setUserInfoById(String name, String designationName,int status, Long userId);
	   
		@Query("SELECT cc.email FROM User cc  WHERE cc.name like %:name%")
		public List<User> findAllUserByName(@Param("name") String name);
		
		@Modifying
		@Query("Update User u set u.active = ?1 where u.id = ?2")
		public void updateActvieStatus(int status, Long id);
		
		Optional<User> findOneByEmailIgnoreCase(String email);
}
