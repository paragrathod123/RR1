package com.ey.raroc.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ey.raroc.Entity.Account;
import com.ey.raroc.Repository.AccountRepository;
import com.ey.raroc.Service.AccountService;

@Controller
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	private AccountRepository accountRepo;
	
	@Autowired
	private  AccountService accountService;
	
	@GetMapping("/listAccounts")
	public String listProject(Model model) {
	    List<Account> listAccount = accountRepo.findAll();
	    model.addAttribute("account", listAccount);
	    return "account/listAccounts";
}
	
	@GetMapping("/accountMaster")
	public String addAccount(Model model) {
		Account accountMaster = new Account();
		model.addAttribute("account", accountMaster);
	    return "account/accountMaster";
}

}
