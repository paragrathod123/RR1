package com.ey.raroc.DTO;

public class AjaxResponseBody {
	
	String msg;
	CustomerDetailDTO result;
	
	
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public CustomerDetailDTO getResult() {
		return result;
	}
	public void setResult(CustomerDetailDTO result) {
		this.result = result;
	}
	
	

}
