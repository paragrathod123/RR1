package com.ey.raroc.restcontroller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ey.raroc.DTO.AjaxResponseBody;
import com.ey.raroc.DTO.AjaxResponseLeadBody;
import com.ey.raroc.DTO.CustomerDetailDTO;
import com.ey.raroc.DTO.LeadDTO;
import com.ey.raroc.DTO.SearchCriteria;
import com.ey.raroc.DTO.SearchLeadCriteria;
import com.ey.raroc.Service.CustomerDetailsService;
import com.ey.raroc.Service.LeadService;

@RestController
public class SearchController {

	@Autowired	
	private LeadService leadService;
	
	@Autowired
	private CustomerDetailsService customerDetailsService;
	
	@PostMapping("/api/searchLead")
    public ResponseEntity<?> getSearchLeadResultViaAjax( @RequestBody SearchLeadCriteria search, Errors errors) {

        AjaxResponseLeadBody result = new AjaxResponseLeadBody();

        //If error, just return a 400 bad request, along with the error message
        if (errors.hasErrors()) {

            result.setMsg(errors.getAllErrors().stream().map(x -> x.getDefaultMessage()).collect(Collectors.joining(",")));
            return ResponseEntity.badRequest().body(result);

        }
        
        LeadDTO lead =   leadService.getLeadResult(search.getLeadId());

        if (lead ==  null ) {
            result.setMsg("no user found!");
        } else {
            result.setMsg("success");
        }
        result.setResult(lead);

        return ResponseEntity.ok(result);

    }
	
	@PostMapping("/api/customerDetails")
    public ResponseEntity<?> getcustomerDetailsResultViaAjax( @RequestBody SearchCriteria search, Errors errors) {

		AjaxResponseBody result = new AjaxResponseBody();

        //If error, just return a 400 bad request, along with the error message
        if (errors.hasErrors()) {

            result.setMsg(errors.getAllErrors().stream().map(x -> x.getDefaultMessage()).collect(Collectors.joining(",")));
            return ResponseEntity.badRequest().body(result);

        }
        
        CustomerDetailDTO lead =   customerDetailsService.getCalculatedRaroc(search);

        if (lead ==  null ) {
            result.setMsg("no user found!");
        } else {
            result.setMsg("success");
        }
        result.setResult(lead);

        return ResponseEntity.ok(result);

    }
}

