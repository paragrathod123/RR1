package com.ey.raroc.Entity;



import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "pagemst")
public class PageMst {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pageid")
	private Long pageId;
	
	
	@Column(name="name")
	private String name;
	
	@Column(name="active_status")
	private int activeStatus;
	
	@JsonBackReference
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="menuid")
	private MenuMaster menu;

	@Column(name="page_url")
	private String pageUrl;
	
	@Column(name="page_tag_name")
	private String pageTagName;
	
	
	

	public Long getPageId() {
		return pageId;
	}


	public void setPageId(Long pageId) {
		this.pageId = pageId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getActiveStatus() {
		return activeStatus;
	}


	public void setActiveStatus(int activeStatus) {
		this.activeStatus = activeStatus;
	}


	public MenuMaster getMenu() {
		return menu;
	}


	public void setMenu(MenuMaster menu) {
		this.menu = menu;
	}


	public String getPageUrl() {
		return pageUrl;
	}


	public void setPageUrl(String pageUrl) {
		this.pageUrl = pageUrl;
	}


	public String getPageTagName() {
		return pageTagName;
	}


	public void setPageTagName(String pageTagName) {
		this.pageTagName = pageTagName;
	}

	
	
	

}