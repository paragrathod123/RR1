package com.ey.raroc.Service;

import java.nio.charset.StandardCharsets;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import com.ey.raroc.Entity.User;

import jakarta.mail.internet.MimeMessage;

@Service
public class MailService {

	private final JavaMailSender javaMailSender;

    private final MessageSource messageSource;

    private final SpringTemplateEngine templateEngine;
    
    @Value("${mail.baseUrl}")
    private String baseUrl ;
    
    public MailService( JavaMailSender javaMailSender,
            MessageSource messageSource, SpringTemplateEngine templateEngine) {
        this.javaMailSender = javaMailSender;
        this.messageSource = messageSource;
        this.templateEngine = templateEngine;
    }
    
    
    @Async
    public void sendEmail(String to, String subject, String content, boolean isMultipart, boolean isHtml) {
        System.out.println("Send email[multipart '{}' and html '{}'] to '{}' with subject '{}' and content={}"+
            isMultipart+ isHtml+to+subject+ content);

        // Prepare message using a Spring helper
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        try {
            MimeMessageHelper message = new MimeMessageHelper(mimeMessage, isMultipart, StandardCharsets.UTF_8.name());
            message.setTo(to);
            message.setFrom("tool.vms@gmail.com");
            message.setSubject(subject);
            message.setText(content, isHtml);
            javaMailSender.send(mimeMessage);
            System.out.println("Sent email to User '{}'"+ to);
        } catch (Exception e) {
           
        	System.out.println("Email could not be sent to user '{}': {}"+ to+" "+e.getMessage());
            
        }
    }

    @Async
    public void sendEmailFromTemplate(User user, String templateName, String titleKey) {
    	Locale locale = Locale.forLanguageTag("en");//en
        Context context = new Context();
        context.setVariable("user", user);
        context.setVariable("baseUrl", baseUrl);
        String content = templateEngine.process(templateName, context);
        String subject = messageSource.getMessage(titleKey, null, locale);
        sendEmail(user.getEmail(), subject, content, false, true);
    }
    
    @Async
    public void sendCreationEmail(User user) {
        sendEmailFromTemplate(user, "mail/creationEmail", "email.activation.title");
    }
    
    @Async
    public void sendPasswordResetMail(User user) {
        
        sendEmailFromTemplate(user, "mail/passwordResetEmail", "email.reset.title");
    }

}
