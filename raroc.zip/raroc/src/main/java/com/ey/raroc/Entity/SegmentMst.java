package com.ey.raroc.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "segmentmst")
public class SegmentMst {
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "segment_id")
	private Long segmentId;
	
	
	@Column(name = "segment_name")
	private String segmentName;
	
	@Column(name = "active_flag")
	private Integer activeStatus ;

	public Long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}

	public String getSegmentName() {
		return segmentName;
	}

	public void setSegmentName(String segmentName) {
		this.segmentName = segmentName;
	}

	public Integer getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(Integer activeStatus) {
		this.activeStatus = activeStatus;
	}

	@Override
	public String toString() {
		return "SegmentMst [segmentId=" + segmentId + ", segmentName=" + segmentName + ", activeStatus=" + activeStatus
				+ "]";
	}
	
	
	
	

}
