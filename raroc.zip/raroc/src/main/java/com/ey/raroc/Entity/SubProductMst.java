package com.ey.raroc.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "subproductmst")
public class SubProductMst {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "sub_product_id")
	private Long subProductId;
	
	@Column(name = "sub_product_name")
	private String subProductName;
	
	@Column(name = "active_flag")
	private Integer activeStatus ;

	public Long getSubProductId() {
		return subProductId;
	}

	public void setSubProductId(Long subProductId) {
		this.subProductId = subProductId;
	}

	public String getSubProductName() {
		return subProductName;
	}

	public void setSubProductName(String subProductName) {
		this.subProductName = subProductName;
	}

	public Integer getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(Integer activeStatus) {
		this.activeStatus = activeStatus;
	}

	@Override
	public String toString() {
		return "SubProductMst [subProductId=" + subProductId + ", subProductName=" + subProductName + ", activeStatus="
				+ activeStatus + "]";
	}
	
	
	
	

}
