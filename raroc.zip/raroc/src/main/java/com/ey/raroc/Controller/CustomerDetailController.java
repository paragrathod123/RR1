package com.ey.raroc.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ey.raroc.Entity.CustomerDetails;
import com.ey.raroc.Entity.LeadMst;
import com.ey.raroc.Service.CustomerDetailsService;
import com.ey.raroc.helper.Constants;

import jakarta.servlet.http.HttpServletRequest;

@RequestMapping("/customers")
@Controller
public class CustomerDetailController {
	
	
	@Autowired
	private CustomerDetailsService customerDetailsService;
	
	@GetMapping("/listCustomer")
	public String listCustomers(Model model) {
		List<CustomerDetails> listCustomerDetails =  customerDetailsService.getAllCustomerDetails();
		model.addAttribute("listCustomerDetails", listCustomerDetails);
		return "customer/listCustomer";
	}
	
	@GetMapping("/addCustomerDetails")
	public String addCustomerDetails(Model model) {
		CustomerDetails customerDetails = new CustomerDetails();
		model.addAttribute("customerDetails", customerDetails);
	    return "customer/addCustomer";
	}
	
	@PostMapping("/createCustomer")
	public String createCustomerDetails(@ModelAttribute("customerDetails") @jakarta.validation.Valid CustomerDetails theCustomerDetails
			,BindingResult bindingResult
			,@RequestParam(required=false, value="addbutn") String addFlag
			,RedirectAttributes redirectAttributes
			,HttpServletRequest request){
		System.out.println("Request to Add new CustomerDetails" + theCustomerDetails);
		String succesMessage=""; String errorMessage="";
		
			
			
				succesMessage = Constants.ADD_SUCCESSFULLY;
				CustomerDetails L =  customerDetailsService.createCustomerDetails(theCustomerDetails, request);
				redirectAttributes.addFlashAttribute("succesMessage", succesMessage);
			
			//Step 3 use a redirect to prevent duplicate submissions & Add Messages
			redirectAttributes.addFlashAttribute("alertClass", Constants.SUCCESSALERTCLASS);
			return "redirect:/customers/listCustomer";
				
   }
	
	@GetMapping("/editCustomerDetails")
	public String showFormForUpdate(@RequestParam("customerDetailsId") Long id,Model theModel,HttpServletRequest request) {
		System.out.println("In Edit editCustomerDetails  ");
		CustomerDetails customerDetails = new CustomerDetails();
		customerDetails =  customerDetailsService.findCustomerDetailById(id);
		theModel.addAttribute("customerDetails",customerDetails);
		return "customer/editCustomer";
	}

}
