package com.ey.raroc.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ey.raroc.Entity.LeadMst;

public interface LeadRepository extends JpaRepository<LeadMst, Long>{
	
	Optional<LeadMst> findOneByLeadNoIgnoreCase(String leadNo);

}
