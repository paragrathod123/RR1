package com.ey.raroc.Utils;

import java.util.List;

import com.ey.raroc.Entity.LeadMst;
import com.ey.raroc.Entity.ProductClassMst;
import com.ey.raroc.Entity.Role;
import com.ey.raroc.Entity.SegmentMst;

public interface GetUserName {
	
	String getUserName(int id);
	
	String getNameByUserName(String userId);
	
	String getName(int id);

	List<Role> getAllRoles();
	
	List<SegmentMst> getAllActiveSegment(int activeStatus);
	
	List<ProductClassMst> getAllActiveProductClass(int activeStatus);
	
	List<LeadMst> getAllLeads();

}
