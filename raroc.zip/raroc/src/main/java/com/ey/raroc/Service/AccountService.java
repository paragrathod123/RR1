package com.ey.raroc.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.raroc.Entity.Account;
import com.ey.raroc.Repository.AccountRepository;
import com.ey.raroc.Repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class AccountService {
	
	@Autowired
	private AccountRepository accountRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private MailService mailService;
	
	public Account getByid(Long id) {
		return accountRepo.findById(id).get();
	}

}
