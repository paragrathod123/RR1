package com.ey.raroc.Entity;

import java.time.Instant;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "customerdetails")
public class CustomerDetails {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "customerdetailsid")
	private Long customerDetailsId;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "leadid")
	private LeadMst lead;
	
	@Column(name = "loan_amount")
	Double loanAmount;
	
	@Column(name = "tenure")
	Integer tenure;
	
	@Column(name = "cibilscore")
	Integer cibilScore;
	
	
	@Column(name = "pre_approved_intrest_rate")
	Double preApprovedIntrestRate;
	
	@Column(name = "change_intrest_rate")
	Double changeIntrestRate;
	
	@Column(name = "adjusted_intrest_rate")
	Double adjustedIntrestRate;
	
	@Column(name = "pd_rate")
	Double pdRate;
	
	@Column(name = "threshold_raroc_rate")
	Double thresholdRarocRate;
	
	@Column(name = "expected_raroc")
	Double expectedRaroc;
	
	@Column(name = "deviation_value")
	Double deviationValue;
	
	@Column(name = "isApprovalNeeded")
	Integer isApprovalNeeded;
	
	@OneToOne(mappedBy="customerOpDetails")
	CustomerOperationDetails customerOperationDetails;
	
	@OneToOne(mappedBy="customerRaDetails")
	CustomerRarocDetails customerRarocDetails;
	
	@Column(name = "created_by")
	private Integer createdBy;
	
	@Column(name = "created_date")
	private Instant createdDate ;
	
	@Column(name = "updated_by")
	private Integer updatedBy;
	
	@Column(name = "updated_date")
	private Instant updatedDate;
	
	@Column(name = "approved_flag")
	private Integer approvedFlag;

	public Long getCustomerDetailsId() {
		return customerDetailsId;
	}

	public void setCustomerDetailsId(Long customerDetailsId) {
		this.customerDetailsId = customerDetailsId;
	}

	public LeadMst getLead() {
		return lead;
	}

	public void setLead(LeadMst lead) {
		this.lead = lead;
	}

	public Double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(Double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public Integer getTenure() {
		return tenure;
	}

	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}

	public Integer getCibilScore() {
		return cibilScore;
	}

	public void setCibilScore(Integer cibilScore) {
		this.cibilScore = cibilScore;
	}

	public Double getPreApprovedIntrestRate() {
		return preApprovedIntrestRate;
	}

	public void setPreApprovedIntrestRate(Double preApprovedIntrestRate) {
		this.preApprovedIntrestRate = preApprovedIntrestRate;
	}

	public Double getChangeIntrestRate() {
		return changeIntrestRate;
	}

	public void setChangeIntrestRate(Double changeIntrestRate) {
		this.changeIntrestRate = changeIntrestRate;
	}

	public Double getAdjustedIntrestRate() {
		return adjustedIntrestRate;
	}

	public void setAdjustedIntrestRate(Double adjustedIntrestRate) {
		this.adjustedIntrestRate = adjustedIntrestRate;
	}

	public Double getPdRate() {
		return pdRate;
	}

	public void setPdRate(Double pdRate) {
		this.pdRate = pdRate;
	}

	public Double getThresholdRarocRate() {
		return thresholdRarocRate;
	}

	public void setThresholdRarocRate(Double thresholdRarocRate) {
		this.thresholdRarocRate = thresholdRarocRate;
	}

	public Double getExpectedRaroc() {
		return expectedRaroc;
	}

	public void setExpectedRaroc(Double expectedRaroc) {
		this.expectedRaroc = expectedRaroc;
	}

	public Double getDeviationValue() {
		return deviationValue;
	}

	public void setDeviationValue(Double deviationValue) {
		this.deviationValue = deviationValue;
	}

	public Integer getIsApprovalNeeded() {
		return isApprovalNeeded;
	}

	public void setIsApprovalNeeded(Integer isApprovalNeeded) {
		this.isApprovalNeeded = isApprovalNeeded;
	}

	public CustomerOperationDetails getCustomerOperationDetails() {
		return customerOperationDetails;
	}

	public void setCustomerOperationDetails(CustomerOperationDetails customerOperationDetails) {
		this.customerOperationDetails = customerOperationDetails;
	}

	public CustomerRarocDetails getCustomerRarocDetails() {
		return customerRarocDetails;
	}

	public void setCustomerRarocDetails(CustomerRarocDetails customerRarocDetails) {
		this.customerRarocDetails = customerRarocDetails;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Instant getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Instant updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Integer getApprovedFlag() {
		return approvedFlag;
	}

	public void setApprovedFlag(Integer approvedFlag) {
		this.approvedFlag = approvedFlag;
	}
	
	
	

	
	
}
