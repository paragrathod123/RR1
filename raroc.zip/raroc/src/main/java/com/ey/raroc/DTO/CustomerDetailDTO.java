package com.ey.raroc.DTO;

public class CustomerDetailDTO {
	
	
	Long leadId;
	Double preApprovedIntrestRate;
	Double changeIntrestRate;
	Double adjustedIntrestRate;
	Double pdRate;
	Double thresholdRarocRate;
	
	Double expectedRaroc;
	Double deviationValue;
	Integer isApprovalNeeded;
	
	CustomerOperationDetailDTO customerOperationDetailDTO;
	CustomerRarocDetailDTO customerRarocDetailDTO;
	
	
	public Long getLeadId() {
		return leadId;
	}
	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	public Double getPreApprovedIntrestRate() {
		return preApprovedIntrestRate;
	}
	public void setPreApprovedIntrestRate(Double preApprovedIntrestRate) {
		this.preApprovedIntrestRate = preApprovedIntrestRate;
	}
	public Double getChangeIntrestRate() {
		return changeIntrestRate;
	}
	public void setChangeIntrestRate(Double changeIntrestRate) {
		this.changeIntrestRate = changeIntrestRate;
	}
	public Double getAdjustedIntrestRate() {
		return adjustedIntrestRate;
	}
	public void setAdjustedIntrestRate(Double adjustedIntrestRate) {
		this.adjustedIntrestRate = adjustedIntrestRate;
	}
	public Double getPdRate() {
		return pdRate;
	}
	public void setPdRate(Double pdRate) {
		this.pdRate = pdRate;
	}
	public Double getThresholdRarocRate() {
		return thresholdRarocRate;
	}
	public void setThresholdRarocRate(Double thresholdRarocRate) {
		this.thresholdRarocRate = thresholdRarocRate;
	}
	public CustomerOperationDetailDTO getCustomerOperationDetailDTO() {
		return customerOperationDetailDTO;
	}
	public void setCustomerOperationDetailDTO(CustomerOperationDetailDTO customerOperationDetailDTO) {
		this.customerOperationDetailDTO = customerOperationDetailDTO;
	}
	public CustomerRarocDetailDTO getCustomerRarocDetailDTO() {
		return customerRarocDetailDTO;
	}
	public void setCustomerRarocDetailDTO(CustomerRarocDetailDTO customerRarocDetailDTO) {
		this.customerRarocDetailDTO = customerRarocDetailDTO;
	}
	public Double getExpectedRaroc() {
		return expectedRaroc;
	}
	public void setExpectedRaroc(Double expectedRaroc) {
		this.expectedRaroc = expectedRaroc;
	}
	public Double getDeviationValue() {
		return deviationValue;
	}
	public void setDeviationValue(Double deviationValue) {
		this.deviationValue = deviationValue;
	}
	public Integer getIsApprovalNeeded() {
		return isApprovalNeeded;
	}
	public void setIsApprovalNeeded(Integer isApprovalNeeded) {
		this.isApprovalNeeded = isApprovalNeeded;
	}
	
	
	

}
