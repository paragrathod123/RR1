package com.ey.raroc.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.expression.DefaultWebSecurityExpressionHandler;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;


@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true, securedEnabled = true, jsr250Enabled = true)
public class WebSecurityConfig {
	
	  @Value("${spring.security.debug:false}")
	    boolean securityDebug;
	  
	  	@Autowired
		UserPermissionEvaluator userPermission;
		
		@Bean
		public UserDetailsService userDetailsService() {
			return new UserDetailsServiceImpl();
		}
		
	    @Bean
	    public BCryptPasswordEncoder passwordEncoder() {
	        return new BCryptPasswordEncoder();
	    }
		
		@Bean
		public AuthenticationManager authManager(HttpSecurity http, BCryptPasswordEncoder bCryptPasswordEncoder, UserDetailsService userDetailService) 
		  throws Exception {
		    return http
		      .getSharedObject(AuthenticationManagerBuilder.class)
		      .userDetailsService(userDetailService)
		      .passwordEncoder(bCryptPasswordEncoder)
		      .and()
		      .build()
		      ;
		}
		
		@Bean
	    public AuthenticationSuccessHandler myAuthenticationSuccessHandler(){
	        return new CustomAuthenticationSuccessHandler();
	    }
		
		@Bean
	    public AuthenticationFailureHandler myAuthenticationFailureHandler(){
	        return new CustomAuthenticationFailureHandler();
	    }
	
	@Bean
	SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception{
		    http
				.authorizeHttpRequests(auth->auth.requestMatchers("/images/**","/api/**").permitAll()
						.anyRequest().authenticated())
				.csrf(AbstractHttpConfigurer::disable)
				.formLogin(form->form.loginPage("/login").permitAll()
						   .defaultSuccessUrl("/home")
				           .usernameParameter("username")
				           .passwordParameter("password")
				           .failureUrl("/login?error=true")
				           .successHandler(myAuthenticationSuccessHandler())
				           .failureHandler(myAuthenticationFailureHandler()))
				.logout(logout -> logout                                                
		            .logoutUrl("/logout")                                            
		            .logoutSuccessUrl("/")                                                                      
		        );
			    
				return http.build();
	}
	
	@Bean
	public WebSecurityCustomizer webSecurityCustomizer() {
		DefaultWebSecurityExpressionHandler handler 
    	= new DefaultWebSecurityExpressionHandler();
		handler.setPermissionEvaluator(userPermission);
	    return (web) -> web.debug(securityDebug)
	    		.expressionHandler(handler)
	      .ignoring()
	      .requestMatchers("/resources/**","/i18n/**", "/js/**", "/static/**", "/dist/**","/css/**","/img/**","/scss/**","/webjars/**","/plugins/**");
	}
}
