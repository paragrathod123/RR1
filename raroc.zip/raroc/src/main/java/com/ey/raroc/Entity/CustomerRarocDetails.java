package com.ey.raroc.Entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "customer_raroc_details")
public class CustomerRarocDetails {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "customer_raroc_id")
	private Long CustomerRarocId;
	
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "customerdetailsid")
	private CustomerDetails customerRaDetails;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "leadid")
	private LeadMst lead;
	
	@Column(name = "loan_balance")
	Double loanBalance;
	
	@Column(name = "interest_rate")
	Double interestRate;
	
	@Column(name = "interest_income")
	Double interestIncome;
	
	@Column(name = "tenure")
	Integer tenure;
	
	@Column(name = "operating_expense")
	Double operatingExpense;
	
	@Column(name = "expected_losses")
	Double expectedLosses;
	
	@Column(name = "expected_loss_rate")
	Double expectedLossRate;
	
	@Column(name = "interest_expenses")
	Double interestExpenses;
	
	@Column(name = "other_income")
	Double otherIncome;
	
	@Column(name = "net_interest_income")
	Double netInterestIncome;
	
	@Column(name = "net_profit")
	Double netProfit;
	
	@Column(name = "economic_capital")
	Double economicCapital;
	
	@Column(name = "return_on_economic_capital")
	Double returnOnEconomiccapital;
	
	@Column(name = "expected_raroc")
	Double expectedRaroc;

	public Long getCustomerRarocId() {
		return CustomerRarocId;
	}

	public void setCustomerRarocId(Long customerRarocId) {
		CustomerRarocId = customerRarocId;
	}

	public CustomerDetails getCustomerRaDetails() {
		return customerRaDetails;
	}

	public void setCustomerRaDetails(CustomerDetails customerRaDetails) {
		this.customerRaDetails = customerRaDetails;
	}

	public LeadMst getLead() {
		return lead;
	}

	public void setLead(LeadMst lead) {
		this.lead = lead;
	}

	public Double getLoanBalance() {
		return loanBalance;
	}

	public void setLoanBalance(Double loanBalance) {
		this.loanBalance = loanBalance;
	}

	public Double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}

	public Double getInterestIncome() {
		return interestIncome;
	}

	public void setInterestIncome(Double interestIncome) {
		this.interestIncome = interestIncome;
	}

	public Integer getTenure() {
		return tenure;
	}

	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}

	public Double getOperatingExpense() {
		return operatingExpense;
	}

	public void setOperatingExpense(Double operatingExpense) {
		this.operatingExpense = operatingExpense;
	}

	public Double getExpectedLosses() {
		return expectedLosses;
	}

	public void setExpectedLosses(Double expectedLosses) {
		this.expectedLosses = expectedLosses;
	}

	public Double getExpectedLossRate() {
		return expectedLossRate;
	}

	public void setExpectedLossRate(Double expectedLossRate) {
		this.expectedLossRate = expectedLossRate;
	}

	public Double getInterestExpenses() {
		return interestExpenses;
	}

	public void setInterestExpenses(Double interestExpenses) {
		this.interestExpenses = interestExpenses;
	}

	public Double getOtherIncome() {
		return otherIncome;
	}

	public void setOtherIncome(Double otherIncome) {
		this.otherIncome = otherIncome;
	}

	public Double getNetInterestIncome() {
		return netInterestIncome;
	}

	public void setNetInterestIncome(Double netInterestIncome) {
		this.netInterestIncome = netInterestIncome;
	}

	public Double getNetProfit() {
		return netProfit;
	}

	public void setNetProfit(Double netProfit) {
		this.netProfit = netProfit;
	}

	public Double getEconomicCapital() {
		return economicCapital;
	}

	public void setEconomicCapital(Double economicCapital) {
		this.economicCapital = economicCapital;
	}

	public Double getReturnOnEconomiccapital() {
		return returnOnEconomiccapital;
	}

	public void setReturnOnEconomiccapital(Double returnOnEconomiccapital) {
		this.returnOnEconomiccapital = returnOnEconomiccapital;
	}

	public Double getExpectedRaroc() {
		return expectedRaroc;
	}

	public void setExpectedRaroc(Double expectedRaroc) {
		this.expectedRaroc = expectedRaroc;
	}
	
	
	

}
