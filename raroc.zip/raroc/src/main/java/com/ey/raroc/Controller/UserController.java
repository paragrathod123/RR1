package com.ey.raroc.Controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ey.raroc.Entity.Role;
import com.ey.raroc.Entity.User;
import com.ey.raroc.Repository.RoleRepository;
import com.ey.raroc.Repository.UserRepository;
import com.ey.raroc.Service.UserService;

import jakarta.servlet.http.HttpServletRequest;

@RequestMapping("/user")
@Controller
public class UserController {
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private RoleRepository roleRepo;
	
	@GetMapping("/listuser")
	public String listUsers(Model model) {
	    List<User> listUsers = userRepo.findAll();
	    model.addAttribute("listUsers", listUsers);
	     
	    return "User/listUser";
	}
	
	
	@GetMapping("/addUser")
	public String addUser(Model model) {
		User user = new User();
		model.addAttribute("user", user);
	    return "User/addUser";
	}
	
	@GetMapping("/importUser")
	public String importTb() {
		return "User/importUser.html";
	}
	
	@PostMapping("/import")
	public String readUserExcelDataToDb(@RequestParam("file") MultipartFile reapExcelDataFile, Model theModel,
			RedirectAttributes redirectAttributes, HttpServletRequest request) throws IOException {
		System.out.println("inside import");
		userService.uploadUsers(reapExcelDataFile, request);
		return "redirect:/user/listuser";
	}
	
	
	@GetMapping("/editUser")
	public String showFormForUpdate(@RequestParam("userId") Long id, Model theModel) {
		User user = new User();
		user = userService.getUserById(id);
		theModel.addAttribute("user", user);
		return "User/updateuser";
	}
	
	
	@PostMapping("/updateUser")
	public String updateTempUser(@ModelAttribute("userData") @jakarta.validation.Valid User theUser, BindingResult bindingResult,
			@RequestParam(required = false, value = "updatebutn") String updateFlag,
			@RequestParam(required = false, value = "updateandsendbutn") String updateSendFlag,
			RedirectAttributes redirectAttributes, HttpServletRequest request) {
		userService.updateuser(theUser.getName(), theUser.getDesignationName(),theUser.getActive(), theUser.getId());
		//userRepo.setUserInfoById(theUser.getName(), theUser.getDesignationName(),theUser.getActive(), theUser.getId());
		return "redirect:/user/listuser";
	}
	
	@PostMapping("/createUser")
	public String createUser(@ModelAttribute("userData") @jakarta.validation.Valid User theUser, BindingResult bindingResult,
			@RequestParam(required = false, value = "updatebutn") String updateFlag,
			@RequestParam(required = false, value = "updateandsendbutn") String updateSendFlag,
			RedirectAttributes redirectAttributes, HttpServletRequest request) {
		Role role = roleRepo.findById(Long.valueOf(request.getParameter("roleId"))).get();
		theUser.setRoles(role);
		userService.createUser(theUser);
		return "redirect:/user/listuser";
	}
}
