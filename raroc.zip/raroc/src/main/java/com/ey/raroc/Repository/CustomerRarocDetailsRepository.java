package com.ey.raroc.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ey.raroc.Entity.CustomerRarocDetails;

public interface CustomerRarocDetailsRepository extends JpaRepository<CustomerRarocDetails, Long> {

}
