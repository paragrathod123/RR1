package com.ey.raroc.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "accounts")
public class Account {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "account_id")
	private Long accountId;
	
	@Column(name = "accountNumber")
	private String accountNumber;
	
	@Column(name = "customer")
	private String customer;
	
	@Column(name = "segment")
	private String segment;
	
	@Column(name = "subProduct")
	private String subProduct;
	
	@Column(name = "productClass")
	private String productClass;
	
	@Column(name = "branch")
	private String branch;
	
	@Column(name = "customerRM")
	private String customerRM;

	public Long getAccountId() {
		return accountId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public String getCustomer() {
		return customer;
	}

	public String getSegment() {
		return segment;
	}

	public String getSubProduct() {
		return subProduct;
	}

	public String getProductClass() {
		return productClass;
	}

	public String getBranch() {
		return branch;
	}

	public String getCustomerRM() {
		return customerRM;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public void setSegment(String segment) {
		this.segment = segment;
	}

	public void setSubProduct(String subProduct) {
		this.subProduct = subProduct;
	}

	public void setProductClass(String productClass) {
		this.productClass = productClass;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public void setCustomerRM(String customerRM) {
		this.customerRM = customerRM;
	}

	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountNumber=" + accountNumber + ", customer=" + customer
				+ ", segment=" + segment + ", subProduct=" + subProduct + ", productClass=" + productClass + ", branch="
				+ branch + ", customerRM=" + customerRM + ", getAccountId()=" + getAccountId() + ", getAccountNumber()="
				+ getAccountNumber() + ", getCustomer()=" + getCustomer() + ", getSegment()=" + getSegment()
				+ ", getSubProduct()=" + getSubProduct() + ", getProductClass()=" + getProductClass() + ", getBranch()="
				+ getBranch() + ", getCustomerRM()=" + getCustomerRM() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}
	

}
