package com.ey.raroc.config;

import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.ey.raroc.Entity.User;
import com.ey.raroc.Repository.UserRepository;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler{

	@Autowired
	private UserRepository userRepo;
	private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

	@Value("${PORTAL_PATH}")
	private String pathUrl;
	
	
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		Optional<String> loginNames  =  SecurityUtils.getCurrentUserLogin();
		HttpSession session = request.getSession();
		System.out.println("User Authenticated");
		String loginUser =  loginNames.get();
		User user = userRepo.findByEmail(loginUser);
		session.setAttribute("name", user.getName());
		session.setAttribute("userId", user.getId());
		session.setAttribute("roleId", user.getRoles().getRoleId());
		session.setAttribute("roleName", user.getRoles().getRole());
		session.setAttribute("pathUrl", pathUrl);
		session.setMaxInactiveInterval(10 * 60);
		System.out.println(loginUser);
		System.out.println(session.getAttribute("roleName"));
		// TODO Auto-generated method stub
		redirectStrategy.sendRedirect(request, response, "/home");
	
	
	}


}
