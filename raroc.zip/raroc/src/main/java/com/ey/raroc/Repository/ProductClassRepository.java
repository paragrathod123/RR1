package com.ey.raroc.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ey.raroc.Entity.ProductClassMst;
import com.ey.raroc.Entity.SegmentMst;

public interface ProductClassRepository extends JpaRepository<ProductClassMst, Long> {
	
	List<ProductClassMst> findAllByActiveStatusOrderByProductClassNameAsc(int activeStatus);

}
