package com.ey.raroc.DTO;

public class CustomerRarocDetailDTO {
	
	Long leadId;
	
	Double loanBalance;
	Double interestRate;
	Double interestIncome;
	Integer tenure;
	Double operatingExpense;
	Double expectedLosses;
	Double expectedLossRate;
	Double interestExpenses;
	Double otherIncome;
	Double netInterestIncome;
	Double netProfit;
	Double economicCapital;
	Double returnOnEconomiccapital;
	Double expectedRaroc;
	public Long getLeadId() {
		return leadId;
	}
	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	public Double getLoanBalance() {
		return loanBalance;
	}
	public void setLoanBalance(Double loanBalance) {
		this.loanBalance = loanBalance;
	}
	public Double getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}
	public Double getInterestIncome() {
		return interestIncome;
	}
	public void setInterestIncome(Double interestIncome) {
		this.interestIncome = interestIncome;
	}
	public Integer getTenure() {
		return tenure;
	}
	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}
	public Double getOperatingExpense() {
		return operatingExpense;
	}
	public void setOperatingExpense(Double operatingExpense) {
		this.operatingExpense = operatingExpense;
	}
	public Double getExpectedLosses() {
		return expectedLosses;
	}
	public void setExpectedLosses(Double expectedLosses) {
		this.expectedLosses = expectedLosses;
	}
	public Double getExpectedLossRate() {
		return expectedLossRate;
	}
	public void setExpectedLossRate(Double expectedLossRate) {
		this.expectedLossRate = expectedLossRate;
	}
	public Double getInterestExpenses() {
		return interestExpenses;
	}
	public void setInterestExpenses(Double interestExpenses) {
		this.interestExpenses = interestExpenses;
	}
	public Double getOtherIncome() {
		return otherIncome;
	}
	public void setOtherIncome(Double otherIncome) {
		this.otherIncome = otherIncome;
	}
	public Double getNetInterestIncome() {
		return netInterestIncome;
	}
	public void setNetInterestIncome(Double netInterestIncome) {
		this.netInterestIncome = netInterestIncome;
	}
	public Double getNetProfit() {
		return netProfit;
	}
	public void setNetProfit(Double netProfit) {
		this.netProfit = netProfit;
	}
	public Double getEconomicCapital() {
		return economicCapital;
	}
	public void setEconomicCapital(Double economicCapital) {
		this.economicCapital = economicCapital;
	}
	public Double getReturnOnEconomiccapital() {
		return returnOnEconomiccapital;
	}
	public void setReturnOnEconomiccapital(Double returnOnEconomiccapital) {
		this.returnOnEconomiccapital = returnOnEconomiccapital;
	}
	public Double getExpectedRaroc() {
		return expectedRaroc;
	}
	public void setExpectedRaroc(Double expectedRaroc) {
		this.expectedRaroc = expectedRaroc;
	}
	
	

}
