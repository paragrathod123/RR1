package com.ey.raroc.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AjaxDummyController {
	
	
	@GetMapping("/ajaxLead")
    public String index() {
        return "ajax";
    }
	
	@GetMapping("/ajaxCustomerDetails")
    public String index1() {
        return "ajaxCustomer";
    }

}
