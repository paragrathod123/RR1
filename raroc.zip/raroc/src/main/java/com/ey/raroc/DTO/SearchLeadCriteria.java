package com.ey.raroc.DTO;

public class SearchLeadCriteria {
	
	
	Long leadId;

	public Long getLeadId() {
		return leadId;
	}

	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	
	

}
