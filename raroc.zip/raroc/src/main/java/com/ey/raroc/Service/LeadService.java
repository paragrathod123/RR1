package com.ey.raroc.Service;

import java.time.Instant;
import java.util.List;
import java.util.logging.Level;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ey.raroc.DTO.LeadDTO;
import com.ey.raroc.Entity.LeadMst;
import com.ey.raroc.Repository.LeadRepository;
import com.ey.raroc.Repository.ProductClassRepository;
import com.ey.raroc.Repository.SegmentRepository;
import com.ey.raroc.Repository.UserRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class LeadService {

	@Autowired
	private LeadRepository leadRepository;
	
	@Autowired
	private ProductClassRepository productClassRepository;
	
	@Autowired
	private SegmentRepository segmentRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	
	public LeadMst findLeadById(Long id) {
		return leadRepository.findById(id).get();
	}
	
	public List<LeadMst> getAllLeads(){
		return leadRepository.findAll();
	}
	
	
	public LeadMst createLead(LeadMst theLead , HttpServletRequest request) {
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		
		
		Long producclasstid =  Long.valueOf(request.getParameter("producclasstid"));
		Long segmentid = Long.valueOf(request.getParameter("segment_id"));
		
		if(productClassRepository.findById(producclasstid).isPresent()) {
			theLead.setProductClassMst(productClassRepository.findById(producclasstid).get());
        }
        
        if(segmentRepository.findById(segmentid).isPresent()) {
        	theLead.setSegmentMst(segmentRepository.findById(segmentid).get());
        }
        
        if(userRepository.findById(((Long)session.getAttribute("userId"))).isPresent()) {
        	theLead.setUser(userRepository.findById(((Long)session.getAttribute("userId"))).get());
        }
		
      //Setting Created By  //Let Say Default
        theLead.setCreatedBy(((Long)session.getAttribute("userId")).intValue());
  	  //Setting Created Date
        theLead.setCreatedDate(Instant.now());
       
        leadRepository.save(theLead);
  	  
        return theLead;
		
	}
	
		public LeadMst updateLead(LeadMst theLead , HttpServletRequest request) {
		
		HttpSession session =  request.getSession();
		String filePath = (String)session.getAttribute("pathUrl");
		
		
		Long producclasstid =  Long.valueOf(request.getParameter("producclasstid"));
		Long segmentid = Long.valueOf(request.getParameter("segment_id"));
		
		if(productClassRepository.findById(producclasstid).isPresent()) {
			theLead.setProductClassMst(productClassRepository.findById(producclasstid).get());
        }
        
        if(segmentRepository.findById(segmentid).isPresent()) {
        	theLead.setSegmentMst(segmentRepository.findById(segmentid).get());
        }
        
        if(userRepository.findById(((Long)session.getAttribute("userId"))).isPresent()) {
        	theLead.setUser(userRepository.findById(((Long)session.getAttribute("userId"))).get());
        }
		
   
        theLead.setUpdatedBy(((Long)session.getAttribute("userId")).intValue());
        theLead.setUpdatedDate(Instant.now());
		
        LeadMst speakerTemp =  findLeadById(theLead.getLeadId());
        theLead.setCreatedBy(speakerTemp.getCreatedBy());
        theLead.setCreatedDate(speakerTemp.getCreatedDate());
       
        leadRepository.save(theLead);
  	  
        return theLead;
		
	}
		
		
	public LeadDTO getLeadResult(Long leadId) {
		
		LeadDTO lead =  new LeadDTO();
		
		LeadMst leadMst = new LeadMst();
		leadMst =  findLeadById(leadId);
		
		lead.setLeadId(leadMst.getLeadId());
		lead.setLeadNo(leadMst.getLeadNo());
		lead.setLeadDescription(leadMst.getLeadDescription());
		lead.setSegmentId(leadMst.getSegmentMst().getSegmentId());
		lead.setProductClassId(leadMst.getProductClassMst().getProductClassId());
		lead.setRmName(leadMst.getUser().getName());
		lead.setRmUserId(leadMst.getUser().getId());
		
		return lead;
		
	}
}
