package com.ey.raroc.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "productclassmst")
public class ProductClassMst {
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "producclasstid")
	private Long productClassId;
	
	@Column(name = "product_class_name")
	private String productClassName;
	
	
	@Column(name = "active_flag")
	private Integer activeStatus;


	public Long getProductClassId() {
		return productClassId;
	}


	public void setProductClassId(Long productClassId) {
		this.productClassId = productClassId;
	}


	public String getProductClassName() {
		return productClassName;
	}


	public void setProductClassName(String productClassName) {
		this.productClassName = productClassName;
	}


	public Integer getActiveStatus() {
		return activeStatus;
	}


	public void setActiveStatus(Integer activeStatus) {
		this.activeStatus = activeStatus;
	}


	@Override
	public String toString() {
		return "ProductClassMst [productClassId=" + productClassId + ", productClassName=" + productClassName
				+ ", activeStatus=" + activeStatus + "]";
	}
	
	

}
