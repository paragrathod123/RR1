package com.ey.raroc.Entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "raroc_threshold_mst")
public class RarocThresholdMst {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "segment_id")
	private Long rarocThresholdId;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "segment_id")
	private SegmentMst segmentMst;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "producclasstid")
	private ProductClassMst productClassMst;
	
	@Column(name = "raroc_threshold_value")
	private Double rarocThresholdValue;
	
	@Column(name = "active_flag")
	private Integer activeStatus;

	public Long getRarocThresholdId() {
		return rarocThresholdId;
	}

	public void setRarocThresholdId(Long rarocThresholdId) {
		this.rarocThresholdId = rarocThresholdId;
	}

	public SegmentMst getSegmentMst() {
		return segmentMst;
	}

	public void setSegmentMst(SegmentMst segmentMst) {
		this.segmentMst = segmentMst;
	}

	public ProductClassMst getProductClassMst() {
		return productClassMst;
	}

	public void setProductClassMst(ProductClassMst productClassMst) {
		this.productClassMst = productClassMst;
	}

	public Double getRarocThresholdValue() {
		return rarocThresholdValue;
	}

	public void setRarocThresholdValue(Double rarocThresholdValue) {
		this.rarocThresholdValue = rarocThresholdValue;
	}

	public Integer getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(Integer activeStatus) {
		this.activeStatus = activeStatus;
	}

	@Override
	public String toString() {
		return "RarocThresholdMst [rarocThresholdId=" + rarocThresholdId + ", segmentMst=" + segmentMst
				+ ", productClassMst=" + productClassMst + ", rarocThresholdValue=" + rarocThresholdValue
				+ ", activeStatus=" + activeStatus + "]";
	}
	
	
	
	

}
