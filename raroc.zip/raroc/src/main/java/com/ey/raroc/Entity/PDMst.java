package com.ey.raroc.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "pdmst")
public class PDMst {
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "pd_id")
	private Long pdId;
	
	@Column(name = "credit_from")
	private Integer creditFrom;
	
	@Column(name = "credit_to")
	private Integer creditTo;
	
	@Column(name = "pd_rate")
	private Double pdRate;

	public Long getPdId() {
		return pdId;
	}

	public void setPdId(Long pdId) {
		this.pdId = pdId;
	}

	public Integer getCreditFrom() {
		return creditFrom;
	}

	public void setCreditFrom(Integer creditFrom) {
		this.creditFrom = creditFrom;
	}

	public Integer getCreditTo() {
		return creditTo;
	}

	public void setCreditTo(Integer creditTo) {
		this.creditTo = creditTo;
	}

	public Double getPdRate() {
		return pdRate;
	}

	public void setPdRate(Double pdRate) {
		this.pdRate = pdRate;
	}

	@Override
	public String toString() {
		return "PDMst [pdId=" + pdId + ", creditFrom=" + creditFrom + ", creditTo=" + creditTo + ", pdRate=" + pdRate
				+ "]";
	}
	
	

}
