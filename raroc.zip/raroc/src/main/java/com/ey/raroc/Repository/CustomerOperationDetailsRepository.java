package com.ey.raroc.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ey.raroc.Entity.CustomerOperationDetails;

public interface CustomerOperationDetailsRepository extends JpaRepository<CustomerOperationDetails, Long> {

}
